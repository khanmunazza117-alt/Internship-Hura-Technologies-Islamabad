"""Convert Figma SVGs in res/drawable into Android VectorDrawable XML."""
from __future__ import annotations

import math
import re
import xml.etree.ElementTree as ET
from pathlib import Path

NS = {"svg": "http://www.w3.org/2000/svg"}
ET.register_namespace("", "http://www.w3.org/2000/svg")

DRAWABLE = Path(r"c:\Users\hura\PhoneClone\app\src\main\res\drawable")


def local(tag: str) -> str:
    return tag.split("}")[-1] if "}" in tag else tag


def rounded_rect(x: float, y: float, w: float, h: float, rx: float) -> str:
    rx = min(rx, w / 2, h / 2)
    if rx <= 0:
        return f"M{x},{y}h{w}v{h}h{-w}z"
    return (
        f"M{x + rx},{y}H{x + w - rx}A{rx},{rx} 0 0 1 {x + w},{y + rx}"
        f"V{y + h - rx}A{rx},{rx} 0 0 1 {x + w - rx},{y + h}"
        f"H{x + rx}A{rx},{rx} 0 0 1 {x},{y + h - rx}"
        f"V{y + rx}A{rx},{rx} 0 0 1 {x + rx},{y}Z"
    )


def circle_path(cx: float, cy: float, r: float) -> str:
    return f"M{cx - r},{cy}a{r},{r} 0 1,0 {2 * r},0a{r},{r} 0 1,0 {-2 * r},0"


def num(el, name: str, default: float = 0.0) -> float:
    v = el.attrib.get(name)
    if v is None:
        return default
    return float(v.replace("px", ""))


def xml_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def path_attrs(el) -> list[str]:
    fill = el.attrib.get("fill", "#000000")
    stroke = el.attrib.get("stroke")
    stroke_w = el.attrib.get("stroke-width")
    fill_rule = el.attrib.get("fill-rule") or el.attrib.get("clip-rule")
    attrs = []
    if fill == "none":
        attrs.append('android:fillColor="#00000000"')
    elif fill:
        attrs.append(f'android:fillColor="{fill}"')
    if fill_rule and "even" in fill_rule.lower():
        attrs.append('android:fillType="evenOdd"')
    if stroke and stroke != "none":
        attrs.append(f'android:strokeColor="{stroke}"')
        if stroke_w:
            attrs.append(f'android:strokeWidth="{stroke_w}"')
        attrs.append('android:strokeLineJoin="round"')
        attrs.append('android:strokeLineCap="round"')
    return attrs


def collect_paths(root) -> list[str]:
    nodes = []
    for el in root.iter():
        name = local(el.tag)
        if name == "path" and el.attrib.get("d"):
            nodes.append((el, el.attrib["d"]))
        elif name == "rect":
            x, y = num(el, "x"), num(el, "y")
            w, h = num(el, "width"), num(el, "height")
            rx = num(el, "rx", num(el, "ry", 0))
            nodes.append((el, rounded_rect(x, y, w, h, rx)))
        elif name == "circle":
            nodes.append((el, circle_path(num(el, "cx"), num(el, "cy"), num(el, "r"))))
    out = []
    for el, d in nodes:
        attrs = "\n        ".join(path_attrs(el) + [f'android:pathData="{xml_escape(d)}"'])
        out.append(f"    <path\n        {attrs}/>")
    return out


def convert(svg_path: Path) -> Path:
    tree = ET.parse(svg_path)
    root = tree.getroot()
    vb = root.attrib.get("viewBox", "0 0 24 24").split()
    vw, vh = float(vb[2]), float(vb[3])
    w = root.attrib.get("width", str(int(vw))).replace("px", "")
    h = root.attrib.get("height", str(int(vh))).replace("px", "")
    paths = "\n".join(collect_paths(root))
    xml = f'''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="{w}dp"
    android:height="{h}dp"
    android:viewportWidth="{vw}"
    android:viewportHeight="{vh}">
{paths}
</vector>
'''
    name = svg_path.stem
    if not name.startswith("ic_") and name not in {"sync_phone", "old_phone", "new_phone"}:
        name = "ic_" + name
    out = svg_path.with_name(f"{name}.xml")
    out.write_text(xml, encoding="utf-8")
    return out


def main():
    converted = []
    for svg in sorted(DRAWABLE.glob("*.svg")):
        out = convert(svg)
        svg.unlink()
        converted.append(out.name)
        print(f"converted {svg.name} -> {out.name}")
    print("done", len(converted))


if __name__ == "__main__":
    main()
