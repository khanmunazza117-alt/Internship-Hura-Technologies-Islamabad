package com.mastercoding.phoneclone.ui.screens

import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import coil.request.ImageRequest
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.model.FileCategory
import com.mastercoding.phoneclone.model.MediaItem
import com.mastercoding.phoneclone.ui.CloneViewModel
import com.mastercoding.phoneclone.ui.components.CheckCircle
import com.mastercoding.phoneclone.ui.components.FileListCard
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.components.ScreenHeader
import com.mastercoding.phoneclone.ui.components.SelectAllChip
import com.mastercoding.phoneclone.ui.theme.PcCard
import com.mastercoding.phoneclone.ui.theme.PcTextDim

@Composable
fun CategoryDetailScreen(
    category: FileCategory,
    vm: CloneViewModel,
    onBack: () -> Unit
) {
    val all by vm.items.collectAsState()
    val selected by vm.selectedIds.collectAsState()
    val list = all[category].orEmpty()
    val allSelected = list.isNotEmpty() && list.all { it.id in selected }

    PcScreen {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(stringResource(category.titleRes), stringResource(category.subtitleRes), onBack)
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                Box(Modifier.align(Alignment.CenterEnd)) {
                    SelectAllChip(
                        selected = allSelected,
                        onClick = { vm.selectAll(category, !allSelected) }
                    )
                }
            }
            if (list.isEmpty()) {
                Text(
                    stringResource(R.string.no_category_found, stringResource(category.titleRes)),
                    color = PcTextDim,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(24.dp)
                )
            } else if (category.isGrid) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(list, key = { it.id }) { item ->
                        MediaGridCell(
                            item = item,
                            selected = item.id in selected,
                            showPlay = category == FileCategory.VIDEOS,
                            onClick = { vm.toggle(item.id) }
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(list, key = { it.id }) { item ->
                        FileListCard(
                            selected = item.id in selected,
                            title = item.name,
                            onClick = { vm.toggle(item.id) }
                        ) {
                            ListLeadingIcon(category, item, vm)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaGridCell(
    item: MediaItem,
    selected: Boolean,
    showPlay: Boolean,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    Box(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(4.dp))
            .background(PcCard)
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(item.uri)
                .crossfade(true)
                .apply { if (showPlay) decoderFactory(VideoFrameDecoder.Factory()) }
                .build(),
            contentDescription = item.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (showPlay) {
            Box(
                Modifier
                    .align(Alignment.Center)
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.35f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White)
            }
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(6.dp)) {
            CheckCircle(selected = selected, size = 20.dp)
        }
    }
}

@Composable
private fun ListLeadingIcon(category: FileCategory, item: MediaItem, vm: CloneViewModel) {
    when (category) {
        FileCategory.APPS -> {
            val drawable = remember(item.packageName) { vm.appIcon(item.packageName) }
            AppGlyph(drawable)
        }
        FileCategory.AUDIOS -> {
            Icon(
                painter = painterResource(R.drawable.ic_audios),
                contentDescription = null,
                tint = Color.Unspecified,
                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
            )
        }
        else -> {
            Icon(
                painter = painterResource(R.drawable.ic_documents),
                contentDescription = null,
                tint = Color.Unspecified,
                modifier = Modifier.size(40.dp)
            )
        }
    }
}

@Composable
private fun AppGlyph(drawable: Drawable?) {
    if (drawable != null) {
        val bmp = remember(drawable) { drawable.toBitmap() }
        Image(
            bmp.asImageBitmap(),
            contentDescription = null,
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp))
        )
    } else {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1A1A1A)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_apps),
                contentDescription = null,
                tint = Color.Unspecified,
                modifier = Modifier.size(40.dp)
            )
        }
    }
}
