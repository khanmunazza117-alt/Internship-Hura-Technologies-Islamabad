package com.mastercoding.phoneclone.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.model.TransferRole
import com.mastercoding.phoneclone.transfer.TransferService
import com.mastercoding.phoneclone.transfer.TransferState
import com.mastercoding.phoneclone.ui.CloneViewModel
import com.mastercoding.phoneclone.ui.components.PcOutlineButton
import com.mastercoding.phoneclone.ui.components.PcPrimaryButton
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.components.ScreenHeader
import com.mastercoding.phoneclone.ui.theme.PcBlue
import com.mastercoding.phoneclone.ui.theme.PcText
import com.mastercoding.phoneclone.ui.theme.PcTextDim
import com.mastercoding.phoneclone.util.Formatters

@Composable
fun TransferProgressScreen(
    vm: CloneViewModel,
    onBackHome: () -> Unit
) {
    val context = LocalContext.current
    val state by TransferService.snapshot.collectAsState()
    val logged = remember { androidx.compose.runtime.mutableStateOf(false) }

    LaunchedEffect(state) {
        val done = state as? TransferState.Completed
        if (done != null && !logged.value) {
            logged.value = true
            vm.addHistory(done.fileCount, done.sent, done.bytes)
        }
    }

    val title = when (state) {
        is TransferState.Connecting -> stringResource(R.string.connecting)
        is TransferState.Waiting -> stringResource(R.string.waiting)
        is TransferState.Transferring -> {
            if ((state as TransferState.Transferring).role == TransferRole.SENDER) {
                stringResource(R.string.sending)
            } else {
                stringResource(R.string.receiving)
            }
        }
        is TransferState.Completed -> stringResource(R.string.completed)
        is TransferState.Failed -> stringResource(R.string.failed)
        else -> stringResource(R.string.transfer)
    }

    PcScreen {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ScreenHeader(title, stringResource(R.string.keep_phones_unlocked), onBack = onBackHome)
            Spacer(Modifier.weight(1f))
            when (val s = state) {
                is TransferState.Connecting -> {
                    Text(s.message.uppercase(), color = PcText, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
                is TransferState.Waiting -> {
                    Text(stringResource(R.string.waiting_other_phone), color = PcText, fontWeight = FontWeight.Bold)
                }
                is TransferState.Transferring -> {
                    Text(
                        "${s.index} / ${s.total}",
                        color = PcBlue,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(s.currentFile, color = PcText, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    LinearProgressIndicator(
                        progress = { s.overall },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = PcBlue,
                        trackColor = androidx.compose.ui.graphics.Color(0xFF3A3A3C),
                        strokeCap = StrokeCap.Round
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "${Formatters.bytes(s.bytesDone)} / ${Formatters.bytes(s.bytesTotal)}",
                        color = PcTextDim,
                        fontSize = 12.sp
                    )
                }
                is TransferState.Completed -> {
                    Text(
                        stringResource(if (s.sent) R.string.files_sent else R.string.files_received, s.fileCount),
                        color = PcText,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(Formatters.bytes(s.bytes), color = PcTextDim)
                }
                is TransferState.Failed -> {
                    Text(s.message.uppercase(), color = PcText, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
                else -> {}
            }
            Spacer(Modifier.weight(1f))
            if (state is TransferState.Completed || state is TransferState.Failed) {
                PcPrimaryButton(stringResource(R.string.done), Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
                    TransferService.reset()
                    onBackHome()
                }
            } else {
                PcOutlineButton(stringResource(R.string.cancel), Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
                    TransferService.cancel(context)
                    TransferService.reset()
                    onBackHome()
                }
            }
        }
    }
}
