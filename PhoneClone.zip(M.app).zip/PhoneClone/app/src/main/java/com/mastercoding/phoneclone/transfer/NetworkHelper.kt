package com.mastercoding.phoneclone.transfer

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object NetworkHelper {
    fun localIpv4(): String {
        val hotspot = preferredHotspotIp()
        if (hotspot != null) return hotspot
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty().forEach { ni ->
            ni.inetAddresses.toList().forEach { addr ->
                if (!addr.isLoopbackAddress && addr is Inet4Address) {
                    val ip = addr.hostAddress ?: return@forEach
                    if (!ip.startsWith("169.254")) return ip
                }
            }
        }
        return "0.0.0.0"
    }

    private fun preferredHotspotIp(): String? {
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty().forEach { ni ->
            val name = ni.name.lowercase()
            ni.inetAddresses.toList().forEach { addr ->
                if (!addr.isLoopbackAddress && addr is Inet4Address) {
                    val ip = addr.hostAddress ?: return@forEach
                    if (ip.startsWith("192.168.43.") ||
                        ip.startsWith("192.168.49.") ||
                        ip.startsWith("192.168.137.") ||
                        name.contains("ap") ||
                        name.contains("wlan1")
                    ) {
                        return ip
                    }
                }
            }
        }
        return null
    }

    fun deviceName(): String = Build.MODEL ?: "Phone"
}

class HotspotController(context: Context) {
    private val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    @Volatile var reservation: WifiManager.LocalOnlyHotspotReservation? = null
        private set
    @Volatile var ssid: String? = null
        private set
    @Volatile var password: String? = null
        private set

    fun start(onReady: (ssid: String?, pass: String?) -> Unit) {
        if (Build.VERSION.SDK_INT < 26) {
            onReady(null, null)
            return
        }
        try {
            wifi.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation) {
                    this@HotspotController.reservation = reservation
                    if (Build.VERSION.SDK_INT >= 30) {
                        val soft = reservation.softApConfiguration
                        ssid = soft.ssid?.trim('"')
                        password = soft.passphrase
                    } else {
                        @Suppress("DEPRECATION")
                        val config = reservation.wifiConfiguration
                        ssid = config?.SSID?.trim('"')
                        password = config?.preSharedKey?.trim('"')
                    }
                    onReady(ssid, password)
                }

                override fun onFailed(reason: Int) {
                    onReady(null, null)
                }
            }, null)
        } catch (_: SecurityException) {
            onReady(null, null)
        } catch (_: Exception) {
            onReady(null, null)
        }
    }

    fun stop() {
        try {
            reservation?.close()
        } catch (_: Exception) {
        }
        reservation = null
        ssid = null
        password = null
    }
}

class NsdPublisher(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var registration: NsdManager.RegistrationListener? = null

    fun register(name: String, port: Int) {
        unregister()
        val info = NsdServiceInfo().apply {
            serviceName = name
            serviceType = TransferProtocol.NSD_TYPE
            this.port = port
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {}
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {}
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
        }
        registration = listener
        runCatching { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener) }
    }

    fun unregister() {
        val listener = registration ?: return
        runCatching { nsd.unregisterService(listener) }
        registration = null
    }
}

class NsdFinder(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager

    suspend fun find(timeoutMs: Long = 18_000): Pair<String, Int> = withTimeout(timeoutMs) {
        suspendCancellableCoroutine { cont ->
            var discovery: NsdManager.DiscoveryListener? = null
            val stop = {
                discovery?.let { runCatching { nsd.stopServiceDiscovery(it) } }
            }
            discovery = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String) {}
                override fun onDiscoveryStopped(serviceType: String) {}
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                    if (cont.isActive) cont.resumeWithException(IllegalStateException("Discovery failed"))
                }
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
                override fun onServiceLost(service: NsdServiceInfo) {}
                override fun onServiceFound(service: NsdServiceInfo) {
                    if (!service.serviceType.contains("phoneclone", ignoreCase = true) &&
                        service.serviceType != TransferProtocol.NSD_TYPE
                    ) return
                    nsd.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            val host = serviceInfo.host?.hostAddress ?: return
                            if (cont.isActive) {
                                stop()
                                cont.resume(host to serviceInfo.port)
                            }
                        }
                    })
                }
            }
            nsd.discoverServices(TransferProtocol.NSD_TYPE, NsdManager.PROTOCOL_DNS_SD, discovery)
            cont.invokeOnCancellation { stop() }
        }
    }
}

suspend fun bindToHotspot(context: Context, ssid: String, pass: String): Network {
    if (Build.VERSION.SDK_INT < 29) error("Hotspot join requires Android 10+")
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val specifier = WifiNetworkSpecifier.Builder()
        .setSsid(ssid)
        .setWpa2Passphrase(pass)
        .build()
    val request = NetworkRequest.Builder()
        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        .setNetworkSpecifier(specifier)
        .build()
    return suspendCancellableCoroutine { cont ->
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cm.bindProcessToNetwork(network)
                if (cont.isActive) cont.resume(network)
            }

            override fun onUnavailable() {
                if (cont.isActive) cont.resumeWithException(IllegalStateException("Unable to join hotspot"))
            }
        }
        cm.requestNetwork(request, callback)
        cont.invokeOnCancellation {
            runCatching { cm.unregisterNetworkCallback(callback) }
            cm.bindProcessToNetwork(null)
        }
    }
}

fun unbindNetwork(context: Context) {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    cm.bindProcessToNetwork(null)
}
