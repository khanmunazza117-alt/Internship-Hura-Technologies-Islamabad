package com.mastercoding.phoneclone.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("phone_clone_prefs")

class AppPreferences(private val context: Context) {
    private val termsKey = booleanPreferencesKey("terms_accepted")
    private val languageKey = stringPreferencesKey("language_tag")

    val termsAccepted: Flow<Boolean> = context.dataStore.data.map { it[termsKey] ?: false }
    val languageTag: Flow<String> = context.dataStore.data.map { it[languageKey] ?: "en" }

    suspend fun setTermsAccepted(accepted: Boolean) {
        context.dataStore.edit { it[termsKey] = accepted }
    }

    suspend fun setLanguage(tag: String) {
        com.mastercoding.phoneclone.util.LocaleHelper.persist(context, tag)
        context.dataStore.edit { it[languageKey] = tag }
    }
}
