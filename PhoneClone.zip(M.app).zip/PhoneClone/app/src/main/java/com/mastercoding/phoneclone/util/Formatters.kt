package com.mastercoding.phoneclone.util

import android.content.Context
import com.mastercoding.phoneclone.R
import java.util.Locale

object Formatters {
    fun bytes(value: Long): String {
        if (value <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var size = value.toDouble()
        var idx = 0
        while (size >= 1024 && idx < units.lastIndex) {
            size /= 1024.0
            idx++
        }
        return if (idx == 0) {
            "${size.toInt()} ${units[idx]}"
        } else {
            String.format(Locale.US, "%.2f %s", size, units[idx])
        }
    }

    fun storageLine(context: Context, used: Long, total: Long): String {
        return context.getString(R.string.storage_line, bytes(used), bytes(total))
    }

    fun itemsLine(context: Context, count: Int, bytes: Long): String {
        return context.getString(R.string.items_line, count, bytes(bytes))
    }

    fun historyDate(millis: Long): String {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = millis }
        val d = cal.get(java.util.Calendar.DAY_OF_MONTH).toString().padStart(2, '0')
        val m = (cal.get(java.util.Calendar.MONTH) + 1).toString().padStart(2, '0')
        val y = cal.get(java.util.Calendar.YEAR)
        return "$d/$m/$y"
    }
}
