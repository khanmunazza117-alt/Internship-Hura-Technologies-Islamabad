package com.mastercoding.phoneclone.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.model.FileCategory
import com.mastercoding.phoneclone.ui.CloneViewModel
import com.mastercoding.phoneclone.ui.components.CategoryRow
import com.mastercoding.phoneclone.ui.components.PcPrimaryButton
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.components.ScreenHeader
import com.mastercoding.phoneclone.ui.theme.PcTextDim
import com.mastercoding.phoneclone.util.Formatters
import com.mastercoding.phoneclone.util.PermissionSets

@Composable
fun SelectFileScreen(
    vm: CloneViewModel,
    onBack: () -> Unit,
    onOpenCategory: (FileCategory) -> Unit,
    onSend: () -> Unit
) {
    val context = LocalContext.current
    val items by vm.items.collectAsState()
    val selected by vm.selectedIds.collectAsState()
    val loading by vm.loading.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { vm.loadMedia() }

    LaunchedEffect(Unit) {
        if (PermissionSets.mediaGranted(context)) {
            vm.loadMedia()
        } else {
            permissionLauncher.launch(PermissionSets.media())
        }
    }

    PcScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            ScreenHeader(stringResource(R.string.select_file), stringResource(R.string.line_description), onBack)
            if (loading) {
                Text(stringResource(R.string.scanning_files), color = PcTextDim, fontSize = 12.sp)
            }
            Column(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FileCategory.entries.forEach { cat ->
                    val list = items[cat].orEmpty()
                    val icon = when (cat) {
                        FileCategory.PHOTOS -> R.drawable.ic_photos
                        FileCategory.VIDEOS -> R.drawable.ic_videos
                        FileCategory.AUDIOS -> R.drawable.ic_audios
                        FileCategory.DOCUMENTS -> R.drawable.ic_documents
                        FileCategory.APPS -> R.drawable.ic_apps
                    }
                    CategoryRow(
                        selected = vm.isCategorySelected(cat),
                        icon = painterResource(icon),
                        title = stringResource(cat.titleRes),
                        subtitle = Formatters.itemsLine(context, list.size, list.sumOf { it.size }),
                        onToggle = { vm.toggleCategory(cat) },
                        onOpen = { onOpenCategory(cat) }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            PcPrimaryButton(
                text = stringResource(R.string.send_file, selected.size),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                enabled = selected.isNotEmpty(),
                onClick = onSend
            )
        }
    }
}
