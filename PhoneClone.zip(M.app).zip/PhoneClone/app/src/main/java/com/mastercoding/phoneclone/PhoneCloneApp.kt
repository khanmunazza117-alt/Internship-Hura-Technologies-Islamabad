package com.mastercoding.phoneclone

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.mastercoding.phoneclone.util.LocaleHelper

class PhoneCloneApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleHelper.wrap(base))
    }

    override fun onCreate() {
        super.onCreate()
        val tag = LocaleHelper.getTag(this)
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    "phone_clone_transfer",
                    getString(R.string.notification_transfers),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }
}
