package com.mastercoding.phoneclone.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val PhoneCloneColorScheme = darkColorScheme(
    primary = PcBlue,
    onPrimary = Color.White,
    secondary = PcBlue,
    background = PcBlack,
    onBackground = PcText,
    surface = PcCard,
    onSurface = PcText,
    surfaceVariant = PcCardAlt,
    onSurfaceVariant = PcTextDim
)

@Composable
fun PhoneCloneTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? android.app.Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = PhoneCloneColorScheme,
        typography = Typography,
        content = content
    )
}
