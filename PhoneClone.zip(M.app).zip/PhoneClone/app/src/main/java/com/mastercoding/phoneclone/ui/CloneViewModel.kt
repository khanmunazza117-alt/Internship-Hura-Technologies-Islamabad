package com.mastercoding.phoneclone.ui

import android.app.Application
import android.graphics.drawable.Drawable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mastercoding.phoneclone.data.AppPreferences
import com.mastercoding.phoneclone.data.HistoryStore
import com.mastercoding.phoneclone.data.MediaRepository
import com.mastercoding.phoneclone.model.FileCategory
import com.mastercoding.phoneclone.model.HistoryEntry
import com.mastercoding.phoneclone.model.MediaItem
import com.mastercoding.phoneclone.model.StorageInfo
import com.mastercoding.phoneclone.transfer.TransferService
import com.mastercoding.phoneclone.transfer.TransferState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class CloneViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MediaRepository(app)
    private val historyStore = HistoryStore(app)
    val prefs = AppPreferences(app)

    val storage = MutableStateFlow(StorageInfo(0, 1))
    val items = MutableStateFlow<Map<FileCategory, List<MediaItem>>>(emptyMap())
    val selectedIds = MutableStateFlow<Set<String>>(emptySet())
    val loading = MutableStateFlow(false)
    val history: StateFlow<List<HistoryEntry>> = historyStore.entries
    val transfer: StateFlow<TransferState> = TransferService.snapshot
    val termsAccepted = prefs.termsAccepted.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    init {
        viewModelScope.launch { historyStore.load() }
        viewModelScope.launch { storage.value = repo.storageInfo() }
    }

    fun loadMedia() {
        viewModelScope.launch {
            loading.value = true
            try {
                val map = FileCategory.entries.associateWith { repo.loadCategory(it) }
                items.value = map
            } finally {
                loading.value = false
            }
        }
    }

    fun itemsOf(category: FileCategory): List<MediaItem> = items.value[category].orEmpty()

    fun selectedCount(): Int = selectedIds.value.size

    fun selectedItems(): List<MediaItem> {
        val ids = selectedIds.value
        return items.value.values.flatten().filter { it.id in ids }
    }

    fun toggle(id: String) {
        selectedIds.value = selectedIds.value.toMutableSet().also {
            if (!it.add(id)) it.remove(id)
        }
    }

    fun toggleCategory(category: FileCategory) {
        val catItems = itemsOf(category)
        val ids = catItems.map { it.id }.toSet()
        val current = selectedIds.value
        selectedIds.value = if (ids.isNotEmpty() && current.containsAll(ids)) {
            current - ids
        } else {
            current + ids
        }
    }

    fun isCategorySelected(category: FileCategory): Boolean {
        val catItems = itemsOf(category)
        return catItems.isNotEmpty() && selectedIds.value.containsAll(catItems.map { it.id })
    }

    fun selectAll(category: FileCategory, selected: Boolean) {
        val ids = itemsOf(category).map { it.id }.toSet()
        selectedIds.value = if (selected) selectedIds.value + ids else selectedIds.value - ids
    }

    fun isAllSelected(category: FileCategory): Boolean = isCategorySelected(category)

    fun appIcon(packageName: String?): Drawable? {
        if (packageName.isNullOrBlank()) return null
        return runCatching {
            getApplication<Application>().packageManager.getApplicationIcon(packageName)
        }.getOrNull()
    }

    fun addHistory(count: Int, sent: Boolean, bytes: Long) {
        viewModelScope.launch {
            historyStore.add(
                HistoryEntry(
                    id = UUID.randomUUID().toString(),
                    fileCount = count,
                    dateMillis = System.currentTimeMillis(),
                    sent = sent,
                    totalBytes = bytes
                )
            )
        }
    }

    fun deleteHistory(id: String) {
        viewModelScope.launch { historyStore.delete(id) }
    }

    fun acceptTerms() {
        viewModelScope.launch { prefs.setTermsAccepted(true) }
    }

    fun setLanguage(tag: String) {
        viewModelScope.launch { prefs.setLanguage(tag) }
    }
}
