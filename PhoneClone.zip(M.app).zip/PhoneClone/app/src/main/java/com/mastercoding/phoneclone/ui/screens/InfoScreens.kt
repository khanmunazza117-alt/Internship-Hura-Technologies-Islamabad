package com.mastercoding.phoneclone.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.ui.CloneViewModel
import com.mastercoding.phoneclone.ui.components.CardShape
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.components.ScreenHeader
import com.mastercoding.phoneclone.ui.theme.PcBlue
import com.mastercoding.phoneclone.ui.theme.PcCard
import com.mastercoding.phoneclone.ui.theme.PcText
import com.mastercoding.phoneclone.ui.theme.PcTextDim
import com.mastercoding.phoneclone.util.LocaleHelper

private data class Lang(val tag: String, val labelRes: Int)

private val languages = listOf(
    Lang("en", R.string.lang_en),
    Lang("es", R.string.lang_es),
    Lang("fr", R.string.lang_fr),
    Lang("de", R.string.lang_de),
    Lang("hi", R.string.lang_hi),
    Lang("ar", R.string.lang_ar),
    Lang("pt", R.string.lang_pt),
    Lang("zh", R.string.lang_zh)
)

@Composable
fun LanguageScreen(vm: CloneViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val current = LocaleHelper.getTag(context)
    PcScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            ScreenHeader(
                stringResource(R.string.language_title),
                stringResource(R.string.language_subtitle),
                onBack
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(languages) { lang ->
                    val selected = current == lang.tag
                    Text(
                        stringResource(lang.labelRes),
                        color = PcText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(CardShape)
                            .background(if (selected) PcBlue else PcCard)
                            .clickable {
                                if (lang.tag == current) return@clickable
                                vm.setLanguage(lang.tag)
                                LocaleHelper.apply(context, lang.tag)
                            }
                            .padding(horizontal = 16.dp, vertical = 18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    PcScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            ScreenHeader(
                stringResource(R.string.privacy_policy),
                stringResource(R.string.privacy_subtitle),
                onBack
            )
            Text(
                stringResource(R.string.privacy_body),
                color = PcTextDim,
                fontSize = 14.sp,
                lineHeight = 22.sp,
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 24.dp)
            )
        }
    }
}
