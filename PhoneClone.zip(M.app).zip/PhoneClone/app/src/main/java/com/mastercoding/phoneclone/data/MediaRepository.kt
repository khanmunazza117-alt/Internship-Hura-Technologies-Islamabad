package com.mastercoding.phoneclone.data

import android.content.ContentUris
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import com.mastercoding.phoneclone.model.FileCategory
import com.mastercoding.phoneclone.model.MediaItem
import com.mastercoding.phoneclone.model.StorageInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {

    suspend fun storageInfo(): StorageInfo = withContext(Dispatchers.IO) {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val total = stat.totalBytes
        val available = stat.availableBytes
        StorageInfo(usedBytes = total - available, totalBytes = total)
    }

    suspend fun loadCategory(category: FileCategory): List<MediaItem> = withContext(Dispatchers.IO) {
        when (category) {
            FileCategory.PHOTOS -> queryImages()
            FileCategory.VIDEOS -> queryVideos()
            FileCategory.AUDIOS -> queryAudio()
            FileCategory.DOCUMENTS -> queryDocuments()
            FileCategory.APPS -> queryApps()
        }
    }

    private fun queryImages(): List<MediaItem> {
        val items = mutableListOf<MediaItem>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.DATE_ADDED
        )
        val sort = "${MediaStore.Images.Media.DATE_ADDED} DESC"
        context.contentResolver.query(collection, projection, null, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                items += MediaItem(
                    id = "photo_$id",
                    name = cursor.getString(nameCol) ?: "Photo",
                    size = cursor.getLong(sizeCol),
                    mime = cursor.getString(mimeCol) ?: "image/jpeg",
                    category = FileCategory.PHOTOS,
                    uri = ContentUris.withAppendedId(collection, id),
                    dateAdded = cursor.getLong(dateCol)
                )
            }
        }
        return items
    }

    private fun queryVideos(): List<MediaItem> {
        val items = mutableListOf<MediaItem>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.DATE_ADDED
        )
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        context.contentResolver.query(collection, projection, null, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                items += MediaItem(
                    id = "video_$id",
                    name = cursor.getString(nameCol) ?: "Video",
                    size = cursor.getLong(sizeCol),
                    mime = cursor.getString(mimeCol) ?: "video/mp4",
                    category = FileCategory.VIDEOS,
                    uri = ContentUris.withAppendedId(collection, id),
                    dateAdded = cursor.getLong(dateCol)
                )
            }
        }
        return items
    }

    private fun queryAudio(): List<MediaItem> {
        val items = mutableListOf<MediaItem>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val sort = "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        context.contentResolver.query(collection, projection, null, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val mime = cursor.getString(mimeCol) ?: "audio/mpeg"
                if (mime.startsWith("audio")) {
                    items += MediaItem(
                        id = "audio_$id",
                        name = cursor.getString(nameCol) ?: "Audio",
                        size = cursor.getLong(sizeCol),
                        mime = mime,
                        category = FileCategory.AUDIOS,
                        uri = ContentUris.withAppendedId(collection, id),
                        dateAdded = cursor.getLong(dateCol)
                    )
                }
            }
        }
        return items
    }

    private fun queryDocuments(): List<MediaItem> {
        val items = mutableListOf<MediaItem>()
        val seen = HashSet<String>()

        if (Build.VERSION.SDK_INT >= 29) {
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE,
                MediaStore.Downloads.MIME_TYPE,
                MediaStore.Downloads.DATE_ADDED
            )
            context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Downloads.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_ADDED)
                while (cursor.moveToNext()) {
                    val mime = cursor.getString(mimeCol) ?: "application/octet-stream"
                    if (isMediaMime(mime)) continue
                    val id = cursor.getLong(idCol)
                    val key = "dl_$id"
                    seen += key
                    items += MediaItem(
                        id = key,
                        name = cursor.getString(nameCol) ?: "Document",
                        size = cursor.getLong(sizeCol),
                        mime = mime,
                        category = FileCategory.DOCUMENTS,
                        uri = ContentUris.withAppendedId(collection, id),
                        dateAdded = cursor.getLong(dateCol)
                    )
                }
            }
        }

        val filesUri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATE_ADDED,
            MediaStore.Files.FileColumns.MEDIA_TYPE
        )
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
        val args = arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_NONE.toString())
        context.contentResolver.query(
            filesUri,
            projection,
            selection,
            args,
            "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)
            while (cursor.moveToNext()) {
                val mime = cursor.getString(mimeCol) ?: continue
                if (isMediaMime(mime)) continue
                val name = cursor.getString(nameCol) ?: continue
                val id = cursor.getLong(idCol)
                val key = "file_$id"
                if (key in seen) continue
                items += MediaItem(
                    id = key,
                    name = name,
                    size = cursor.getLong(sizeCol),
                    mime = mime,
                    category = FileCategory.DOCUMENTS,
                    uri = ContentUris.withAppendedId(filesUri, id),
                    dateAdded = cursor.getLong(dateCol)
                )
            }
        }
        return items.distinctBy { it.id }
    }

    private fun isMediaMime(mime: String): Boolean {
        return mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/")
    }

    private fun queryApps(): List<MediaItem> {
        val pm = context.packageManager
        val flags = PackageManager.GET_META_DATA
        val apps = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(flags)
        }
        return apps
            .filter { app ->
                pm.getLaunchIntentForPackage(app.packageName) != null &&
                    app.packageName != context.packageName &&
                    (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0
            }
            .map { app ->
                val label = pm.getApplicationLabel(app).toString()
                val apk = java.io.File(app.sourceDir)
                MediaItem(
                    id = "app_${app.packageName}",
                    name = label,
                    size = if (apk.exists()) apk.length() else 0L,
                    mime = "application/vnd.android.package-archive",
                    category = FileCategory.APPS,
                    filePath = app.sourceDir,
                    packageName = app.packageName
                )
            }
            .sortedBy { it.name.lowercase() }
    }
}
