package com.mastercoding.phoneclone.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp
import com.mastercoding.phoneclone.ui.theme.PcBlue
import com.mastercoding.phoneclone.ui.theme.PcQrRed

object PcIcons {
    val StoragePhone: ImageVector by lazy {
        material("StoragePhone") {
            path(fill = SolidColor(Color.White)) {
                moveTo(7.2f, 2f)
                horizontalLineTo(16.8f)
                curveTo(17.9f, 2f, 18.8f, 2.9f, 18.8f, 4f)
                verticalLineTo(20f)
                curveTo(18.8f, 21.1f, 17.9f, 22f, 16.8f, 22f)
                horizontalLineTo(7.2f)
                curveTo(6.1f, 22f, 5.2f, 21.1f, 5.2f, 20f)
                verticalLineTo(4f)
                curveTo(5.2f, 2.9f, 6.1f, 2f, 7.2f, 2f)
                close()
                moveTo(7.8f, 5.2f)
                verticalLineTo(18.8f)
                horizontalLineTo(16.2f)
                verticalLineTo(5.2f)
                close()
            }
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.5f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(14.8f, 9.4f)
                arcToRelative(2.6f, 2.6f, 0f, true, false, -0.2f, 3.6f)
            }
        }
    }

    val OldPhone: ImageVector by lazy {
        material("OldPhone") {
            path(fill = SolidColor(Color.White)) {
                moveTo(3.5f, 3.5f)
                horizontalLineTo(12.2f)
                curveTo(13.2f, 3.5f, 14f, 4.3f, 14f, 5.3f)
                verticalLineTo(18.7f)
                curveTo(14f, 19.7f, 13.2f, 20.5f, 12.2f, 20.5f)
                horizontalLineTo(3.5f)
                curveTo(2.5f, 20.5f, 1.7f, 19.7f, 1.7f, 18.7f)
                verticalLineTo(5.3f)
                curveTo(1.7f, 4.3f, 2.5f, 3.5f, 3.5f, 3.5f)
                close()
                moveTo(4.3f, 6f)
                verticalLineTo(18f)
                horizontalLineTo(11.4f)
                verticalLineTo(6f)
                close()
            }
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(16f, 12f)
                horizontalLineTo(22.2f)
            }
            path(fill = SolidColor(Color.White)) {
                moveTo(20f, 9.7f)
                lineTo(23.2f, 12f)
                lineTo(20f, 14.3f)
                close()
            }
        }
    }

    val NewPhone: ImageVector by lazy {
        material("NewPhone") {
            path(fill = SolidColor(Color.White)) {
                moveTo(11.8f, 3.5f)
                horizontalLineTo(20.5f)
                curveTo(21.5f, 3.5f, 22.3f, 4.3f, 22.3f, 5.3f)
                verticalLineTo(18.7f)
                curveTo(22.3f, 19.7f, 21.5f, 20.5f, 20.5f, 20.5f)
                horizontalLineTo(11.8f)
                curveTo(10.8f, 20.5f, 10f, 19.7f, 10f, 18.7f)
                verticalLineTo(5.3f)
                curveTo(10f, 4.3f, 10.8f, 3.5f, 11.8f, 3.5f)
                close()
                moveTo(12.6f, 6f)
                verticalLineTo(18f)
                horizontalLineTo(19.7f)
                verticalLineTo(6f)
                close()
            }
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(1.8f, 12f)
                horizontalLineTo(8.2f)
            }
            path(fill = SolidColor(Color.White)) {
                moveTo(6.2f, 9.7f)
                lineTo(9.3f, 12f)
                lineTo(6.2f, 14.3f)
                close()
            }
        }
    }

    val HistoryDoc: ImageVector by lazy {
        material("HistoryDoc") {
            path(fill = SolidColor(Color.White)) {
                moveTo(6f, 2f)
                horizontalLineTo(14.2f)
                lineTo(20f, 8f)
                verticalLineTo(20f)
                curveTo(20f, 21.1f, 19.1f, 22f, 18f, 22f)
                horizontalLineTo(6f)
                curveTo(4.9f, 22f, 4f, 21.1f, 4f, 20f)
                verticalLineTo(4f)
                curveTo(4f, 2.9f, 4.9f, 2f, 6f, 2f)
                close()
            }
            path(fill = SolidColor(Color(0xFF2C2C2E))) {
                moveTo(13.4f, 3.2f)
                verticalLineTo(8.2f)
                horizontalLineTo(18.4f)
                close()
            }
            path(
                stroke = SolidColor(Color(0xFF2C2C2E)),
                strokeLineWidth = 1.5f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(12f, 11.5f)
                arcToRelative(3.2f, 3.2f, 0f, true, true, -0.1f, 0.01f)
            }
            path(
                stroke = SolidColor(Color(0xFF2C2C2E)),
                strokeLineWidth = 1.3f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(12f, 10.6f)
                verticalLineTo(13.2f)
                lineTo(13.6f, 14f)
            }
        }
    }

    val Language: ImageVector by lazy {
        material("Language") {
            path(fill = SolidColor(Color.White)) {
                moveTo(3.5f, 5f)
                horizontalLineTo(14.5f)
                curveTo(15.6f, 5f, 16.5f, 5.9f, 16.5f, 7f)
                verticalLineTo(13.2f)
                curveTo(16.5f, 14.3f, 15.6f, 15.2f, 14.5f, 15.2f)
                horizontalLineTo(9.8f)
                lineTo(6f, 18.2f)
                verticalLineTo(15.2f)
                horizontalLineTo(3.5f)
                curveTo(2.4f, 15.2f, 1.5f, 14.3f, 1.5f, 13.2f)
                verticalLineTo(7f)
                curveTo(1.5f, 5.9f, 2.4f, 5f, 3.5f, 5f)
                close()
            }
            path(fill = SolidColor(Color.White)) {
                moveTo(17.2f, 9.2f)
                horizontalLineTo(20.2f)
                curveTo(21.3f, 9.2f, 22.2f, 10.1f, 22.2f, 11.2f)
                verticalLineTo(16.4f)
                curveTo(22.2f, 17.5f, 21.3f, 18.4f, 20.2f, 18.4f)
                horizontalLineTo(18.6f)
                verticalLineTo(21.2f)
                lineTo(15.4f, 18.4f)
                horizontalLineTo(15f)
                verticalLineTo(16.6f)
                horizontalLineTo(20.2f)
                verticalLineTo(11.2f)
                horizontalLineTo(17.2f)
                close()
            }
            path(fill = SolidColor(Color(0xFF2C2C2E))) {
                moveTo(7.4f, 7.6f)
                lineTo(10.6f, 13.6f)
                horizontalLineTo(9.1f)
                lineTo(8.5f, 12.2f)
                horizontalLineTo(6.1f)
                lineTo(5.5f, 13.6f)
                horizontalLineTo(4f)
                lineTo(7.2f, 7.6f)
                close()
                moveTo(6.5f, 11f)
                horizontalLineTo(8.1f)
                lineTo(7.3f, 9.1f)
                close()
            }
        }
    }

    val Privacy: ImageVector by lazy {
        material("Privacy") {
            path(fill = SolidColor(PcBlue)) {
                moveTo(12f, 2.2f)
                lineTo(20.2f, 6f)
                verticalLineTo(11.6f)
                curveTo(20.2f, 16.3f, 16.8f, 20.5f, 12f, 21.8f)
                curveTo(7.2f, 20.5f, 3.8f, 16.3f, 3.8f, 11.6f)
                verticalLineTo(6f)
                close()
            }
            path(
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(8.2f, 12.1f)
                lineTo(10.8f, 14.7f)
                lineTo(16.1f, 9.3f)
            }
        }
    }

    val Share: ImageVector by lazy {
        material("Share") {
            path(fill = SolidColor(PcBlue)) {
                moveTo(6f, 9.2f)
                arcToRelative(2.8f, 2.8f, 0f, true, true, 0.01f, 0f)
                close()
            }
            path(fill = SolidColor(PcBlue)) {
                moveTo(18f, 3.4f)
                arcToRelative(2.8f, 2.8f, 0f, true, true, 0.01f, 0f)
                close()
            }
            path(fill = SolidColor(PcBlue)) {
                moveTo(18f, 15.4f)
                arcToRelative(2.8f, 2.8f, 0f, true, true, 0.01f, 0f)
                close()
            }
            path(
                stroke = SolidColor(PcBlue),
                strokeLineWidth = 1.7f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(8.4f, 10.6f)
                lineTo(15.4f, 6.4f)
                moveTo(8.4f, 13.4f)
                lineTo(15.4f, 17.4f)
            }
        }
    }

    val Rate: ImageVector by lazy {
        material("Rate") {
            path(fill = SolidColor(PcBlue)) {
                moveTo(12f, 3f)
                lineTo(14.5f, 8.6f)
                lineTo(20.5f, 9.2f)
                lineTo(16.1f, 13.3f)
                lineTo(17.4f, 19.2f)
                lineTo(12f, 16.3f)
                lineTo(6.6f, 19.2f)
                lineTo(7.9f, 13.3f)
                lineTo(3.5f, 9.2f)
                lineTo(9.5f, 8.6f)
                close()
            }
        }
    }

    val Photos: ImageVector by lazy {
        material("Photos") {
            path(fill = SolidColor(Color.White)) {
                roundRect(3f, 6f, 21f, 20f, 2.2f)
            }
            path(fill = SolidColor(Color(0xFF1C1C1E))) {
                moveTo(4.4f, 18.4f)
                lineTo(9.3f, 11.6f)
                lineTo(12.6f, 15.6f)
                lineTo(15f, 12.8f)
                lineTo(19.6f, 18.4f)
                close()
            }
            path(fill = SolidColor(Color(0xFF1C1C1E))) {
                moveTo(16.6f, 8.6f)
                arcToRelative(1.5f, 1.5f, 0f, true, true, 0.01f, 0f)
                close()
            }
        }
    }

    val Videos: ImageVector by lazy {
        material("Videos") {
            path(fill = SolidColor(Color.White)) {
                moveTo(12f, 3f)
                arcToRelative(9f, 9f, 0f, true, true, 0.01f, 0f)
                close()
            }
            path(fill = SolidColor(Color(0xFF1C1C1E))) {
                moveTo(10f, 8.4f)
                lineTo(16.4f, 12f)
                lineTo(10f, 15.6f)
                close()
            }
        }
    }

    val Audios: ImageVector by lazy {
        material("Audios") {
            path(fill = SolidColor(Color.White)) {
                moveTo(10.2f, 3.6f)
                horizontalLineTo(18.2f)
                verticalLineTo(6.4f)
                horizontalLineTo(13.2f)
                verticalLineTo(15.8f)
                curveTo(13.2f, 18.2f, 11.4f, 20.1f, 9.1f, 20.1f)
                curveTo(6.8f, 20.1f, 5f, 18.2f, 5f, 15.8f)
                curveTo(5f, 13.4f, 6.8f, 11.5f, 9.1f, 11.5f)
                curveTo(9.5f, 11.5f, 9.9f, 11.6f, 10.2f, 11.7f)
                close()
            }
        }
    }

    val Documents: ImageVector by lazy {
        material("Documents") {
            path(fill = SolidColor(Color.White)) {
                moveTo(6f, 2.2f)
                horizontalLineTo(14f)
                lineTo(20f, 8.2f)
                verticalLineTo(20f)
                curveTo(20f, 21.1f, 19.1f, 22f, 18f, 22f)
                horizontalLineTo(6f)
                curveTo(4.9f, 22f, 4f, 21.1f, 4f, 20f)
                verticalLineTo(4.2f)
                curveTo(4f, 3.1f, 4.9f, 2.2f, 6f, 2.2f)
                close()
            }
            path(fill = SolidColor(Color(0xFF1C1C1E))) {
                moveTo(13.2f, 3.1f)
                verticalLineTo(8.4f)
                horizontalLineTo(18.4f)
                close()
            }
            path(
                stroke = SolidColor(Color(0xFF1C1C1E)),
                strokeLineWidth = 1.4f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(7.8f, 12.2f)
                horizontalLineTo(16.2f)
                moveTo(7.8f, 15.2f)
                horizontalLineTo(16.2f)
                moveTo(7.8f, 18.2f)
                horizontalLineTo(13.4f)
            }
        }
    }

    val Apps: ImageVector by lazy {
        material("Apps") {
            path(fill = SolidColor(Color.White)) {
                roundRect(4f, 4f, 10.2f, 10.2f, 1.4f)
                roundRect(13.8f, 4f, 20f, 10.2f, 1.4f)
                roundRect(4f, 13.8f, 10.2f, 20f, 1.4f)
                roundRect(13.8f, 13.8f, 20f, 20f, 1.4f)
            }
        }
    }

    val Wifi: ImageVector by lazy {
        material("Wifi") {
            path(
                stroke = SolidColor(PcBlue),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(4f, 10.2f)
                arcToRelative(11.2f, 11.2f, 0f, false, true, 16f, 0f)
                moveTo(7f, 13.4f)
                arcToRelative(7.2f, 7.2f, 0f, false, true, 10f, 0f)
                moveTo(9.8f, 16.4f)
                arcToRelative(3.5f, 3.5f, 0f, false, true, 4.4f, 0f)
            }
            path(fill = SolidColor(PcBlue)) {
                moveTo(12f, 19.1f)
                arcToRelative(1.4f, 1.4f, 0f, true, true, 0.01f, 0f)
                close()
            }
        }
    }

    val Qr: ImageVector by lazy {
        material("Qr") {
            path(fill = SolidColor(PcBlue)) {
                roundRect(2.5f, 2.5f, 10.2f, 10.2f, 1.2f)
            }
            path(fill = SolidColor(Color.Black)) {
                roundRect(4.3f, 4.3f, 8.4f, 8.4f, 0.6f)
            }
            path(fill = SolidColor(PcQrRed)) {
                roundRect(13.8f, 2.5f, 21.5f, 10.2f, 1.2f)
            }
            path(fill = SolidColor(Color.Black)) {
                roundRect(15.6f, 4.3f, 19.7f, 8.4f, 0.6f)
            }
            path(fill = SolidColor(PcBlue)) {
                roundRect(2.5f, 13.8f, 10.2f, 21.5f, 1.2f)
            }
            path(fill = SolidColor(Color.Black)) {
                roundRect(4.3f, 15.6f, 8.4f, 19.7f, 0.6f)
            }
            path(fill = SolidColor(Color.White)) {
                roundRect(13.8f, 13.8f, 16.6f, 16.6f, 0.4f)
                roundRect(17.8f, 13.8f, 21.5f, 16.6f, 0.4f)
                roundRect(13.8f, 17.8f, 16.6f, 21.5f, 0.4f)
                roundRect(18.6f, 17.8f, 21.5f, 19.6f, 0.3f)
                roundRect(17.4f, 19.8f, 19.4f, 21.5f, 0.3f)
            }
        }
    }

    val Lightning: ImageVector by lazy {
        material("Lightning") {
            path(fill = SolidColor(Color.White)) {
                moveTo(13.2f, 2f)
                lineTo(4.8f, 13.4f)
                horizontalLineTo(11.4f)
                lineTo(10.4f, 22f)
                lineTo(19.4f, 10f)
                horizontalLineTo(12.6f)
                close()
            }
        }
    }

    val HistoryClock: ImageVector by lazy {
        material("HistoryClock") {
            path(
                stroke = SolidColor(PcBlue),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(5f, 8.2f)
                verticalLineTo(12f)
                horizontalLineTo(8.6f)
                moveTo(5.2f, 12f)
                arcToRelative(6.8f, 6.8f, 0f, true, false, 1.8f, -4.6f)
            }
            path(
                stroke = SolidColor(PcBlue),
                strokeLineWidth = 1.6f,
                strokeLineCap = StrokeCap.Round
            ) {
                moveTo(12f, 8.8f)
                verticalLineTo(12.2f)
                lineTo(14.4f, 13.7f)
            }
        }
    }

    val Trash: ImageVector by lazy {
        material("Trash") {
            path(
                stroke = SolidColor(PcBlue),
                strokeLineWidth = 1.7f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(5f, 7f)
                horizontalLineTo(19f)
                moveTo(9.2f, 7f)
                verticalLineTo(5.2f)
                horizontalLineTo(14.8f)
                verticalLineTo(7f)
                moveTo(8f, 7f)
                verticalLineTo(18.6f)
                curveTo(8f, 19.6f, 8.8f, 20.4f, 9.8f, 20.4f)
                horizontalLineTo(14.2f)
                curveTo(15.2f, 20.4f, 16f, 19.6f, 16f, 18.6f)
                verticalLineTo(7f)
            }
        }
    }
}

private fun material(
    name: String,
    block: ImageVector.Builder.() -> Unit
): ImageVector = ImageVector.Builder(
    name = name,
    defaultWidth = 24.dp,
    defaultHeight = 24.dp,
    viewportWidth = 24f,
    viewportHeight = 24f
).apply(block).build()

private fun androidx.compose.ui.graphics.vector.PathBuilder.roundRect(
    left: Float,
    top: Float,
    right: Float,
    bottom: Float,
    r: Float
) {
    moveTo(left + r, top)
    lineTo(right - r, top)
    arcToRelative(r, r, 0f, false, true, r, r)
    lineTo(right, bottom - r)
    arcToRelative(r, r, 0f, false, true, -r, r)
    lineTo(left + r, bottom)
    arcToRelative(r, r, 0f, false, true, -r, -r)
    lineTo(left, top + r)
    arcToRelative(r, r, 0f, false, true, r, -r)
    close()
}
