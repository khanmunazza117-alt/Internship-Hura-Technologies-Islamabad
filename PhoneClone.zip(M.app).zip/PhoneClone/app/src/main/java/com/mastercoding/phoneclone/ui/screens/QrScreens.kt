package com.mastercoding.phoneclone.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.model.QrPayload
import com.mastercoding.phoneclone.transfer.TransferService
import com.mastercoding.phoneclone.transfer.TransferState
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.components.ScannerCorners
import com.mastercoding.phoneclone.ui.components.ScreenHeader
import com.mastercoding.phoneclone.ui.theme.PcBlue
import com.mastercoding.phoneclone.ui.theme.PcText
import com.mastercoding.phoneclone.util.PermissionSets
import com.mastercoding.phoneclone.util.QrBitmaps
import kotlinx.serialization.json.Json
import java.util.concurrent.Executors

@Composable
fun QrDisplayScreen(
    onBack: () -> Unit,
    onTransferring: () -> Unit
) {
    val context = LocalContext.current
    val state by TransferService.snapshot.collectAsState()
    val nearbyLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { TransferService.receive(context) }

    LaunchedEffect(Unit) {
        if (PermissionSets.granted(context, PermissionSets.nearby())) {
            TransferService.receive(context)
        } else {
            nearbyLauncher.launch(PermissionSets.nearby())
        }
    }

    LaunchedEffect(state) {
        if (state is TransferState.Transferring || state is TransferState.Completed) {
            onTransferring()
        }
    }

    DisposableEffect(Unit) {
        onDispose { }
    }

    val qrJson = (state as? TransferState.Waiting)?.qrJson
    var bitmap by remember(qrJson) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(qrJson) {
        bitmap = qrJson?.let { QrBitmaps.generate(it) }
    }

    PcScreen {
        Box(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ScreenHeader(stringResource(R.string.new_phone), stringResource(R.string.new_phone_wait), onBack)
                Spacer(Modifier.weight(1f))
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap!!.asImageBitmap(),
                        contentDescription = stringResource(R.string.cd_qr),
                        modifier = Modifier
                            .size(260.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                } else {
                    Text(stringResource(R.string.preparing_connection), color = PcText, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(28.dp))
                Text(
                    stringResource(R.string.qr_hint),
                    color = PcText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
                Spacer(Modifier.weight(1f))
            }
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(22.dp)
                    .size(58.dp)
                    .clip(CircleShape)
                    .background(PcBlue)
                    .clickable { TransferService.receive(context) },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_lightening_bolt),
                    contentDescription = stringResource(R.string.cd_refresh),
                    tint = Color.Unspecified,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

@Composable
fun QrScannerScreen(
    onBack: () -> Unit,
    onScanned: (QrPayload) -> Unit
) {
    val context = LocalContext.current
    var hasCamera by remember { mutableStateOf(PermissionSets.granted(context, PermissionSets.camera())) }
    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasCamera = granted }

    LaunchedEffect(Unit) {
        if (!hasCamera) cameraLauncher.launch(android.Manifest.permission.CAMERA)
    }

    var handled by remember { mutableStateOf(false) }
    val json = remember { Json { ignoreUnknownKeys = true } }

    PcScreen {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            ScreenHeader(stringResource(R.string.scan_qr), stringResource(R.string.scan_qr_subtitle), onBack)
            if (hasCamera) {
                CameraPreview(
                    modifier = Modifier.fillMaxSize(),
                    onQr = { raw ->
                        if (handled) return@CameraPreview
                        runCatching { json.decodeFromString<QrPayload>(raw) }.getOrNull()?.let {
                            handled = true
                            onScanned(it)
                        }
                    }
                )
            }
            ScannerCorners(
                Modifier
                    .align(Alignment.Center)
                    .size(240.dp)
            )
        }
    }
}

@androidx.annotation.OptIn(ExperimentalGetImage::class)
@Composable
private fun CameraPreview(modifier: Modifier, onQr: (String) -> Unit) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    val executor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) {
        onDispose { executor.shutdown() }
    }
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }
            val future = ProcessCameraProvider.getInstance(ctx)
            future.addListener({
                val provider = future.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val scanner = BarcodeScanning.getClient()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media == null) {
                        proxy.close()
                        return@setAnalyzer
                    }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    scanner.process(image)
                        .addOnSuccessListener { codes ->
                            codes.firstOrNull { it.format == Barcode.FORMAT_QR_CODE }
                                ?.rawValue
                                ?.let(onQr)
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                runCatching {
                    provider.unbindAll()
                    provider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        analysis
                    )
                }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        }
    )
}
