package com.mastercoding.phoneclone.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.ui.CloneViewModel
import com.mastercoding.phoneclone.ui.components.MoreRow
import com.mastercoding.phoneclone.ui.components.PcProgressBar
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.components.SectionLabel
import com.mastercoding.phoneclone.ui.components.TileCard
import com.mastercoding.phoneclone.ui.icons.PcIcons
import com.mastercoding.phoneclone.ui.theme.PcBlue
import com.mastercoding.phoneclone.ui.theme.PcText
import com.mastercoding.phoneclone.ui.theme.PcTextDim
import com.mastercoding.phoneclone.util.Formatters

private val HomeCard = Color(0xFF232323)

@Composable
fun HomeScreen(
    vm: CloneViewModel,
    onOldPhone: () -> Unit,
    onNewPhone: () -> Unit,
    onHistory: () -> Unit,
    onLanguage: () -> Unit,
    onPrivacy: () -> Unit,
    onShare: () -> Unit,
    onRate: () -> Unit
) {
    val storage by vm.storage.collectAsState()
    val usedRatio = if (storage.totalBytes == 0L) 0f else storage.usedBytes.toFloat() / storage.totalBytes
    val context = LocalContext.current
    val lineDesc = stringResource(R.string.line_description)

    PcScreen {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                // Figma: storage 667×237, tiles 329×115 r26, more 667×127 r19
                val scale = maxWidth / 667.dp
                val storageHeight = 237.dp * scale
                val tileHeight = 115.dp * scale
                val moreHeight = 127.dp * scale
                val tileRadius = 26.dp * scale
                val moreRadius = 19.dp * scale
                val tileGap = 9.dp * scale

                Column(Modifier.fillMaxWidth()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.phone_clone),
                    color = PcText,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    lineDesc,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp)
                )

                val storageShape = RoundedCornerShape(tileRadius)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(storageHeight)
                        .clip(storageShape)
                        .background(HomeCard)
                        .border(1.dp, PcBlue, storageShape)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(R.drawable.sync_phone),
                        contentDescription = stringResource(R.string.cd_storage),
                        tint = Color.Unspecified,
                        modifier = Modifier.size(storageHeight * 0.48f)
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.storage), color = PcText, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            Formatters.storageLine(context, storage.usedBytes, storage.totalBytes),
                            color = PcTextDim,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                        )
                        PcProgressBar(usedRatio)
                    }
                }

                SectionLabel(stringResource(R.string.section_phone_clone), stringResource(R.string.section_transfer_desc))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(tileGap)
                ) {
                    TileCard(
                        icon = painterResource(R.drawable.old_phone),
                        title = stringResource(R.string.old_phone),
                        subtitle = lineDesc,
                        iconSize = tileHeight * 0.42f,
                        corner = tileRadius,
                        modifier = Modifier.weight(1f).height(tileHeight),
                        onClick = onOldPhone
                    )
                    TileCard(
                        icon = painterResource(R.drawable.new_phone),
                        title = stringResource(R.string.new_phone),
                        subtitle = lineDesc,
                        iconSize = tileHeight * 0.42f,
                        corner = tileRadius,
                        modifier = Modifier.weight(1f).height(tileHeight),
                        onClick = onNewPhone
                    )
                }

                SectionLabel(stringResource(R.string.section_tools), stringResource(R.string.section_transfer_desc))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(tileGap)
                ) {
                    TileCard(
                        icon = painterResource(R.drawable.ic_history),
                        title = stringResource(R.string.history),
                        subtitle = lineDesc,
                        iconSize = tileHeight * 0.42f,
                        corner = tileRadius,
                        modifier = Modifier.weight(1f).height(tileHeight),
                        onClick = onHistory
                    )
                    TileCard(
                        icon = painterResource(R.drawable.ic_language),
                        title = stringResource(R.string.language),
                        subtitle = lineDesc,
                        iconSize = tileHeight * 0.42f,
                        corner = tileRadius,
                        modifier = Modifier.weight(1f).height(tileHeight),
                        onClick = onLanguage
                    )
                }

                SectionLabel(stringResource(R.string.section_more), "")
                Column(
                    Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MoreRow(
                        icon = painterResource(R.drawable.ic_privacy),
                        title = stringResource(R.string.privacy_policy),
                        subtitle = lineDesc,
                        modifier = Modifier.height(moreHeight),
                        corner = moreRadius,
                        onClick = onPrivacy
                    )
                    MoreRow(
                        icon = rememberVectorPainter(PcIcons.Share),
                        title = stringResource(R.string.share_app),
                        subtitle = lineDesc,
                        modifier = Modifier.height(moreHeight),
                        corner = moreRadius,
                        onClick = onShare
                    )
                    MoreRow(
                        icon = painterResource(R.drawable.ic_rate_us),
                        title = stringResource(R.string.rate_us),
                        subtitle = lineDesc,
                        modifier = Modifier.height(moreHeight),
                        corner = moreRadius,
                        onClick = onRate
                    )
                }
            }
            }
        }
    }
}
