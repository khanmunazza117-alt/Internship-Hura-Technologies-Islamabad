package com.mastercoding.phoneclone.transfer

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.mastercoding.phoneclone.model.FileMeta
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.Socket

object TransferProtocol {
    const val PORT = 19888
    const val NSD_TYPE = "_phoneclone._tcp."
    const val MAGIC = 0x50433031 // PC01
    const val HELLO = 1
    const val HELLO_ACK = 2
    const val FILE_META = 3
    const val FILE_ACK = 4
    const val DONE = 5
    const val ERROR = 6
    const val BUFFER = 64 * 1024

    val json = Json { ignoreUnknownKeys = true }

    fun writeFrame(out: DataOutputStream, type: Int, payload: ByteArray = ByteArray(0)) {
        out.writeInt(MAGIC)
        out.writeByte(type)
        out.writeInt(payload.size)
        if (payload.isNotEmpty()) out.write(payload)
        out.flush()
    }

    fun writeJson(out: DataOutputStream, type: Int, value: String) {
        writeFrame(out, type, value.toByteArray(Charsets.UTF_8))
    }

    fun readFrame(input: DataInputStream): Pair<Int, ByteArray> {
        val magic = input.readInt()
        if (magic != MAGIC) error("Invalid protocol")
        val type = input.readUnsignedByte()
        val len = input.readInt()
        require(len in 0..8_000_000) { "Invalid frame" }
        val bytes = ByteArray(len)
        if (len > 0) input.readFully(bytes)
        return type to bytes
    }
}

class FileStreamer(
    private val context: Context,
    private val onProgress: (copied: Long, fileSize: Long) -> Unit
) {
    fun sendStream(output: OutputStream, input: InputStream, size: Long) {
        val buf = ByteArray(TransferProtocol.BUFFER)
        var copied = 0L
        var remaining = size
        while (remaining > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
            if (n <= 0) break
            output.write(buf, 0, n)
            copied += n
            remaining -= n
            onProgress(copied, size)
        }
        output.flush()
    }

    fun receiveToSink(input: InputStream, output: OutputStream, size: Long) {
        val buf = ByteArray(TransferProtocol.BUFFER)
        var copied = 0L
        var remaining = size
        while (remaining > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
            if (n <= 0) break
            output.write(buf, 0, n)
            copied += n
            remaining -= n
            onProgress(copied, size)
        }
        output.flush()
    }

    fun openIncoming(meta: FileMeta): Pair<OutputStream, () -> Unit> {
        val resolver = context.contentResolver
        val safeName = meta.name.ifBlank { "file_${System.currentTimeMillis()}" }
        when (meta.category) {
            "PHOTOS" -> {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                    put(MediaStore.Images.Media.MIME_TYPE, meta.mime.ifBlank { "image/jpeg" })
                    if (Build.VERSION.SDK_INT >= 29) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PhoneClone")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                }
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Cannot save photo")
                val stream = resolver.openOutputStream(uri) ?: error("Cannot open photo")
                return stream to {
                    if (Build.VERSION.SDK_INT >= 29) {
                        values.clear()
                        values.put(MediaStore.Images.Media.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    }
                }
            }
            "VIDEOS" -> {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, safeName)
                    put(MediaStore.Video.Media.MIME_TYPE, meta.mime.ifBlank { "video/mp4" })
                    if (Build.VERSION.SDK_INT >= 29) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/PhoneClone")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Cannot save video")
                val stream = resolver.openOutputStream(uri) ?: error("Cannot open video")
                return stream to {
                    if (Build.VERSION.SDK_INT >= 29) {
                        values.clear()
                        values.put(MediaStore.Video.Media.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    }
                }
            }
            "AUDIOS" -> {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, safeName)
                    put(MediaStore.Audio.Media.MIME_TYPE, meta.mime.ifBlank { "audio/mpeg" })
                    if (Build.VERSION.SDK_INT >= 29) {
                        put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/PhoneClone")
                        put(MediaStore.Audio.Media.IS_PENDING, 1)
                    }
                }
                val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Cannot save audio")
                val stream = resolver.openOutputStream(uri) ?: error("Cannot open audio")
                return stream to {
                    if (Build.VERSION.SDK_INT >= 29) {
                        values.clear()
                        values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    }
                }
            }
            else -> {
                val dirName = if (meta.category == "APPS") "PhoneClone/Apps" else "PhoneClone"
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, meta.mime.ifBlank { "application/octet-stream" })
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/$dirName")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: error("Cannot save file")
                    val stream = resolver.openOutputStream(uri) ?: error("Cannot open file")
                    return stream to {
                        values.clear()
                        values.put(MediaStore.Downloads.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    }
                } else {
                    val dir = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        dirName
                    )
                    if (!dir.exists()) dir.mkdirs()
                    val file = File(dir, safeName)
                    return file.outputStream() to {}
                }
            }
        }
    }
}

fun Socket.streams(): Pair<DataInputStream, DataOutputStream> {
    tcpNoDelay = true
    keepAlive = true
    return DataInputStream(getInputStream().buffered()) to DataOutputStream(getOutputStream().buffered())
}

fun encodeJson(meta: FileMeta): String = TransferProtocol.json.encodeToString(meta)
fun decodeMeta(bytes: ByteArray): FileMeta =
    TransferProtocol.json.decodeFromString(String(bytes, Charsets.UTF_8))
