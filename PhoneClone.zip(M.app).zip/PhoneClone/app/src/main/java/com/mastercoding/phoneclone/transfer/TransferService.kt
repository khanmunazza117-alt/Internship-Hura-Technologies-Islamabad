package com.mastercoding.phoneclone.transfer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.mastercoding.phoneclone.model.FileMeta
import com.mastercoding.phoneclone.model.MediaItem
import com.mastercoding.phoneclone.model.QrPayload
import com.mastercoding.phoneclone.model.TransferRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.FileInputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID

sealed class TransferState {
    data object Idle : TransferState()
    data class Waiting(
        val qrJson: String,
        val payload: QrPayload
    ) : TransferState()

    data class Connecting(val message: String) : TransferState()
    data class Transferring(
        val role: TransferRole,
        val currentFile: String,
        val index: Int,
        val total: Int,
        val overall: Float,
        val bytesDone: Long,
        val bytesTotal: Long
    ) : TransferState()

    data class Completed(val fileCount: Int, val sent: Boolean, val bytes: Long) : TransferState()
    data class Failed(val message: String) : TransferState()
}

object TransferSession {
    var pendingFiles: List<MediaItem> = emptyList()
    var qrPayload: QrPayload? = null
}

class TransferService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var server: ServerSocket? = null
    private var client: Socket? = null
    private val hotspot by lazy { HotspotController(this) }
    private val nsd by lazy { NsdPublisher(this) }
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        startInForeground("Phone Clone is ready")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RECEIVE -> startReceiver()
            ACTION_SEND_WIFI -> startSender(useQr = false)
            ACTION_SEND_QR -> startSender(useQr = true)
            ACTION_CANCEL -> {
                failOrCancel("Transfer cancelled")
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startReceiver() {
        job?.cancel()
        job = scope.launch {
            try {
                state.value = TransferState.Connecting("Preparing new phone…")
                val key = UUID.randomUUID().toString().take(8)
                val socket = ServerSocket(TransferProtocol.PORT).also { server = it }
                nsd.register("PhoneClone-$key", TransferProtocol.PORT)

                fun publish(ssid: String?, pass: String?) {
                    val payload = QrPayload(
                        ip = NetworkHelper.localIpv4(),
                        port = TransferProtocol.PORT,
                        key = key,
                        name = NetworkHelper.deviceName(),
                        ssid = ssid,
                        pass = pass
                    )
                    state.value = TransferState.Waiting(json.encodeToString(payload), payload)
                }
                publish(null, null)
                hotspot.start { ssid, pass -> publish(ssid, pass) }

                val remote = socket.accept().also { client = it }
                handleIncoming(remote, key)
            } catch (e: Exception) {
                if (state.value !is TransferState.Completed) {
                    state.value = TransferState.Failed(e.message ?: "Receive failed")
                }
            } finally {
                cleanupNet()
            }
        }
    }

    private fun startSender(useQr: Boolean) {
        job?.cancel()
        job = scope.launch {
            try {
                val files = TransferSession.pendingFiles
                if (files.isEmpty()) {
                    state.value = TransferState.Failed("No files selected")
                    return@launch
                }
                state.value = TransferState.Connecting(
                    if (useQr) "Connecting with QR…" else "Searching for new phone…"
                )
                val target = if (useQr) {
                    val payload = TransferSession.qrPayload ?: error("Invalid QR")
                    if (!payload.ssid.isNullOrBlank() && !payload.pass.isNullOrBlank()) {
                        runCatching { bindToHotspot(this@TransferService, payload.ssid, payload.pass) }
                    }
                    payload.ip to payload.port
                } else {
                    NsdFinder(this@TransferService).find()
                }
                val socket = Socket()
                socket.connect(InetSocketAddress(target.first, target.second), 12_000)
                client = socket
                sendAll(socket, files, TransferSession.qrPayload?.key.orEmpty())
            } catch (e: Exception) {
                if (state.value !is TransferState.Completed) {
                    state.value = TransferState.Failed(e.message ?: "Send failed")
                }
            } finally {
                unbindNetwork(this@TransferService)
                cleanupNet()
            }
        }
    }

    private fun handleIncoming(socket: Socket, expectedKey: String) {
        val (input, output) = socket.streams()
        val (type, payload) = TransferProtocol.readFrame(input)
        if (type != TransferProtocol.HELLO) error("Unexpected hello")
        val hello = json.decodeFromString<Hello>(String(payload, Charsets.UTF_8))
        if (hello.key.isNotBlank() && hello.key != expectedKey) error("Session mismatch")
        TransferProtocol.writeJson(output, TransferProtocol.HELLO_ACK, json.encodeToString(HelloAck(true, NetworkHelper.deviceName())))

        val streamer = FileStreamer(this) { copied, _ ->
            val current = state.value
            if (current is TransferState.Transferring) {
                val done = lastFileCopied + copied
                state.value = current.copy(
                    overall = if (current.bytesTotal == 0L) 0f else done.toFloat() / current.bytesTotal,
                    bytesDone = done
                )
            }
        }
        var received = 0
        var bytes = 0L
        val totalFiles = hello.fileCount.coerceAtLeast(1)
        val totalBytes = hello.totalBytes.coerceAtLeast(1)
        lastFileCopied = 0L
        while (true) {
            val (kind, body) = TransferProtocol.readFrame(input)
            when (kind) {
                TransferProtocol.FILE_META -> {
                    val meta = decodeMeta(body)
                    received += 1
                    lastFileCopied = bytes
                    state.value = TransferState.Transferring(
                        role = TransferRole.RECEIVER,
                        currentFile = meta.name,
                        index = received,
                        total = totalFiles,
                        overall = bytes.toFloat() / totalBytes,
                        bytesDone = bytes,
                        bytesTotal = totalBytes
                    )
                    val (outStream, finish) = streamer.openIncoming(meta)
                    outStream.use { sink ->
                        streamer.receiveToSink(input, sink, meta.size)
                    }
                    finish()
                    bytes += meta.size
                    TransferProtocol.writeJson(output, TransferProtocol.FILE_ACK, meta.id)
                }
                TransferProtocol.DONE -> {
                    state.value = TransferState.Completed(received, sent = false, bytes = bytes)
                    return
                }
                TransferProtocol.ERROR -> error(String(body, Charsets.UTF_8))
                else -> error("Unexpected frame")
            }
        }
    }

    @Volatile private var lastFileCopied = 0L

    private fun sendAll(socket: Socket, files: List<MediaItem>, key: String) {
        val (input, output) = socket.streams()
        val totalBytes = files.sumOf { it.size.coerceAtLeast(0) }
        TransferProtocol.writeJson(
            output,
            TransferProtocol.HELLO,
            json.encodeToString(Hello(key, NetworkHelper.deviceName(), files.size, totalBytes))
        )
        val (ackType, _) = TransferProtocol.readFrame(input)
        if (ackType != TransferProtocol.HELLO_ACK) error("Receiver rejected the session")

        val streamer = FileStreamer(this) { copied, _ ->
            val current = state.value
            if (current is TransferState.Transferring) {
                val done = lastFileCopied + copied
                state.value = current.copy(
                    overall = if (current.bytesTotal == 0L) 0f else done.toFloat() / current.bytesTotal,
                    bytesDone = done
                )
            }
        }
        var sentBytes = 0L
        files.forEachIndexed { index, item ->
            lastFileCopied = sentBytes
            state.value = TransferState.Transferring(
                role = TransferRole.SENDER,
                currentFile = item.name,
                index = index + 1,
                total = files.size,
                overall = if (totalBytes == 0L) 0f else sentBytes.toFloat() / totalBytes,
                bytesDone = sentBytes,
                bytesTotal = totalBytes
            )
            val meta = FileMeta(
                id = item.id,
                name = item.name,
                size = item.size,
                mime = item.mime,
                category = item.category.name
            )
            TransferProtocol.writeJson(output, TransferProtocol.FILE_META, encodeJson(meta))
            val source = when {
                item.uri != null -> contentResolver.openInputStream(item.uri)
                !item.filePath.isNullOrBlank() -> FileInputStream(item.filePath)
                else -> null
            } ?: error("Cannot open ${item.name}")
            source.use { streamer.sendStream(output, it, item.size) }
            val (kind, _) = TransferProtocol.readFrame(input)
            if (kind != TransferProtocol.FILE_ACK) error("Receiver failed on ${item.name}")
            sentBytes += item.size
        }
        TransferProtocol.writeFrame(output, TransferProtocol.DONE)
        state.value = TransferState.Completed(files.size, sent = true, bytes = sentBytes)
    }

    private fun failOrCancel(message: String) {
        job?.cancel()
        cleanupNet()
        if (state.value !is TransferState.Completed) {
            state.value = TransferState.Failed(message)
        }
    }

    private fun cleanupNet() {
        runCatching { client?.close() }
        runCatching { server?.close() }
        client = null
        server = null
        nsd.unregister()
        hotspot.stop()
    }

    override fun onDestroy() {
        failOrCancel("Stopped")
        scope.cancel()
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Transfers", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun startInForeground(text: String) {
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Phone Clone")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(71, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(71, notification)
        }
    }

    @kotlinx.serialization.Serializable
    private data class Hello(
        val key: String,
        val name: String,
        val fileCount: Int,
        val totalBytes: Long
    )

    @kotlinx.serialization.Serializable
    private data class HelloAck(val ok: Boolean, val name: String)

    companion object {
        const val ACTION_RECEIVE = "receive"
        const val ACTION_SEND_WIFI = "send_wifi"
        const val ACTION_SEND_QR = "send_qr"
        const val ACTION_CANCEL = "cancel"
        private const val CHANNEL = "phone_clone_transfer"

        val state: MutableStateFlow<TransferState> = MutableStateFlow(TransferState.Idle)
        val snapshot: StateFlow<TransferState> = state

        fun receive(context: Context) = start(context, ACTION_RECEIVE)
        fun sendWifi(context: Context, files: List<MediaItem>) {
            TransferSession.pendingFiles = files
            start(context, ACTION_SEND_WIFI)
        }
        fun sendQr(context: Context, files: List<MediaItem>, payload: QrPayload) {
            TransferSession.pendingFiles = files
            TransferSession.qrPayload = payload
            start(context, ACTION_SEND_QR)
        }
        fun cancel(context: Context) = start(context, ACTION_CANCEL)

        fun reset() {
            state.value = TransferState.Idle
        }

        private fun start(context: Context, action: String) {
            val intent = Intent(context, TransferService::class.java).setAction(action)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }
}
