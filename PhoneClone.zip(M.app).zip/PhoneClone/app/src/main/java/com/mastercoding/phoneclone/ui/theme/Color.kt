package com.mastercoding.phoneclone.ui.theme

import androidx.compose.ui.graphics.Color

val PcBlack = Color(0xFF000000)
val PcCard = Color(0xFF1C1C1E)
val PcCardAlt = Color(0xFF1C1C1E)
val PcBlue = Color(0xFF2196F3)
val PcBlueDark = Color(0xFF1565C0)
val PcText = Color(0xFFFFFFFF)
val PcTextDim = Color(0xFF9E9E9E)
val PcTextMuted = Color(0xFFBDBDBD)
val PcTrack = Color(0xFF3A3A3C)
val PcIconBg = Color(0xFF1A1A1A)
val PcQrRed = Color(0xFFE53935)
