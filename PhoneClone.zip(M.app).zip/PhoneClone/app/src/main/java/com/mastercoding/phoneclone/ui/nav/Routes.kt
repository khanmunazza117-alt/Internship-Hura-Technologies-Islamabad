package com.mastercoding.phoneclone.ui.nav

object Routes {
    const val Splash = "splash"
    const val Terms = "terms"
    const val Home = "home"
    const val SelectFile = "select_file"
    const val Category = "category/{category}"
    const val SelectMethod = "select_method"
    const val QrDisplay = "qr_display"
    const val QrScanner = "qr_scanner"
    const val Transfer = "transfer"
    const val History = "history"
    const val Language = "language"
    const val Privacy = "privacy"

    fun category(name: String) = "category/$name"
}
