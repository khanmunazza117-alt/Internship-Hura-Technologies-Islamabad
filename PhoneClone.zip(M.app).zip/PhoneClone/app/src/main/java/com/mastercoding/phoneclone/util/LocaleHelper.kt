package com.mastercoding.phoneclone.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

object LocaleHelper {
    private const val PREFS = "phone_clone_locale"
    private const val KEY_TAG = "language_tag"

    private fun prefs(context: Context) =
        (context.applicationContext ?: context)
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getTag(context: Context): String {
        return prefs(context).getString(KEY_TAG, "en") ?: "en"
    }

    fun persist(context: Context, tag: String) {
        prefs(context).edit().putString(KEY_TAG, tag).apply()
    }

    fun localeFor(tag: String): Locale {
        return when (tag) {
            "zh" -> Locale.SIMPLIFIED_CHINESE
            else -> Locale.forLanguageTag(tag)
        }
    }

    fun wrap(context: Context, tag: String = getTag(context)): Context {
        val locale = localeFor(tag)
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        if (Build.VERSION.SDK_INT >= 24) {
            config.setLocale(locale)
            config.setLocales(LocaleList(locale))
        } else {
            @Suppress("DEPRECATION")
            config.locale = locale
        }
        return context.createConfigurationContext(config)
    }

    fun findActivity(context: Context): Activity? {
        var ctx: Context? = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return ctx as? Activity
    }

    fun apply(context: Context, tag: String) {
        persist(context, tag)
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
        findActivity(context)?.recreate()
    }
}
