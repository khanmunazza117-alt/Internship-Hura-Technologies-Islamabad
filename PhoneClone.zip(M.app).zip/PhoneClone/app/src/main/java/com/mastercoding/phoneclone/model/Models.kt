package com.mastercoding.phoneclone.model

import android.net.Uri
import kotlinx.serialization.Serializable

enum class FileCategory {
    PHOTOS, VIDEOS, AUDIOS, DOCUMENTS, APPS;

    val isGrid: Boolean get() = this == PHOTOS || this == VIDEOS

    val titleRes: Int
        get() = when (this) {
            PHOTOS -> com.mastercoding.phoneclone.R.string.cat_photos
            VIDEOS -> com.mastercoding.phoneclone.R.string.cat_videos
            AUDIOS -> com.mastercoding.phoneclone.R.string.cat_audios
            DOCUMENTS -> com.mastercoding.phoneclone.R.string.cat_documents
            APPS -> com.mastercoding.phoneclone.R.string.cat_apps
        }

    val subtitleRes: Int
        get() = when (this) {
            PHOTOS -> com.mastercoding.phoneclone.R.string.cat_photos_sub
            VIDEOS -> com.mastercoding.phoneclone.R.string.cat_videos_sub
            AUDIOS -> com.mastercoding.phoneclone.R.string.cat_audios_sub
            DOCUMENTS -> com.mastercoding.phoneclone.R.string.cat_documents_sub
            APPS -> com.mastercoding.phoneclone.R.string.cat_apps_sub
        }
}

data class MediaItem(
    val id: String,
    val name: String,
    val size: Long,
    val mime: String,
    val category: FileCategory,
    val uri: Uri? = null,
    val filePath: String? = null,
    val dateAdded: Long = 0L,
    val packageName: String? = null
)

data class CategorySummary(
    val category: FileCategory,
    val count: Int,
    val bytes: Long
)

data class StorageInfo(
    val usedBytes: Long,
    val totalBytes: Long
)

@Serializable
data class HistoryEntry(
    val id: String,
    val fileCount: Int,
    val dateMillis: Long,
    val sent: Boolean,
    val totalBytes: Long = 0L
)

@Serializable
data class QrPayload(
    val v: Int = 1,
    val ip: String,
    val port: Int,
    val key: String,
    val name: String,
    val ssid: String? = null,
    val pass: String? = null
)

@Serializable
data class FileMeta(
    val id: String,
    val name: String,
    val size: Long,
    val mime: String,
    val category: String
)

enum class TransferRole { SENDER, RECEIVER }

enum class TransferMode { WIFI, QR }
