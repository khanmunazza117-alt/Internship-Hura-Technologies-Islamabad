package com.mastercoding.phoneclone.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.ui.theme.PcBlack
import com.mastercoding.phoneclone.ui.theme.PcBlue
import com.mastercoding.phoneclone.ui.theme.PcCard
import com.mastercoding.phoneclone.ui.theme.PcText
import com.mastercoding.phoneclone.ui.theme.PcTextDim

val CardShape = RoundedCornerShape(16.dp)
val PillShape = RoundedCornerShape(28.dp)

@Composable
fun PcScreen(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(PcBlack)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            content()
        }
    }
}

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)? = null
) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp)
            .height(64.dp)
    ) {
        if (onBack != null) {
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .size(48.dp)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_back_btn),
                    contentDescription = stringResource(R.string.cd_back),
                    modifier = Modifier.size(26.dp),
                    contentScale = ContentScale.Fit
                )
            }
        }
        Column(
            Modifier.align(Alignment.Center).padding(horizontal = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                title,
                color = PcText,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.6.sp,
                textAlign = TextAlign.Center
            )
            if (subtitle.isNotBlank()) {
                Text(
                    subtitle,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 0.3.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun PcPrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier
            .height(52.dp)
            .clip(PillShape)
            .background(if (enabled) PcBlue else PcBlue.copy(alpha = 0.4f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun PcOutlineButton(
    text: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier
            .height(52.dp)
            .clip(PillShape)
            .border(1.5.dp, PcBlue, PillShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}

@Composable
fun PcFilledPillButton(
    text: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier
            .height(52.dp)
            .clip(PillShape)
            .background(PcBlue)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}

@Composable
fun CheckCircle(selected: Boolean, size: Dp = 22.dp, uncheckedColor: Color = Color.White) {
    Image(
        painter = painterResource(
            if (selected) R.drawable.ic_check_circle else R.drawable.empty_circle
        ),
        contentDescription = if (selected) "Selected" else "Not selected",
        modifier = Modifier.size(size),
        contentScale = ContentScale.Fit
    )
}

@Composable
fun SelectAllChip(selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) PcBlue else PcCard)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            stringResource(R.string.select_all),
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.4.sp
        )
        Spacer(Modifier.width(8.dp))
        CheckCircle(selected = selected, size = 18.dp, uncheckedColor = Color.White)
    }
}

@Composable
fun SectionLabel(title: String, description: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 18.dp, bottom = 10.dp)
    ) {
        Text(
            title,
            color = PcText,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.4.sp
        )
        if (description.isNotBlank()) {
            Text(
                description,
                color = Color.White,
                fontSize = 9.sp,
                fontWeight = FontWeight.Normal,
                letterSpacing = 0.2.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun TileCard(
    icon: Painter,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    iconSize: Dp = 34.dp,
    corner: Dp = 16.dp,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(corner)
    Row(
        modifier
            .clip(shape)
            .background(Color(0xFF232323))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = icon,
            contentDescription = title,
            tint = Color.Unspecified,
            modifier = Modifier.size(iconSize)
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = PcText,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                subtitle,
                color = PcTextDim,
                fontSize = 8.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun MoreRow(
    icon: Painter,
    title: String,
    subtitle: String = "",
    modifier: Modifier = Modifier,
    corner: Dp = 16.dp,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(corner)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xFF232323))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = icon,
            contentDescription = title,
            tint = Color.Unspecified,
            modifier = Modifier.size(30.dp)
        )
        Spacer(Modifier.width(14.dp))
        Column {
            Text(
                title,
                color = PcText,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                subtitle,
                color = Color.White,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun CategoryRow(
    selected: Boolean,
    icon: Painter,
    title: String,
    subtitle: String,
    onToggle: () -> Unit,
    onOpen: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(PcCard)
            .clickable(onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.clickable(onClick = onToggle)) {
            CheckCircle(selected = selected, size = 24.dp)
        }
        Spacer(Modifier.width(12.dp))
        Icon(
            painter = icon,
            contentDescription = title,
            tint = Color.Unspecified,
            modifier = Modifier.size(52.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = PcText, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(subtitle, color = Color.White, fontSize = 11.sp)
        }
        Image(
            painter = painterResource(R.drawable.ic_right_arrow),
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
fun FileListCard(
    selected: Boolean,
    title: String,
    onClick: () -> Unit,
    icon: @Composable RowScope.() -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(CardShape)
            .background(PcCard)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CheckCircle(selected = selected, size = 24.dp)
        Spacer(Modifier.width(12.dp))
        icon()
        Spacer(Modifier.width(12.dp))
        Text(
            title.uppercase(),
            color = PcText,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ScannerCorners(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val stroke = 8.dp.toPx()
        val arm = size.minDimension * 0.18f
        val color = PcBlue
        val left = 0f
        val top = 0f
        val right = size.width
        val bottom = size.height
        fun corner(x: Float, y: Float, dx: Float, dy: Float) {
            drawLine(color, Offset(x, y), Offset(x + dx, y), stroke, StrokeCap.Round)
            drawLine(color, Offset(x, y), Offset(x, y + dy), stroke, StrokeCap.Round)
        }
        corner(left, top, arm, arm)
        corner(right, top, -arm, arm)
        corner(left, bottom, arm, -arm)
        corner(right, bottom, -arm, -arm)
        drawRect(Color.Transparent, Offset.Zero, Size(size.width, size.height))
    }
}

@Composable
fun PcProgressBar(progress: Float, modifier: Modifier = Modifier, track: Color = Color(0xFF3A3A3C)) {
    Canvas(
        modifier
            .fillMaxWidth()
            .height(6.dp)
    ) {
        val h = size.height
        drawRoundRect(track, cornerRadius = androidx.compose.ui.geometry.CornerRadius(h))
        drawRoundRect(
            PcBlue,
            size = Size(size.width * progress.coerceIn(0f, 1f), h),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(h)
        )
    }
}
