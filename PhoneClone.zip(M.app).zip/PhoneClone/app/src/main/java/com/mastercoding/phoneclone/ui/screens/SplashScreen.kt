package com.mastercoding.phoneclone.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.ui.components.PcProgressBar
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.theme.PcBlack
import com.mastercoding.phoneclone.ui.theme.PcBlue
import com.mastercoding.phoneclone.ui.theme.PcCard
import com.mastercoding.phoneclone.ui.theme.PcText
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(checkAccepted: suspend () -> Boolean, onFinished: (Boolean) -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(1800))
        delay(250)
        onFinished(checkAccepted())
    }
    PcScreen {
        Box(Modifier.fillMaxSize().background(PcBlack)) {
            Column(
                Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(118.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(PcBlue)
                        .border(8.dp, PcCard, RoundedCornerShape(28.dp))
                )
                Spacer(Modifier.height(22.dp))
                Text(
                    stringResource(R.string.phone_clone),
                    color = PcText,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
            PcProgressBar(
                progress = progress.value,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 36.dp, vertical = 42.dp)
                    .fillMaxWidth()
                    .height(8.dp),
                track = androidx.compose.ui.graphics.Color(0xFF1A3A5C)
            )
        }
    }
}
