package com.mastercoding.phoneclone.data

import android.content.Context
import com.mastercoding.phoneclone.model.HistoryEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

class HistoryStore(context: Context) {
    private val file = File(context.filesDir, "transfer_history.json")
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    private val _entries = MutableStateFlow<List<HistoryEntry>>(emptyList())
    val entries: StateFlow<List<HistoryEntry>> = _entries

    suspend fun load() = withContext(Dispatchers.IO) {
        _entries.value = runCatching {
            if (!file.exists()) emptyList()
            else json.decodeFromString<List<HistoryEntry>>(file.readText())
        }.getOrDefault(emptyList())
    }

    suspend fun add(entry: HistoryEntry) {
        val next = listOf(entry) + _entries.value
        persist(next)
    }

    suspend fun delete(id: String) {
        persist(_entries.value.filterNot { it.id == id })
    }

    private suspend fun persist(list: List<HistoryEntry>) = withContext(Dispatchers.IO) {
        _entries.value = list
        file.writeText(json.encodeToString(list))
    }
}
