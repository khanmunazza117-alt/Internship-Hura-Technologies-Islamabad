package com.mastercoding.phoneclone.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.ui.components.PcFilledPillButton
import com.mastercoding.phoneclone.ui.components.PcOutlineButton
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.components.ScreenHeader
import com.mastercoding.phoneclone.ui.theme.PcTextDim

@Composable
fun TermsScreen(onAccept: () -> Unit, onDecline: () -> Unit) {
    PcScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            ScreenHeader(title = stringResource(R.string.terms_title), subtitle = "")
            Text(
                text = stringResource(R.string.terms_body),
                color = PcTextDim,
                fontSize = 14.sp,
                lineHeight = 22.sp,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(top = 8.dp, bottom = 16.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
            ) {
                PcOutlineButton(
                    text = stringResource(R.string.decline),
                    modifier = Modifier.weight(1f),
                    onClick = onDecline
                )
                Spacer(Modifier.width(14.dp))
                PcFilledPillButton(
                    text = stringResource(R.string.accept),
                    modifier = Modifier.weight(1f),
                    onClick = onAccept
                )
            }
        }
    }
}
