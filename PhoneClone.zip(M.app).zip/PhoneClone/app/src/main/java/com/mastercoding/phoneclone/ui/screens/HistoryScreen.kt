package com.mastercoding.phoneclone.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.ui.CloneViewModel
import com.mastercoding.phoneclone.ui.components.CardShape
import com.mastercoding.phoneclone.ui.components.PcScreen
import com.mastercoding.phoneclone.ui.components.ScreenHeader
import com.mastercoding.phoneclone.ui.theme.PcBlue
import com.mastercoding.phoneclone.ui.theme.PcCard
import com.mastercoding.phoneclone.ui.theme.PcText
import com.mastercoding.phoneclone.ui.theme.PcTextDim
import com.mastercoding.phoneclone.util.Formatters

@Composable
fun HistoryScreen(vm: CloneViewModel, onBack: () -> Unit) {
    val entries by vm.history.collectAsState()
    var sentTab by remember { mutableStateOf(true) }
    val visible = entries.filter { it.sent == sentTab }

    PcScreen {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            ScreenHeader(stringResource(R.string.history), stringResource(R.string.history_subtitle), onBack)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HistoryTab(stringResource(R.string.sent_history), sentTab, Modifier.weight(1f)) { sentTab = true }
                HistoryTab(stringResource(R.string.receive_history), !sentTab, Modifier.weight(1f)) { sentTab = false }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(visible, key = { it.id }) { entry ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(CardShape)
                            .background(PcCard)
                            .padding(horizontal = 14.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_history),
                            contentDescription = null,
                            tint = Color.Unspecified,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                stringResource(
                                    if (entry.sent) R.string.files_sent else R.string.files_received,
                                    entry.fileCount
                                ),
                                color = PcText,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(Formatters.historyDate(entry.dateMillis), color = PcTextDim, fontSize = 12.sp)
                        }
                        Icon(
                            painter = painterResource(R.drawable.trash_bin),
                            contentDescription = stringResource(R.string.delete),
                            tint = Color.Unspecified,
                            modifier = Modifier
                                .size(26.dp)
                                .clickable { vm.deleteHistory(entry.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Text(
        text = label,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) PcBlue else PcCard)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
}
