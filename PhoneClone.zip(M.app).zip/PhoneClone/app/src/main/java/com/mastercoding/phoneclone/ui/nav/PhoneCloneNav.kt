package com.mastercoding.phoneclone.ui.nav

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mastercoding.phoneclone.R
import com.mastercoding.phoneclone.model.FileCategory
import com.mastercoding.phoneclone.transfer.TransferService
import com.mastercoding.phoneclone.ui.CloneViewModel
import com.mastercoding.phoneclone.ui.screens.CategoryDetailScreen
import com.mastercoding.phoneclone.ui.screens.HistoryScreen
import com.mastercoding.phoneclone.ui.screens.HomeScreen
import com.mastercoding.phoneclone.ui.screens.LanguageScreen
import com.mastercoding.phoneclone.ui.screens.PrivacyScreen
import com.mastercoding.phoneclone.ui.screens.QrDisplayScreen
import com.mastercoding.phoneclone.ui.screens.QrScannerScreen
import com.mastercoding.phoneclone.ui.screens.SelectFileScreen
import com.mastercoding.phoneclone.ui.screens.SelectMethodScreen
import com.mastercoding.phoneclone.ui.screens.SplashScreen
import com.mastercoding.phoneclone.ui.screens.TermsScreen
import com.mastercoding.phoneclone.ui.screens.TransferProgressScreen
import kotlinx.coroutines.flow.first

@Composable
fun PhoneCloneNav(vm: CloneViewModel = viewModel()) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val activity = context as? Activity

    NavHost(navController = nav, startDestination = Routes.Splash) {
        composable(Routes.Splash) {
            SplashScreen(checkAccepted = { vm.prefs.termsAccepted.first() }) { accepted ->
                if (accepted) {
                    nav.navigate(Routes.Home) { popUpTo(Routes.Splash) { inclusive = true } }
                } else {
                    nav.navigate(Routes.Terms) { popUpTo(Routes.Splash) { inclusive = true } }
                }
            }
        }
        composable(Routes.Terms) {
            TermsScreen(
                onAccept = {
                    vm.acceptTerms()
                    nav.navigate(Routes.Home) { popUpTo(Routes.Terms) { inclusive = true } }
                },
                onDecline = { activity?.finishAffinity() }
            )
        }
        composable(Routes.Home) {
            HomeScreen(
                vm = vm,
                onOldPhone = { nav.navigate(Routes.SelectFile) },
                onNewPhone = { nav.navigate(Routes.QrDisplay) },
                onHistory = { nav.navigate(Routes.History) },
                onLanguage = { nav.navigate(Routes.Language) },
                onPrivacy = { nav.navigate(Routes.Privacy) },
                onShare = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            context.getString(R.string.share_text)
                        )
                    }
                    context.startActivity(
                        Intent.createChooser(send, context.getString(R.string.share_chooser))
                    )
                },
                onRate = {
                    val pkg = context.packageName
                    val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                    val web = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=$pkg")
                    )
                    runCatching { context.startActivity(market) }.onFailure {
                        context.startActivity(web)
                    }
                }
            )
        }
        composable(Routes.SelectFile) {
            SelectFileScreen(
                vm = vm,
                onBack = { nav.popBackStack() },
                onOpenCategory = { cat ->
                    if (cat == FileCategory.DOCUMENTS &&
                        android.os.Build.VERSION.SDK_INT >= 30 &&
                        !android.os.Environment.isExternalStorageManager()
                    ) {
                        runCatching {
                            context.startActivity(
                                Intent(
                                    android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                            )
                        }
                    }
                    nav.navigate(Routes.category(cat.name))
                },
                onSend = { nav.navigate(Routes.SelectMethod) }
            )
        }
        composable(
            Routes.Category,
            arguments = listOf(navArgument("category") { type = NavType.StringType })
        ) { entry ->
            val cat = remember(entry) {
                FileCategory.valueOf(entry.arguments?.getString("category") ?: FileCategory.PHOTOS.name)
            }
            CategoryDetailScreen(cat, vm) { nav.popBackStack() }
        }
        composable(Routes.SelectMethod) {
            SelectMethodScreen(
                onBack = { nav.popBackStack() },
                onWifi = {
                    TransferService.sendWifi(context, vm.selectedItems())
                    nav.navigate(Routes.Transfer)
                },
                onQr = { nav.navigate(Routes.QrScanner) }
            )
        }
        composable(Routes.QrDisplay) {
            QrDisplayScreen(
                onBack = {
                    TransferService.cancel(context)
                    TransferService.reset()
                    nav.popBackStack()
                },
                onTransferring = {
                    nav.navigate(Routes.Transfer) {
                        popUpTo(Routes.Home)
                    }
                }
            )
        }
        composable(Routes.QrScanner) {
            QrScannerScreen(
                onBack = { nav.popBackStack() },
                onScanned = { payload ->
                    TransferService.sendQr(context, vm.selectedItems(), payload)
                    nav.navigate(Routes.Transfer) {
                        popUpTo(Routes.SelectMethod)
                    }
                }
            )
        }
        composable(Routes.Transfer) {
            TransferProgressScreen(vm) {
                nav.navigate(Routes.Home) {
                    popUpTo(Routes.Home) { inclusive = true }
                    launchSingleTop = true
                }
            }
        }
        composable(Routes.History) { HistoryScreen(vm) { nav.popBackStack() } }
        composable(Routes.Language) { LanguageScreen(vm) { nav.popBackStack() } }
        composable(Routes.Privacy) { PrivacyScreen { nav.popBackStack() } }
    }
}
