package com.mastercoding.invoicemaker.ui.docs

import android.graphics.Bitmap
import android.graphics.Paint
import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.PrimaryCta
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Composable
fun SignatureScreen(
    vm: AppViewModel,
    lang: String,
    docId: String,
    seller: Boolean,
    onBack: () -> Unit
) {
    val doc by vm.repo.document(docId).collectAsStateWithLifecycle(null)
    val current = doc ?: return
    var points by remember { mutableStateOf(listOf<Offset>()) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (seller) t(lang, "your_sign") else t(lang, "customer_sign")) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(Color.White)
                    .pointerInteropFilter { e ->
                        when (e.action) {
                            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                                points = points + Offset(e.x, e.y)
                            }
                        }
                        true
                    }
            ) {
                val path = Path()
                points.forEachIndexed { i, p ->
                    if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
                }
                drawPath(path, Color(0xFF0B1F3A), style = Stroke(width = 6f))
            }
            OutlinedButton(onClick = { points = emptyList() }, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                Text(t(lang, "clear"))
            }
            PrimaryCta(t(lang, "done")) {
                if (points.isEmpty()) { onBack(); return@PrimaryCta }
                val bmp = Bitmap.createBitmap(800, 400, Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bmp)
                canvas.drawColor(android.graphics.Color.WHITE)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.parseColor("#0B1F3A")
                    strokeWidth = 8f
                    style = Paint.Style.STROKE
                }
                val scaleX = 800f / 1000f
                val androidPath = android.graphics.Path()
                points.forEachIndexed { i, p ->
                    val x = p.x * (800f / 1080f)
                    val y = p.y * (400f / 280f)
                    if (i == 0) androidPath.moveTo(x, y) else androidPath.lineTo(x, y)
                }
                canvas.drawPath(androidPath, paint)
                val file = File(context.filesDir, "sign_${System.currentTimeMillis()}.png")
                file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                scope.launch {
                    vm.saveDoc(
                        if (seller) current.copy(sellerSignPath = file.absolutePath)
                        else current.copy(customerSignPath = file.absolutePath)
                    )
                    onBack()
                }
            }
        }
    }
}
