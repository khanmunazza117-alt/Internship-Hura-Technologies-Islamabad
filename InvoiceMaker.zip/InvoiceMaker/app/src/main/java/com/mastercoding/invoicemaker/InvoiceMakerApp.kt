package com.mastercoding.invoicemaker

import android.app.Application
import com.mastercoding.invoicemaker.data.AppDatabase
import com.mastercoding.invoicemaker.data.InvoiceRepository
import com.mastercoding.invoicemaker.data.UserPrefs

class InvoiceMakerApp : Application() {
    lateinit var prefs: UserPrefs
        private set
    lateinit var repository: InvoiceRepository
        private set

    override fun onCreate() {
        super.onCreate()
        prefs = UserPrefs(this)
        repository = InvoiceRepository(AppDatabase.create(this), prefs, this)
    }
}
