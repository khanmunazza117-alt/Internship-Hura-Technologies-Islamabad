package com.mastercoding.invoicemaker.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.i18n.SupportedLanguages
import com.mastercoding.invoicemaker.ui.docs.DocumentEditorScreen
import com.mastercoding.invoicemaker.ui.docs.DocumentListScreen
import com.mastercoding.invoicemaker.ui.docs.PreviewScreen
import com.mastercoding.invoicemaker.ui.docs.SignatureScreen
import com.mastercoding.invoicemaker.ui.home.HomeScreen
import com.mastercoding.invoicemaker.ui.language.LanguageScreen
import com.mastercoding.invoicemaker.ui.onboarding.OnboardingScreen
import com.mastercoding.invoicemaker.ui.people.CustomersScreen
import com.mastercoding.invoicemaker.ui.people.ItemsScreen
import com.mastercoding.invoicemaker.ui.reports.PaymentsScreen
import com.mastercoding.invoicemaker.ui.reports.ReportsScreen
import com.mastercoding.invoicemaker.ui.settings.PrivacyScreen
import com.mastercoding.invoicemaker.ui.settings.SettingsScreen
import com.mastercoding.invoicemaker.ui.settings.TemplatesScreen
import com.mastercoding.invoicemaker.ui.splash.SplashScreen
import com.mastercoding.invoicemaker.ui.terms.TermsScreen
import com.mastercoding.invoicemaker.ui.theme.InvoiceMakerTheme
import kotlinx.coroutines.launch

@Composable
fun InvoiceApp(vm: AppViewModel = viewModel()) {
    val lang by vm.language.collectAsStateWithLifecycle()
    val dark by vm.darkTheme.collectAsStateWithLifecycle()
    val languageChosen by vm.languageChosen.collectAsStateWithLifecycle()
    val onboard by vm.onboardingDone.collectAsStateWithLifecycle()
    val terms by vm.termsAccepted.collectAsStateWithLifecycle()
    val docs by vm.documents.collectAsStateWithLifecycle()
    val customers by vm.customers.collectAsStateWithLifecycle()
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val pays by vm.payments.collectAsStateWithLifecycle()
    val lines by vm.allLines.collectAsStateWithLifecycle()
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    val rtl = SupportedLanguages.find { it.code == lang }?.rtl == true

    InvoiceMakerTheme(darkTheme = dark) {
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.ui.platform.LocalLayoutDirection provides
                if (rtl) androidx.compose.ui.unit.LayoutDirection.Rtl
                else androidx.compose.ui.unit.LayoutDirection.Ltr
        ) {
            NavHost(navController = nav, startDestination = "splash") {
                composable("splash") {
                    SplashScreen(lang) {
                        when {
                            !languageChosen -> nav.navigate("language") { popUpTo("splash") { inclusive = true } }
                            !onboard -> nav.navigate("onboarding") { popUpTo("splash") { inclusive = true } }
                            !terms -> nav.navigate("terms") { popUpTo("splash") { inclusive = true } }
                            else -> nav.navigate("home") { popUpTo("splash") { inclusive = true } }
                        }
                    }
                }
                composable("language") {
                    LanguageScreen(
                        currentLang = lang,
                        onContinue = { code ->
                            vm.setLanguage(code)
                            nav.navigate("onboarding") { popUpTo("language") { inclusive = true } }
                        }
                    )
                }
                composable("language_change") {
                    LanguageScreen(
                        currentLang = lang,
                        onBack = { nav.popBackStack() },
                        onContinue = { code ->
                            vm.setLanguage(code)
                            nav.popBackStack()
                        }
                    )
                }
                composable("onboarding") {
                    OnboardingScreen(lang) {
                        vm.finishOnboarding()
                        nav.navigate("terms") { popUpTo("onboarding") { inclusive = true } }
                    }
                }
                composable("terms") {
                    TermsScreen(lang) {
                        vm.acceptTerms()
                        nav.navigate("home") { popUpTo("terms") { inclusive = true } }
                    }
                }
                composable("home") {
                    HomeScreen(
                        vm, lang, dark, docs, lines, pays,
                        onOpenList = { nav.navigate("list/$it") },
                        onNewInvoice = {
                            scope.launch {
                                val id = vm.repo.createDocument(false)
                                nav.navigate("edit/$id")
                            }
                        },
                        onItems = { nav.navigate("items") },
                        onReports = { nav.navigate("reports") },
                        onTemplates = { nav.navigate("templates") },
                        onSettings = { nav.navigate("settings") },
                        onPrivacy = { nav.navigate("privacy") },
                        onLanguage = { nav.navigate("language_change") }
                    )
                }
                composable("list/{filter}", arguments = listOf(navArgument("filter") { type = NavType.StringType })) {
                    val filter = it.arguments?.getString("filter") ?: "invoice"
                    DocumentListScreen(
                        vm, lang, filter, docs, customers, lines, pays,
                        onBack = { nav.popBackStack() },
                        onOpen = { id -> nav.navigate("edit/$id") },
                        onCreate = {
                            scope.launch {
                                val id = vm.repo.createDocument(false)
                                nav.navigate("edit/$id")
                            }
                        }
                    )
                }
                composable("edit/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    val id = it.arguments?.getString("id") ?: return@composable
                    DocumentEditorScreen(
                        vm, lang, id,
                        onBack = { nav.popBackStack() },
                        onPreview = { nav.navigate("preview/$id") },
                        onSign = { seller -> nav.navigate("sign/$id/$seller") }
                    )
                }
                composable("preview/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    val id = it.arguments?.getString("id") ?: return@composable
                    PreviewScreen(
                        vm, lang, id,
                        onBack = { nav.popBackStack() },
                        onEdit = { nav.popBackStack() },
                        onConverted = { newId -> nav.navigate("edit/$newId") }
                    )
                }
                composable(
                    "sign/{id}/{seller}",
                    arguments = listOf(
                        navArgument("id") { type = NavType.StringType },
                        navArgument("seller") { type = NavType.BoolType }
                    )
                ) {
                    val id = it.arguments?.getString("id") ?: return@composable
                    val seller = it.arguments?.getBoolean("seller") ?: true
                    SignatureScreen(vm, lang, id, seller) { nav.popBackStack() }
                }
                composable("customers") { CustomersScreen(vm, lang, customers) { nav.popBackStack() } }
                composable("items") {
                    ItemsScreen(vm, lang, catalog, vm.business.value?.defaultCurrency ?: "USD") { nav.popBackStack() }
                }
                composable("reports") {
                    ReportsScreen(vm, lang, docs, customers, catalog, lines, pays) { nav.popBackStack() }
                }
                composable("payments") { PaymentsScreen(lang, pays, docs) { nav.popBackStack() } }
                composable("settings") {
                    SettingsScreen(vm, lang, onBack = { nav.popBackStack() }, onLanguage = { nav.navigate("language_change") })
                }
                composable("templates") { TemplatesScreen(vm, lang) { nav.popBackStack() } }
                composable("privacy") { PrivacyScreen(lang) { nav.popBackStack() } }
            }
        }
    }
}

@Composable
fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}
