package com.mastercoding.invoicemaker.ui.language

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.i18n.SupportedLanguages
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.PrimaryCta
import com.mastercoding.invoicemaker.ui.components.ScreenHeader
import com.mastercoding.invoicemaker.ui.theme.Teal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageScreen(
    currentLang: String,
    onContinue: (String) -> Unit,
    onBack: (() -> Unit)? = null
) {
    var selected by rememberSaveable(currentLang) { mutableStateOf(currentLang) }
    Scaffold(
        topBar = {
            if (onBack != null) {
                TopAppBar(
                    title = { Text(t(selected, "language")) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = t(selected, "cancel"))
                        }
                    }
                )
            }
        }
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(20.dp)
        ) {
            ScreenHeader(t(selected, "lang_title"), t(selected, "lang_subtitle"))
            Spacer(Modifier.height(16.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(SupportedLanguages, key = { it.code }) { lang ->
                    val active = lang.code == selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, if (active) Teal else MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                            .clickable { selected = lang.code }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = active, onClick = { selected = lang.code })
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(lang.nativeName, style = MaterialTheme.typography.titleMedium)
                            Text(lang.englishName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            PrimaryCta(t(selected, "continue"), onClick = { onContinue(selected) })
        }
    }
}
