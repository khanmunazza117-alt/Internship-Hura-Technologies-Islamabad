package com.mastercoding.invoicemaker.ui.splash

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.BrandMark
import com.mastercoding.invoicemaker.ui.theme.Ink
import com.mastercoding.invoicemaker.ui.theme.Teal
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(lang: String, onFinished: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    val alpha by animateFloatAsState(if (visible) 1f else 0f, tween(700), label = "splash")
    LaunchedEffect(Unit) {
        visible = true
        delay(1700)
        onFinished()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ink, Teal))),
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.alpha(alpha), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            BrandMark()
            Spacer(Modifier.height(20.dp))
            Text(t(lang, "app_name"), style = MaterialTheme.typography.displaySmall, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text(t(lang, "tagline"), style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.85f))
        }
    }
}
