package com.mastercoding.invoicemaker.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("invoice_prefs")

class UserPrefs(private val context: Context) {
    private val lang = stringPreferencesKey("lang")
    private val dark = booleanPreferencesKey("dark")
    private val languageDone = booleanPreferencesKey("language_done")
    private val onboardDone = booleanPreferencesKey("onboard_done")
    private val termsDone = booleanPreferencesKey("terms_done")
    private val invSeq = intPreferencesKey("inv_seq")
    private val estSeq = intPreferencesKey("est_seq")
    private val template = stringPreferencesKey("template")

    val language: Flow<String> = context.dataStore.data.map { it[lang] ?: "en" }
    val darkTheme: Flow<Boolean> = context.dataStore.data.map { it[dark] ?: false }
    val languageChosen: Flow<Boolean> = context.dataStore.data.map { it[languageDone] ?: false }
    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[onboardDone] ?: false }
    val termsAccepted: Flow<Boolean> = context.dataStore.data.map { it[termsDone] ?: false }
    val defaultTemplate: Flow<String> = context.dataStore.data.map { it[template] ?: "inkgold" }

    suspend fun setLanguage(code: String) {
        context.dataStore.edit {
            it[lang] = code
            it[languageDone] = true
        }
    }

    suspend fun setDark(enabled: Boolean) {
        context.dataStore.edit { it[dark] = enabled }
    }

    suspend fun setOnboardingDone() {
        context.dataStore.edit { it[onboardDone] = true }
    }

    suspend fun setTermsAccepted() {
        context.dataStore.edit { it[termsDone] = true }
    }

    suspend fun setTemplate(id: String) {
        context.dataStore.edit { it[template] = id }
    }

    suspend fun nextNumber(isEstimate: Boolean): String {
        var value = ""
        context.dataStore.edit { prefs ->
            if (isEstimate) {
                val n = (prefs[estSeq] ?: 1000) + 1
                prefs[estSeq] = n
                value = "EST-$n"
            } else {
                val n = (prefs[invSeq] ?: 1000) + 1
                prefs[invSeq] = n
                value = "INV-$n"
            }
        }
        return value
    }
}
