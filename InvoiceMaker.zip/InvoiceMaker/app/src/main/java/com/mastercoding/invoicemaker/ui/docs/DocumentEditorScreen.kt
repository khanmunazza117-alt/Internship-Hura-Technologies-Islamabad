package com.mastercoding.invoicemaker.ui.docs

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.data.Currencies
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.AppField
import com.mastercoding.invoicemaker.ui.theme.Teal
import com.mastercoding.invoicemaker.util.MoneyFormat
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentEditorScreen(
    vm: AppViewModel,
    lang: String,
    docId: String,
    onBack: () -> Unit,
    onPreview: () -> Unit,
    onSign: (Boolean) -> Unit
) {
    val doc by vm.repo.document(docId).collectAsStateWithLifecycle(null)
    val lines by vm.repo.lines(docId).collectAsStateWithLifecycle(emptyList())
    val pays by vm.repo.paymentsFor(docId).collectAsStateWithLifecycle(emptyList())
    val customers by vm.customers.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val current = doc ?: return
    val customerName = customers.find { it.id == current.customerId }?.name.orEmpty()
    val money = vm.money(current, lines, pays)
    val salesTax = lines.firstOrNull()?.taxPercent ?: 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(t(lang, "new_invoice")) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                },
                actions = {
                    IconButton(onClick = onPreview) { Icon(Icons.Filled.Search, null) }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(current.number, color = Teal, style = MaterialTheme.typography.titleMedium)
            AppField(
                value = customerName,
                onValueChange = { vm.setBillToName(current, it) },
                label = "${t(lang, "bill_to")} ${t(lang, "customer_name")}"
            )
            OutlinedButton(
                onClick = { pickDate(context, current.issueDate) { vm.saveDoc(current.copy(issueDate = it)) } },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("${t(lang, "issue")}: ${MoneyFormat.date(current.issueDate)}")
            }
            OutlinedButton(
                onClick = { pickDate(context, current.dueDate) { vm.saveDoc(current.copy(dueDate = it)) } },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("${t(lang, "due")}: ${MoneyFormat.date(current.dueDate)}")
            }
            CurrencyPicker(t(lang, "currency"), current.currency) { vm.saveDoc(current.copy(currency = it)) }
            AppField(
                current.discount.toString(),
                { vm.saveDoc(current.copy(discount = it.toDoubleOrNull() ?: 0.0)) },
                t(lang, "discount"),
                keyboardType = KeyboardType.Decimal
            )
            AppField(
                salesTax.toString(),
                { value ->
                    val percent = value.toDoubleOrNull() ?: 0.0
                    vm.saveDoc(current.copy(taxEnabled = percent > 0.0))
                    lines.forEach { vm.saveLine(it.copy(taxPercent = percent)) }
                },
                t(lang, "tax"),
                keyboardType = KeyboardType.Decimal
            )

            Text(t(lang, "items"), style = MaterialTheme.typography.titleMedium)
            lines.forEach { line ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row {
                            OutlinedTextField(
                                value = line.description.ifBlank { line.name },
                                onValueChange = { vm.saveLine(line.copy(description = it, name = it.ifBlank { line.name })) },
                                label = { Text(t(lang, "desc")) },
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { vm.deleteLine(line) }) { Icon(Icons.Filled.Delete, null) }
                        }
                        OutlinedTextField(
                            value = line.qty.toString(),
                            onValueChange = { vm.saveLine(line.copy(qty = it.toDoubleOrNull() ?: 0.0)) },
                            label = { Text(t(lang, "qty")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = line.price.toString(),
                            onValueChange = { vm.saveLine(line.copy(price = it.toDoubleOrNull() ?: 0.0)) },
                            label = { Text(t(lang, "price")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            OutlinedButton(onClick = { vm.addLine(docId) }, modifier = Modifier.fillMaxWidth()) {
                Text(t(lang, "add_item"))
            }

            Card {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${t(lang, "subtotal")}: ${MoneyFormat.format(money.subtotal, current.currency)}")
                    if (current.taxEnabled) {
                        Text("${t(lang, "tax")}: ${MoneyFormat.format(money.tax, current.currency)}")
                    }
                    Text(
                        "${t(lang, "total")}: ${MoneyFormat.format(money.total, current.currency)}",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CurrencyPicker(label: String, selected: String, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = open, onExpandedChange = { open = it }) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(open) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Currencies.forEach { c ->
                DropdownMenuItem(text = { Text(c) }, onClick = { onSelect(c); open = false })
            }
        }
    }
}

private fun pickDate(context: android.content.Context, current: Long, onPick: (Long) -> Unit) {
    val cal = Calendar.getInstance().apply { timeInMillis = current }
    DatePickerDialog(
        context,
        { _, y, m, d ->
            cal.set(y, m, d)
            onPick(cal.timeInMillis)
        },
        cal.get(Calendar.YEAR),
        cal.get(Calendar.MONTH),
        cal.get(Calendar.DAY_OF_MONTH)
    ).show()
}
