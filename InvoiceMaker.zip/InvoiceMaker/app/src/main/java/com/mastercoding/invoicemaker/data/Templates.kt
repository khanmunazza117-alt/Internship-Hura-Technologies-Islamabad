package com.mastercoding.invoicemaker.data

import androidx.compose.ui.graphics.Color

data class InvoiceTemplate(
    val id: String,
    val name: String,
    val header: Color,
    val accent: Color,
    val paper: Color
)

val InvoiceTemplates = listOf(
    InvoiceTemplate("classic", "Classic Ivory", Color(0xFF0B1F3A), Color(0xFF0F766E), Color(0xFFFFFBF5)),
    InvoiceTemplate("midnight", "Midnight", Color(0xFF111827), Color(0xFF38BDF8), Color(0xFFF8FAFC)),
    InvoiceTemplate("ocean", "Ocean", Color(0xFF0E7490), Color(0xFF22D3EE), Color(0xFFF0FDFA)),
    InvoiceTemplate("forest", "Forest", Color(0xFF14532D), Color(0xFF86EFAC), Color(0xFFF7FEE7)),
    InvoiceTemplate("sunset", "Sunset", Color(0xFF9A3412), Color(0xFFFDBA74), Color(0xFFFFF7ED)),
    InvoiceTemplate("graphite", "Graphite", Color(0xFF334155), Color(0xFFE2E8F0), Color(0xFFF8FAFC)),
    InvoiceTemplate("royal", "Royal", Color(0xFF1E3A8A), Color(0xFFFBBF24), Color(0xFFFFFBEB)),
    InvoiceTemplate("mint", "Mint", Color(0xFF047857), Color(0xFF6EE7B7), Color(0xFFECFDF5)),
    InvoiceTemplate("blush", "Blush", Color(0xFF9D174D), Color(0xFFF9A8D4), Color(0xFFFDF2F8)),
    InvoiceTemplate("copper", "Copper", Color(0xFF7C2D12), Color(0xFFF59E0B), Color(0xFFFFFBEB)),
    InvoiceTemplate("ice", "Ice", Color(0xFF164E63), Color(0xFF67E8F9), Color(0xFFECFEFF)),
    InvoiceTemplate("wine", "Wine", Color(0xFF7F1D1D), Color(0xFFFCA5A5), Color(0xFFFFF1F2)),
    InvoiceTemplate("sand", "Sand", Color(0xFF78350F), Color(0xFFFDE68A), Color(0xFFFFFBEB)),
    InvoiceTemplate("emerald", "Emerald", Color(0xFF064E3B), Color(0xFF34D399), Color(0xFFECFDF5)),
    InvoiceTemplate("slate", "Slate Teal", Color(0xFF134E4A), Color(0xFF5EEAD4), Color(0xFFF8FAFC)),
    InvoiceTemplate("inkgold", "Ink & Gold", Color(0xFF0B1F3A), Color(0xFFC9A227), Color(0xFFF6F1E8)),
    InvoiceTemplate("orchid", "Orchid", Color(0xFF5B21B6), Color(0xFFC4B5FD), Color(0xFFF5F3FF)),
    InvoiceTemplate("navy", "Deep Navy", Color(0xFF1E293B), Color(0xFF38BDF8), Color(0xFFF1F5F9)),
    InvoiceTemplate("coral", "Coral Desk", Color(0xFF9A3412), Color(0xFFFB7185), Color(0xFFFFF1F2)),
    InvoiceTemplate("paper", "Studio Paper", Color(0xFF44403C), Color(0xFFD6D3D1), Color(0xFFFAFAF9)),
    InvoiceTemplate("lagoon", "Lagoon", Color(0xFF155E75), Color(0xFF2DD4BF), Color(0xFFF0FDFA)),
    InvoiceTemplate("amber", "Amber Ledger", Color(0xFF92400E), Color(0xFFFBBF24), Color(0xFFFFFBEB)),
    InvoiceTemplate("violet", "Violet", Color(0xFF4C1D95), Color(0xFFA78BFA), Color(0xFFF5F3FF)),
    InvoiceTemplate("charcoal", "Charcoal", Color(0xFF1C1917), Color(0xFFA8A29E), Color(0xFFFAFAF9))
)

val Currencies = listOf(
    "USD", "EUR", "GBP", "INR", "PKR", "AED", "SAR", "CAD", "AUD", "JPY",
    "CNY", "BRL", "MXN", "ZAR", "NGN", "TRY", "CHF", "SGD", "HKD", "KRW"
)

fun templateById(id: String) = InvoiceTemplates.find { it.id == id } ?: InvoiceTemplates.first()
