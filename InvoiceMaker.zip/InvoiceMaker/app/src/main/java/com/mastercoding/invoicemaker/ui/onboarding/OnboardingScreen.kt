package com.mastercoding.invoicemaker.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.PrimaryCta
import com.mastercoding.invoicemaker.ui.theme.Teal
import kotlinx.coroutines.launch

@Composable
fun OnboardingScreen(lang: String, onDone: () -> Unit) {
    val pager = rememberPagerState(pageCount = { 3 })
    val scope = rememberCoroutineScope()
    val pages = listOf(
        Triple(Icons.Filled.List, t(lang, "onb1_title"), t(lang, "onb1_body")),
        Triple(Icons.Filled.ShoppingCart, t(lang, "onb2_title"), t(lang, "onb2_body")),
        Triple(Icons.Filled.Share, t(lang, "onb3_title"), t(lang, "onb3_body"))
    )
    Scaffold { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(20.dp)
        ) {
            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { index ->
                val (icon, title, body) = pages[index]
                OnboardPage(icon, title, body)
            }
            Row(
                Modifier.fillMaxWidth().padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                repeat(3) { i ->
                    Box(
                        Modifier
                            .padding(4.dp)
                            .size(if (pager.currentPage == i) 10.dp else 8.dp)
                            .clip(CircleShape)
                            .background(if (pager.currentPage == i) Teal else MaterialTheme.colorScheme.outline)
                    )
                }
            }
            PrimaryCta(
                if (pager.currentPage == 2) t(lang, "get_started") else t(lang, "next")
            ) {
                if (pager.currentPage == 2) onDone()
                else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
            }
        }
    }
}

@Composable
private fun OnboardPage(icon: ImageVector, title: String, body: String) {
    Column(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, Modifier.size(56.dp), tint = Teal)
        }
        Spacer(Modifier.height(28.dp))
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text(body, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
