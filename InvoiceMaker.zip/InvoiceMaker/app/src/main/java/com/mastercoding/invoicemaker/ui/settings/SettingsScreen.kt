package com.mastercoding.invoicemaker.ui.settings

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.data.BusinessEntity
import com.mastercoding.invoicemaker.data.Currencies
import com.mastercoding.invoicemaker.i18n.SupportedLanguages
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.AppField
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, lang: String, onBack: () -> Unit, onLanguage: () -> Unit) {
    val biz by vm.business.collectAsStateWithLifecycle()
    val current = biz ?: BusinessEntity(name = "", email = "", phone = "", address = "", logoPath = null, defaultCurrency = "USD", taxEnabled = true, defaultTerms = "", companyEmailCopy = "")
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val importCsv = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { vm.repo.importCustomersCsv(it.readText()) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(t(lang, "settings")) }, navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            })
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(t(lang, "settings_hint"), style = MaterialTheme.typography.bodyMedium)
            Text(t(lang, "business"), style = MaterialTheme.typography.titleMedium)
            AppField(current.name, { vm.saveBusiness(current.copy(name = it)) }, t(lang, "name"))
            AppField(current.email, { vm.saveBusiness(current.copy(email = it)) }, t(lang, "email_field"))
            AppField(current.phone, { vm.saveBusiness(current.copy(phone = it)) }, t(lang, "phone"))
            AppField(current.address, { vm.saveBusiness(current.copy(address = it)) }, t(lang, "address"))
            AppField(current.companyEmailCopy, { vm.saveBusiness(current.copy(companyEmailCopy = it)) }, t(lang, "company_email"))
            AppField(current.defaultTerms, { vm.saveBusiness(current.copy(defaultTerms = it)) }, t(lang, "terms"), singleLine = false)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(t(lang, "tax_on"), modifier = Modifier.weight(1f))
                Switch(checked = current.taxEnabled, onCheckedChange = { vm.saveBusiness(current.copy(taxEnabled = it)) })
            }
            Text(t(lang, "currency"))
            Currencies.chunked(5).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { code ->
                        OutlinedButton(onClick = { vm.saveBusiness(current.copy(defaultCurrency = code)) }) {
                            Text(if (current.defaultCurrency == code) "• $code" else code)
                        }
                    }
                }
            }
            Text(t(lang, "language"))
            OutlinedButton(onClick = onLanguage, modifier = Modifier.fillMaxWidth()) {
                val currentName = SupportedLanguages.find { it.code == lang }?.nativeName ?: lang
                Text("${t(lang, "language")}: $currentName")
            }
            Text(t(lang, "backup"), style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = {
                scope.launch {
                    val csv = vm.repo.exportCsv()
                    val file = File(context.cacheDir, "invoices.csv").apply { writeText(csv) }
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
                    context.startActivity(
                        Intent.createChooser(
                            Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            },
                            t(lang, "export_csv")
                        )
                    )
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(t(lang, "export_csv")) }
            OutlinedButton(onClick = { importCsv.launch("text/*") }, modifier = Modifier.fillMaxWidth()) {
                Text(t(lang, "import_csv"))
            }
            OutlinedButton(onClick = {
                scope.launch {
                    val json = vm.repo.exportBackup()
                    val file = File(context.cacheDir, "invoice-backup.json").apply { writeText(json) }
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
                    context.startActivity(
                        Intent.createChooser(
                            Intent(Intent.ACTION_SEND).apply {
                                type = "application/json"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            },
                            t(lang, "export_backup")
                        )
                    )
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(t(lang, "export_backup")) }
        }
    }
}
