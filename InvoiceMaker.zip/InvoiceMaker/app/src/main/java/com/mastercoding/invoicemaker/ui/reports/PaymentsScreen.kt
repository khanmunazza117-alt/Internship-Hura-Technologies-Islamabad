package com.mastercoding.invoicemaker.ui.reports

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.data.DocumentEntity
import com.mastercoding.invoicemaker.data.PaymentEntity
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.util.MoneyFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentsScreen(
    lang: String,
    pays: List<PaymentEntity>,
    docs: List<DocumentEntity>,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text(t(lang, "payments")) }, navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            })
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(pays, key = { it.id }) { p ->
                val d = docs.find { it.id == p.documentId }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${p.kind.uppercase()} · ${d?.number ?: ""}")
                        Text(MoneyFormat.format(p.amount, d?.currency ?: "USD"))
                        Text("${p.method} · ${MoneyFormat.date(p.date)}")
                        if (p.note.isNotBlank()) Text(p.note)
                    }
                }
            }
        }
    }
}
