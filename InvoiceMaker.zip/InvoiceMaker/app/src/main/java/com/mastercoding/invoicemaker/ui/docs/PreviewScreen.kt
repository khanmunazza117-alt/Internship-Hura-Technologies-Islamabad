package com.mastercoding.invoicemaker.ui.docs

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.util.PdfMaker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(
    vm: AppViewModel,
    lang: String,
    docId: String,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onConverted: (String) -> Unit
) {
    val doc by vm.repo.document(docId).collectAsStateWithLifecycle(null)
    val lines by vm.repo.lines(docId).collectAsStateWithLifecycle(emptyList())
    val pays by vm.repo.paymentsFor(docId).collectAsStateWithLifecycle(emptyList())
    val customers by vm.customers.collectAsStateWithLifecycle()
    val biz by vm.business.collectAsStateWithLifecycle()
    val current = doc ?: return
    val money = vm.money(current, lines, pays)
    val customer = customers.find { it.id == current.customerId }
    val context = LocalContext.current
    val pdf = remember { PdfMaker(context) }
    val bitmap = remember(current, lines, pays, biz, customer) {
        pdf.drawBitmap(current, biz, customer, lines, pays, money)
    }
    val scope = rememberCoroutineScope()

    fun share(asJpeg: Boolean, extraEmail: String? = null) {
        scope.launch {
            val file = withContext(Dispatchers.IO) {
                pdf.render(current, biz, customer, lines, pays, money, asJpeg)
            }
            val uri = pdf.shareUri(file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = if (asJpeg) "image/jpeg" else "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, current.number)
                putExtra(Intent.EXTRA_TEXT, "${current.number}")
                extraEmail?.let { putExtra(Intent.EXTRA_EMAIL, arrayOf(it)) }
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, t(lang, "share")))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(t(lang, "preview")) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
            )
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxWidth(),
                contentScale = ContentScale.FillWidth
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { share(false) }, modifier = Modifier.weight(1f)) { Text("PDF") }
                Button(onClick = { share(true) }, modifier = Modifier.weight(1f)) { Text("JPG") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pdf.print(current, bitmap) }, modifier = Modifier.weight(1f)) { Text(t(lang, "print")) }
                OutlinedButton(onClick = {
                    val to = listOfNotNull(customer?.email?.ifBlank { null }, biz?.companyEmailCopy?.ifBlank { null })
                    share(false, to.firstOrNull())
                    if (to.size > 1) share(false, to[1])
                }, modifier = Modifier.weight(1f)) { Text(t(lang, "email")) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    scope.launch { vm.repo.duplicate(docId) }
                    onBack()
                }, modifier = Modifier.weight(1f)) { Text(t(lang, "duplicate")) }
                if (current.type == "estimate") {
                    OutlinedButton(onClick = {
                        scope.launch {
                            vm.repo.convertEstimate(docId)?.let { onConverted(it) }
                        }
                    }, modifier = Modifier.weight(1f)) { Text(t(lang, "convert")) }
                }
            }
            OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) { Text(t(lang, "save")) }
            OutlinedButton(onClick = {
                vm.deleteDocument(docId)
                onBack()
            }, modifier = Modifier.fillMaxWidth()) { Text(t(lang, "delete")) }
        }
    }
}
