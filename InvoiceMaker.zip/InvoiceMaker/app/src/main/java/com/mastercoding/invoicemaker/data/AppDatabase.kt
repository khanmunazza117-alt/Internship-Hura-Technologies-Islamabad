package com.mastercoding.invoicemaker.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CustomerEntity::class,
        CatalogItemEntity::class,
        DocumentEntity::class,
        LineItemEntity::class,
        PaymentEntity::class,
        BusinessEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customers(): CustomerDao
    abstract fun catalog(): CatalogDao
    abstract fun documents(): DocumentDao
    abstract fun lines(): LineDao
    abstract fun payments(): PaymentDao
    abstract fun business(): BusinessDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "invoicemaker.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
