package com.mastercoding.invoicemaker.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Teal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = Ink,
    secondary = Gold,
    onSecondary = Ink,
    tertiary = Coral,
    background = Paper,
    onBackground = Ink,
    surface = PaperCard,
    onSurface = Ink,
    surfaceVariant = Mist,
    onSurfaceVariant = Slate,
    outline = Color(0xFF94A3B8)
)

private val DarkColors = darkColorScheme(
    primary = TealBright,
    onPrimary = Ink,
    primaryContainer = Color(0xFF134E4A),
    onPrimaryContainer = Color(0xFFCCFBF1),
    secondary = Gold,
    onSecondary = Ink,
    tertiary = Coral,
    background = DarkBg,
    onBackground = Color(0xFFE8EEF7),
    surface = DarkSurface,
    onSurface = Color(0xFFE8EEF7),
    surfaceVariant = DarkCard,
    onSurfaceVariant = Color(0xFFB8C5D6),
    outline = Color(0xFF64748B)
)

@Composable
fun InvoiceMakerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}
