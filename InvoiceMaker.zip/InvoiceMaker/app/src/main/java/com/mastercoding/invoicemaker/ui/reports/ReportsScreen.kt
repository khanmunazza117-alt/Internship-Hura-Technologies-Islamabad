package com.mastercoding.invoicemaker.ui.reports

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.data.CatalogItemEntity
import com.mastercoding.invoicemaker.data.CustomerEntity
import com.mastercoding.invoicemaker.data.DocumentEntity
import com.mastercoding.invoicemaker.data.LineItemEntity
import com.mastercoding.invoicemaker.data.PaymentEntity
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.util.MoneyFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    vm: AppViewModel,
    lang: String,
    docs: List<DocumentEntity>,
    customers: List<CustomerEntity>,
    items: List<CatalogItemEntity>,
    lines: List<LineItemEntity>,
    pays: List<PaymentEntity>,
    onBack: () -> Unit
) {
    val invoices = docs.filter { it.type == "invoice" }
    val currency = vm.business.value?.defaultCurrency ?: "USD"
    val totals = invoices.map { d ->
        d to vm.money(d, lines.filter { it.documentId == d.id }, pays.filter { it.documentId == d.id })
    }
    val sales = totals.sumOf { it.second.total }
    val collected = totals.sumOf { it.second.paid }
    val tax = totals.sumOf { it.second.tax }
    val profit = totals.sumOf { it.second.profit }
    val byCustomer = customers.map { c ->
        val related = totals.filter { it.first.customerId == c.id }
        c.name to related.sumOf { it.second.total }
    }.filter { it.second > 0 }
    val byItem = items.map { item ->
        val sold = lines.filter { it.name == item.name }
        item.name to sold.sumOf { (it.qty * it.price) - it.cost * it.qty }
    }.filter { it.second != 0.0 }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(t(lang, "reports")) }, navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            })
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                ReportCard(t(lang, "sales"), MoneyFormat.format(sales, currency))
            }
            item { ReportCard(t(lang, "payments"), MoneyFormat.format(collected, currency)) }
            item { ReportCard(t(lang, "tax_report"), MoneyFormat.format(tax, currency)) }
            item { ReportCard(t(lang, "profitability"), MoneyFormat.format(profit, currency)) }
            item { Text(t(lang, "customers"), style = MaterialTheme.typography.titleMedium) }
            items(byCustomer) { (name, amt) -> ReportCard(name, MoneyFormat.format(amt, currency)) }
            item { Text(t(lang, "items"), style = MaterialTheme.typography.titleMedium) }
            items(byItem) { (name, amt) -> ReportCard(name, MoneyFormat.format(amt, currency)) }
            item { Text(t(lang, "payments"), style = MaterialTheme.typography.titleMedium) }
            items(pays) { p ->
                val d = docs.find { it.id == p.documentId }
                ReportCard("${p.kind} · ${d?.number ?: ""}", MoneyFormat.format(p.amount, d?.currency ?: currency))
            }
        }
    }
}

@Composable
private fun ReportCard(title: String, value: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}
