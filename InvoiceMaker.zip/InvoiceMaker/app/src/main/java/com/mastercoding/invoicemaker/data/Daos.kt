package com.mastercoding.invoicemaker.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name")
    fun observe(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers ORDER BY name")
    suspend fun list(): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun get(id: String): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: CustomerEntity)

    @Delete
    suspend fun delete(item: CustomerEntity)
}

@Dao
interface CatalogDao {
    @Query("SELECT * FROM catalog_items ORDER BY name")
    fun observe(): Flow<List<CatalogItemEntity>>

    @Query("SELECT * FROM catalog_items ORDER BY name")
    suspend fun list(): List<CatalogItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: CatalogItemEntity)

    @Delete
    suspend fun delete(item: CatalogItemEntity)

    @Query("SELECT COUNT(*) FROM catalog_items")
    suspend fun count(): Int
}

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY issueDate DESC")
    fun observe(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun get(id: String): DocumentEntity?

    @Query("SELECT * FROM documents WHERE id = :id")
    fun observeOne(id: String): Flow<DocumentEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: DocumentEntity)

    @Delete
    suspend fun delete(item: DocumentEntity)

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface LineDao {
    @Query("SELECT * FROM line_items WHERE documentId = :docId")
    fun observe(docId: String): Flow<List<LineItemEntity>>

    @Query("SELECT * FROM line_items WHERE documentId = :docId")
    suspend fun list(docId: String): List<LineItemEntity>

    @Query("SELECT * FROM line_items")
    fun observeAll(): Flow<List<LineItemEntity>>

    @Query("SELECT * FROM line_items")
    suspend fun all(): List<LineItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: LineItemEntity)

    @Delete
    suspend fun delete(item: LineItemEntity)

    @Query("DELETE FROM line_items WHERE documentId = :docId")
    suspend fun deleteFor(docId: String)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE documentId = :docId ORDER BY date DESC")
    fun observe(docId: String): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE documentId = :docId")
    suspend fun list(docId: String): List<PaymentEntity>

    @Query("SELECT * FROM payments ORDER BY date DESC")
    fun observeAll(): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments")
    suspend fun all(): List<PaymentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: PaymentEntity)

    @Delete
    suspend fun delete(item: PaymentEntity)

    @Query("DELETE FROM payments WHERE documentId = :docId")
    suspend fun deleteFor(docId: String)
}

@Dao
interface BusinessDao {
    @Query("SELECT * FROM business WHERE id = 1")
    fun observe(): Flow<BusinessEntity?>

    @Query("SELECT * FROM business WHERE id = 1")
    suspend fun get(): BusinessEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: BusinessEntity)
}
