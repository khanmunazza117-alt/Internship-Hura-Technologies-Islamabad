package com.mastercoding.invoicemaker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mastercoding.invoicemaker.data.BusinessEntity
import com.mastercoding.invoicemaker.data.CatalogItemEntity
import com.mastercoding.invoicemaker.data.CustomerEntity
import com.mastercoding.invoicemaker.data.DocumentEntity
import com.mastercoding.invoicemaker.data.LineItemEntity
import com.mastercoding.invoicemaker.data.PaymentEntity
import com.mastercoding.invoicemaker.data.computedStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val appCtx = app as InvoiceMakerApp
    val repo = appCtx.repository
    val prefs = appCtx.prefs

    val language = prefs.language.stateIn(viewModelScope, SharingStarted.Eagerly, "en")
    val darkTheme = prefs.darkTheme.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val languageChosen = prefs.languageChosen.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val onboardingDone = prefs.onboardingDone.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val termsAccepted = prefs.termsAccepted.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val documents = repo.documents.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val customers = repo.customers.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val catalog = repo.catalog.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val payments = repo.payments.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val allLines = repo.allLines.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val business = repo.business.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    init {
        viewModelScope.launch { repo.ensureSeed() }
    }

    fun setLanguage(code: String) = viewModelScope.launch { prefs.setLanguage(code) }
    fun setDark(on: Boolean) = viewModelScope.launch { prefs.setDark(on) }
    fun finishOnboarding() = viewModelScope.launch { prefs.setOnboardingDone() }
    fun acceptTerms() = viewModelScope.launch { prefs.setTermsAccepted() }

    fun saveDoc(doc: DocumentEntity) = viewModelScope.launch { repo.saveDocument(doc) }
    fun saveLine(line: LineItemEntity) = viewModelScope.launch { repo.saveLine(line) }
    fun deleteLine(line: LineItemEntity) = viewModelScope.launch { repo.deleteLine(line) }
    fun addLine(docId: String, item: CatalogItemEntity? = null) =
        viewModelScope.launch { repo.addLine(docId, item) }

    fun addPayment(docId: String, amount: Double, method: String, kind: String, note: String) =
        viewModelScope.launch { repo.addPayment(docId, amount, method, kind, note) }

    fun deletePayment(p: PaymentEntity) = viewModelScope.launch { repo.deletePayment(p) }
    fun saveCustomer(c: CustomerEntity) = viewModelScope.launch { repo.upsertCustomer(c) }
    fun setBillToName(doc: DocumentEntity, name: String) =
        viewModelScope.launch { repo.setBillToName(doc, name) }
    fun deleteCustomer(c: CustomerEntity) = viewModelScope.launch { repo.deleteCustomer(c) }
    fun saveItem(i: CatalogItemEntity) = viewModelScope.launch { repo.upsertItem(i) }
    fun deleteItem(i: CatalogItemEntity) = viewModelScope.launch { repo.deleteItem(i) }
    fun saveBusiness(b: BusinessEntity) = viewModelScope.launch { repo.saveBusiness(b) }
    fun deleteDocument(id: String) = viewModelScope.launch { repo.deleteDocument(id) }

    fun newId() = UUID.randomUUID().toString()

    fun money(doc: DocumentEntity, lines: List<LineItemEntity>, pays: List<PaymentEntity>) =
        repo.breakdown(doc, lines, pays.sumOf { it.amount })

    fun statusOf(doc: DocumentEntity, lines: List<LineItemEntity>, pays: List<PaymentEntity>): String =
        doc.computedStatus(money(doc, lines, pays))
}
