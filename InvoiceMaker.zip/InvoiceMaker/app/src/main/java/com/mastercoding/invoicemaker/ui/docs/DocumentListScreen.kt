package com.mastercoding.invoicemaker.ui.docs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.data.CustomerEntity
import com.mastercoding.invoicemaker.data.DocumentEntity
import com.mastercoding.invoicemaker.data.LineItemEntity
import com.mastercoding.invoicemaker.data.PaymentEntity
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.theme.Teal
import com.mastercoding.invoicemaker.util.MoneyFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentListScreen(
    vm: AppViewModel,
    lang: String,
    filter: String,
    docs: List<DocumentEntity>,
    customers: List<CustomerEntity>,
    lines: List<LineItemEntity>,
    pays: List<PaymentEntity>,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onCreate: () -> Unit
) {
    val title = when (filter) {
        "estimate" -> t(lang, "estimates")
        "unpaid" -> t(lang, "unpaid")
        "overdue" -> t(lang, "overdue")
        else -> t(lang, "invoices")
    }
    val shown = docs.filter { d ->
        when (filter) {
            "estimate" -> d.type == "estimate"
            "invoice" -> d.type == "invoice"
            "unpaid" -> d.type == "invoice" && vm.statusOf(d, lines.filter { it.documentId == d.id }, pays.filter { it.documentId == d.id }) in listOf("unpaid", "partial", "draft")
            "overdue" -> d.type == "invoice" && vm.statusOf(d, lines.filter { it.documentId == d.id }, pays.filter { it.documentId == d.id }) == "overdue"
            else -> true
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreate, containerColor = Teal) {
                Icon(Icons.Filled.Add, null, tint = androidx.compose.ui.graphics.Color.White)
            }
        }
    ) { pad ->
        if (shown.isEmpty()) {
            Text(t(lang, "empty_docs"), Modifier.padding(pad).padding(24.dp))
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(shown, key = { it.id }) { d ->
                    val money = vm.money(d, lines.filter { it.documentId == d.id }, pays.filter { it.documentId == d.id })
                    val st = d.let { vm.statusOf(it, lines.filter { l -> l.documentId == d.id }, pays.filter { p -> p.documentId == d.id }) }
                    val cust = customers.find { it.id == d.customerId }?.name ?: "—"
                    Card(onClick = { onOpen(d.id) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(d.number, style = MaterialTheme.typography.titleMedium)
                                Text(st.uppercase(), color = Teal, style = MaterialTheme.typography.labelLarge)
                            }
                            Text(cust, style = MaterialTheme.typography.bodyMedium)
                            Text("${MoneyFormat.format(money.total, d.currency)} · ${t(lang, "balance")} ${MoneyFormat.format(money.balance, d.currency)}")
                            Text(MoneyFormat.date(d.issueDate), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
