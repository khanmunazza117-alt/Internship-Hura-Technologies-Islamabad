package com.mastercoding.invoicemaker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val phone: String,
    val address: String,
    val creditDays: Int,
    val notes: String
)

@Entity(tableName = "catalog_items")
data class CatalogItemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val unit: String,
    val price: Double,
    val cost: Double,
    val taxPercent: Double
)

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val id: String,
    val type: String,
    val number: String,
    val issueDate: Long,
    val dueDate: Long,
    val customerId: String?,
    val notes: String,
    val terms: String,
    val taxEnabled: Boolean,
    val currency: String,
    val discount: Double,
    val logoPath: String?,
    val backgroundId: String,
    val customBgPath: String?,
    val sellerSignPath: String?,
    val customerSignPath: String?,
    val photosJson: String,
    val attachmentsJson: String,
    val convertedFromId: String?,
    val createdAt: Long
)

@Entity(tableName = "line_items")
data class LineItemEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val name: String,
    val description: String,
    val qty: Double,
    val price: Double,
    val cost: Double,
    val taxPercent: Double,
    val discount: Double
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val amount: Double,
    val date: Long,
    val method: String,
    val kind: String,
    val note: String
)

@Entity(tableName = "business")
data class BusinessEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val email: String,
    val phone: String,
    val address: String,
    val logoPath: String?,
    val defaultCurrency: String,
    val taxEnabled: Boolean,
    val defaultTerms: String,
    val companyEmailCopy: String
)

data class MoneyBreakdown(
    val subtotal: Double,
    val tax: Double,
    val discount: Double,
    val total: Double,
    val paid: Double,
    val balance: Double,
    val cost: Double,
    val profit: Double
)

fun DocumentEntity.computedStatus(breakdown: MoneyBreakdown, now: Long = System.currentTimeMillis()): String {
    if (type == "estimate") {
        return if (convertedFromId != null) "converted" else "draft"
    }
    return when {
        breakdown.total <= 0.0 && breakdown.paid <= 0.0 -> "draft"
        breakdown.balance <= 0.01 -> "paid"
        breakdown.paid > 0.0 -> "partial"
        dueDate < now -> "overdue"
        else -> "unpaid"
    }
}
