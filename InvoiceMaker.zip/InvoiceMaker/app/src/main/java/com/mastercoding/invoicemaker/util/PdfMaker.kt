package com.mastercoding.invoicemaker.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import androidx.print.PrintHelper
import com.mastercoding.invoicemaker.data.BusinessEntity
import com.mastercoding.invoicemaker.data.CustomerEntity
import com.mastercoding.invoicemaker.data.DocumentEntity
import com.mastercoding.invoicemaker.data.LineItemEntity
import com.mastercoding.invoicemaker.data.MoneyBreakdown
import com.mastercoding.invoicemaker.data.PaymentEntity
import com.mastercoding.invoicemaker.data.templateById
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Currency
import java.util.Date
import java.util.Locale

object MoneyFormat {
    fun format(amount: Double, currencyCode: String): String {
        return try {
            val nf = NumberFormat.getCurrencyInstance(Locale.getDefault())
            nf.currency = Currency.getInstance(currencyCode)
            nf.format(amount)
        } catch (_: Exception) {
            "$currencyCode ${"%.2f".format(amount)}"
        }
    }

    fun date(millis: Long): String =
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(millis))
}

class PdfMaker(private val context: Context) {

    fun render(
        doc: DocumentEntity,
        biz: BusinessEntity?,
        customer: CustomerEntity?,
        lines: List<LineItemEntity>,
        payments: List<PaymentEntity>,
        money: MoneyBreakdown,
        asJpeg: Boolean
    ): File {
        val bmp = drawBitmap(doc, biz, customer, lines, payments, money)
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        return if (asJpeg) {
            val file = File(dir, "${doc.number}.jpg")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            file
        } else {
            val file = File(dir, "${doc.number}.pdf")
            val pdf = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(bmp.width, bmp.height, 1).create()
            val page = pdf.startPage(pageInfo)
            page.canvas.drawBitmap(bmp, 0f, 0f, null)
            pdf.finishPage(page)
            FileOutputStream(file).use { pdf.writeTo(it) }
            pdf.close()
            file
        }
    }

    fun print(doc: DocumentEntity, bitmap: Bitmap) {
        val helper = PrintHelper(context)
        helper.scaleMode = PrintHelper.SCALE_MODE_FIT
        helper.printBitmap(doc.number, bitmap)
    }

    fun printBitmapFile(file: File) {
        val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return
        val helper = PrintHelper(context)
        helper.scaleMode = PrintHelper.SCALE_MODE_FIT
        helper.printBitmap(file.name, bmp)
    }

    fun shareUri(file: File) =
        FileProvider.getUriForFile(context, "${context.packageName}.files", file)

    fun drawBitmap(
        doc: DocumentEntity,
        biz: BusinessEntity?,
        customer: CustomerEntity?,
        lines: List<LineItemEntity>,
        payments: List<PaymentEntity>,
        money: MoneyBreakdown
    ): Bitmap {
        val width = 1240
        val rowH = 52
        val height = 980 + lines.size * rowH + payments.size * 40 + 280
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val tpl = templateById(doc.backgroundId)
        fun col(compose: androidx.compose.ui.graphics.Color): Int {
            return android.graphics.Color.argb(
                (compose.alpha * 255).toInt(),
                (compose.red * 255).toInt(),
                (compose.green * 255).toInt(),
                (compose.blue * 255).toInt()
            )
        }
        c.drawColor(col(tpl.paper))

        customBg(c, doc, width, height)

        val header = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col(tpl.header) }
        c.drawRect(0f, 0f, width.toFloat(), 210f, header)
        val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col(tpl.accent) }
        c.drawRect(0f, 210f, width.toFloat(), 222f, accent)

        val white = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = 42f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val white2 = Paint(white).apply { textSize = 22f; typeface = Typeface.SANS_SERIF }
        val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.parseColor("#0B1F3A")
            textSize = 20f
        }
        val inkB = Paint(ink).apply {
            textSize = 24f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        val kind = if (doc.type == "estimate") "ESTIMATE" else "INVOICE"
        c.drawText(kind, 48f, 78f, white)
        c.drawText(doc.number, 48f, 122f, white2)
        c.drawText(biz?.name ?: "Business", 48f, 168f, white2)

        doc.logoPath?.let { path ->
            val logo = BitmapFactory.decodeFile(path)
            if (logo != null) {
                val dest = RectF(width - 210f, 40f, width - 48f, 180f)
                c.drawBitmap(logo, null, dest, null)
            }
        }

        var y = 270f
        c.drawText("From", 48f, y, inkB)
        c.drawText("Bill to", 640f, y, inkB)
        y += 34
        c.drawText(biz?.name.orEmpty(), 48f, y, ink)
        c.drawText(customer?.name ?: "Walk-in client", 640f, y, ink)
        y += 28
        wrap(c, biz?.address.orEmpty() + "\n" + biz?.email.orEmpty() + "\n" + biz?.phone.orEmpty(), 48f, y, ink, 520f)
        wrap(c, (customer?.address.orEmpty() + "\n" + customer?.email.orEmpty() + "\n" + customer?.phone.orEmpty()), 640f, y, ink, 520f)

        y = 430f
        c.drawText("Issued  ${MoneyFormat.date(doc.issueDate)}", 48f, y, ink)
        c.drawText("Due  ${MoneyFormat.date(doc.dueDate)}", 480f, y, ink)
        c.drawText(doc.currency, 900f, y, inkB)

        y = 470f
        c.drawRoundRect(RectF(40f, y, width - 40f, y + 48f), 12f, 12f, header)
        val headT = Paint(white).apply { textSize = 18f }
        c.drawText("Item", 60f, y + 32f, headT)
        c.drawText("Qty", 620f, y + 32f, headT)
        c.drawText("Price", 740f, y + 32f, headT)
        c.drawText("Tax %", 900f, y + 32f, headT)
        c.drawText("Amount", 1040f, y + 32f, headT)

        y += 70f
        lines.forEach { line ->
            val net = (line.qty * line.price) - line.discount
            c.drawText(line.name.ifBlank { "Item" }, 60f, y, inkB)
            if (line.description.isNotBlank()) c.drawText(line.description, 60f, y + 24f, ink)
            c.drawText(line.qty.toString(), 620f, y, ink)
            c.drawText("%.2f".format(line.price), 740f, y, ink)
            c.drawText(if (doc.taxEnabled) "%.1f".format(line.taxPercent) else "-", 900f, y, ink)
            c.drawText(MoneyFormat.format(net, doc.currency), 1040f, y, ink)
            y += rowH.toFloat()
        }

        y += 20f
        fun row(label: String, value: String, bold: Boolean = false) {
            val p = if (bold) inkB else ink
            c.drawText(label, 780f, y, p)
            c.drawText(value, 1040f, y, p)
            y += 32f
        }
        row("Subtotal", MoneyFormat.format(money.subtotal, doc.currency))
        if (doc.taxEnabled) row("Sales tax", MoneyFormat.format(money.tax, doc.currency))
        if (money.discount > 0) row("Discount", MoneyFormat.format(money.discount, doc.currency))
        row("Total", MoneyFormat.format(money.total, doc.currency), true)
        row("Paid", MoneyFormat.format(money.paid, doc.currency))
        row("Balance", MoneyFormat.format(money.balance, doc.currency), true)

        y += 16
        if (doc.notes.isNotBlank()) {
            c.drawText("Notes", 48f, y, inkB); y += 28
            y = wrap(c, doc.notes, 48f, y, ink, 1100f) + 16
        }
        if (doc.terms.isNotBlank()) {
            c.drawText("Terms", 48f, y, inkB); y += 28
            y = wrap(c, doc.terms, 48f, y, ink, 1100f) + 20
        }

        if (payments.isNotEmpty()) {
            c.drawText("Payments & credits", 48f, y, inkB); y += 30
            payments.forEach {
                c.drawText("${it.kind}  ${MoneyFormat.format(it.amount, doc.currency)}  ${it.method}  ${MoneyFormat.date(it.date)}", 48f, y, ink)
                y += 28
            }
        }

        y += 30
        drawSign(c, doc.sellerSignPath, 80f, y, "Authorized")
        drawSign(c, doc.customerSignPath, 680f, y, "Client accepted")
        return bmp
    }

    private fun customBg(c: Canvas, doc: DocumentEntity, w: Int, h: Int) {
        val path = doc.customBgPath ?: return
        val img = BitmapFactory.decodeFile(path) ?: return
        val p = Paint().apply { alpha = 40 }
        c.drawBitmap(img, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), p)
    }

    private fun drawSign(c: Canvas, path: String?, x: Float, y: Float, label: String) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.parseColor("#0B1F3A")
            textSize = 18f
        }
        c.drawText(label, x, y, paint)
        if (path != null) {
            val bmp = BitmapFactory.decodeFile(path)
            if (bmp != null) c.drawBitmap(bmp, null, RectF(x, y + 8, x + 280f, y + 130f), null)
        } else {
            val line = Paint().apply { color = android.graphics.Color.GRAY; strokeWidth = 2f }
            c.drawLine(x, y + 90f, x + 260f, y + 90f, line)
        }
    }

    private fun wrap(c: Canvas, text: String, x: Float, yStart: Float, paint: Paint, maxW: Float): Float {
        var y = yStart
        text.split("\n").forEach { line ->
            var rest = line
            while (rest.isNotEmpty()) {
                val count = paint.breakText(rest, true, maxW, null)
                c.drawText(rest.take(count), x, y, paint)
                rest = rest.drop(count)
                y += paint.textSize + 6
            }
        }
        return y
    }
}
