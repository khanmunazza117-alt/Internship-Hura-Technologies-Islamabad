package com.mastercoding.invoicemaker.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

class InvoiceRepository(
    private val db: AppDatabase,
    private val prefs: UserPrefs,
    private val context: Context
) {
    val customers = db.customers().observe()
    val catalog = db.catalog().observe()
    val documents = db.documents().observe()
    val payments = db.payments().observeAll()
    val allLines = db.lines().observeAll()
    val business = db.business().observe()

    fun document(id: String) = db.documents().observeOne(id)
    fun lines(id: String) = db.lines().observe(id)
    fun paymentsFor(id: String) = db.payments().observe(id)

    suspend fun ensureSeed() {
        if (db.business().get() == null) {
            db.business().upsert(
                BusinessEntity(
                    name = "Your Studio",
                    email = "billing@studio.local",
                    phone = "",
                    address = "",
                    logoPath = null,
                    defaultCurrency = "USD",
                    taxEnabled = true,
                    defaultTerms = "Payment due within the credit terms on this invoice. Late invoices may incur a reminder fee.",
                    companyEmailCopy = ""
                )
            )
        }
        if (db.catalog().count() == 0) {
            listOf(
                CatalogItemEntity(id(), "Design hours", "Product / UI design", "hr", 85.0, 30.0, 10.0),
                CatalogItemEntity(id(), "Development", "App or web development", "hr", 110.0, 45.0, 10.0),
                CatalogItemEntity(id(), "Site visit", "On-site consultation", "visit", 150.0, 40.0, 5.0),
                CatalogItemEntity(id(), "Retainer", "Monthly support retainer", "mo", 900.0, 200.0, 18.0)
            ).forEach { db.catalog().upsert(it) }
        }
    }

    suspend fun createDocument(isEstimate: Boolean, customerId: String? = null): String {
        val biz = db.business().get()
        val customer = customerId?.let { db.customers().get(it) }
        val credit = customer?.creditDays ?: 14
        val now = System.currentTimeMillis()
        val id = id()
        val doc = DocumentEntity(
            id = id,
            type = if (isEstimate) "estimate" else "invoice",
            number = prefs.nextNumber(isEstimate),
            issueDate = now,
            dueDate = now + TimeUnit.DAYS.toMillis(credit.toLong()),
            customerId = customerId,
            notes = "",
            terms = biz?.defaultTerms.orEmpty(),
            taxEnabled = biz?.taxEnabled ?: true,
            currency = biz?.defaultCurrency ?: "USD",
            discount = 0.0,
            logoPath = biz?.logoPath,
            backgroundId = prefs.defaultTemplate.first(),
            customBgPath = null,
            sellerSignPath = null,
            customerSignPath = null,
            photosJson = "[]",
            attachmentsJson = "[]",
            convertedFromId = null,
            createdAt = now
        )
        db.documents().upsert(doc)
        db.lines().upsert(
            LineItemEntity(id(), id, "Service", "", 1.0, 0.0, 0.0, 0.0, 0.0)
        )
        return id
    }

    suspend fun saveDocument(doc: DocumentEntity) = db.documents().upsert(doc)

    suspend fun saveLine(line: LineItemEntity) = db.lines().upsert(line)

    suspend fun deleteLine(line: LineItemEntity) = db.lines().delete(line)

    suspend fun addLine(documentId: String, fromCatalog: CatalogItemEntity? = null) {
        val line = if (fromCatalog != null) {
            LineItemEntity(
                id(), documentId, fromCatalog.name, fromCatalog.description,
                1.0, fromCatalog.price, fromCatalog.cost, fromCatalog.taxPercent, 0.0
            )
        } else {
            LineItemEntity(id(), documentId, "", "", 1.0, 0.0, 0.0, 0.0, 0.0)
        }
        db.lines().upsert(line)
    }

    suspend fun addPayment(documentId: String, amount: Double, method: String, kind: String, note: String) {
        db.payments().upsert(
            PaymentEntity(id(), documentId, amount, System.currentTimeMillis(), method, kind, note)
        )
    }

    suspend fun deletePayment(payment: PaymentEntity) = db.payments().delete(payment)

    suspend fun upsertCustomer(c: CustomerEntity) = db.customers().upsert(c)
    suspend fun deleteCustomer(c: CustomerEntity) = db.customers().delete(c)

    suspend fun setBillToName(doc: DocumentEntity, name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            saveDocument(doc.copy(customerId = null))
            return
        }
        val existing = db.customers().list().firstOrNull { it.name.equals(trimmed, ignoreCase = true) }
        val customer = existing ?: CustomerEntity(
            id = id(),
            name = trimmed,
            email = "",
            phone = "",
            address = "",
            creditDays = 14,
            notes = ""
        ).also { upsertCustomer(it) }
        saveDocument(doc.copy(customerId = customer.id))
    }
    suspend fun upsertItem(i: CatalogItemEntity) = db.catalog().upsert(i)
    suspend fun deleteItem(i: CatalogItemEntity) = db.catalog().delete(i)
    suspend fun saveBusiness(b: BusinessEntity) = db.business().upsert(b)

    suspend fun duplicate(id: String): String? {
        val src = db.documents().get(id) ?: return null
        val newId = id()
        val copy = src.copy(
            id = newId,
            number = prefs.nextNumber(src.type == "estimate"),
            createdAt = System.currentTimeMillis(),
            issueDate = System.currentTimeMillis(),
            convertedFromId = null,
            customerSignPath = null
        )
        db.documents().upsert(copy)
        db.lines().list(id).forEach { db.lines().upsert(it.copy(id = id(), documentId = newId)) }
        return newId
    }

    suspend fun convertEstimate(id: String): String? {
        val src = db.documents().get(id) ?: return null
        if (src.type != "estimate") return id
        val newId = id()
        db.documents().upsert(
            src.copy(
                id = newId,
                type = "invoice",
                number = prefs.nextNumber(false),
                convertedFromId = src.id,
                createdAt = System.currentTimeMillis(),
                issueDate = System.currentTimeMillis()
            )
        )
        db.lines().list(id).forEach { db.lines().upsert(it.copy(id = id(), documentId = newId)) }
        return newId
    }

    suspend fun deleteDocument(id: String) {
        db.lines().deleteFor(id)
        db.payments().deleteFor(id)
        db.documents().deleteById(id)
    }

    suspend fun breakdown(doc: DocumentEntity): MoneyBreakdown {
        val lines = db.lines().list(doc.id)
        val paid = db.payments().list(doc.id).sumOf { it.amount }
        return breakdown(doc, lines, paid)
    }

    fun breakdown(doc: DocumentEntity, lines: List<LineItemEntity>, paid: Double): MoneyBreakdown {
        var subtotal = 0.0
        var tax = 0.0
        var cost = 0.0
        lines.forEach { line ->
            val lineNet = (line.qty * line.price) - line.discount
            subtotal += lineNet
            cost += line.qty * line.cost
            if (doc.taxEnabled) tax += lineNet * (line.taxPercent / 100.0)
        }
        val total = (subtotal + tax - doc.discount).coerceAtLeast(0.0)
        return MoneyBreakdown(subtotal, tax, doc.discount, total, paid, (total - paid).coerceAtLeast(0.0), cost, total - cost)
    }

    suspend fun copyUri(uri: Uri, prefix: String): String {
        val dest = File(context.filesDir, "${prefix}_${System.currentTimeMillis()}_${uri.lastPathSegment?.filter { it.isLetterOrDigit() } ?: "file"}")
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        }
        return dest.absolutePath
    }

    fun jsonList(raw: String): List<String> = try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getString(it) }
    } catch (_: Exception) {
        emptyList()
    }

    fun toJson(list: List<String>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr.toString()
    }

    suspend fun exportCsv(): String {
        val docs = documents.first()
        val sb = StringBuilder("type,number,date,customer,total,paid,balance,status,currency\n")
        val customers = db.customers().list().associateBy { it.id }
        docs.forEach { d ->
            val b = breakdown(d)
            val name = d.customerId?.let { customers[it]?.name }.orEmpty()
            sb.append("${d.type},${d.number},${d.issueDate},\"$name\",${b.total},${b.paid},${b.balance},${d.computedStatus(b)},${d.currency}\n")
        }
        return sb.toString()
    }

    suspend fun importCustomersCsv(text: String) {
        text.lineSequence().drop(1).forEach { line ->
            val p = line.split(",")
            if (p.size >= 2 && p[0].isNotBlank()) {
                upsertCustomer(
                    CustomerEntity(
                        id = id(),
                        name = p[0].trim().trim('"'),
                        email = p.getOrNull(1)?.trim().orEmpty(),
                        phone = p.getOrNull(2)?.trim().orEmpty(),
                        address = p.getOrNull(3)?.trim().orEmpty(),
                        creditDays = p.getOrNull(4)?.toIntOrNull() ?: 14,
                        notes = ""
                    )
                )
            }
        }
    }

    suspend fun exportBackup(): String {
        val obj = JSONObject()
        obj.put("customers", JSONArray(db.customers().list().map { JSONObject(mapOf(
            "id" to it.id, "name" to it.name, "email" to it.email, "phone" to it.phone,
            "address" to it.address, "creditDays" to it.creditDays, "notes" to it.notes
        )) }))
        return obj.toString()
    }

    private fun id() = UUID.randomUUID().toString()
}

fun JSONObject(map: Map<String, Any?>): JSONObject {
    val o = JSONObject()
    map.forEach { (k, v) -> o.put(k, v ?: JSONObject.NULL) }
    return o
}
