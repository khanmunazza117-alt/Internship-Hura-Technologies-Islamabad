package com.mastercoding.invoicemaker.ui.theme

import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF0B1F3A)
val Teal = Color(0xFF0F766E)
val TealBright = Color(0xFF14B8A6)
val Gold = Color(0xFFC9A227)
val Coral = Color(0xFFE07A5F)
val Paper = Color(0xFFF6F1E8)
val PaperCard = Color(0xFFFFFBF5)
val Slate = Color(0xFF334155)
val Mist = Color(0xFFE2E8F0)

val DarkBg = Color(0xFF07111F)
val DarkSurface = Color(0xFF122033)
val DarkCard = Color(0xFF1A2B42)
