package com.mastercoding.invoicemaker.ui.home

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.data.DocumentEntity
import com.mastercoding.invoicemaker.data.LineItemEntity
import com.mastercoding.invoicemaker.data.PaymentEntity
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.BrandMark
import com.mastercoding.invoicemaker.ui.theme.Coral
import com.mastercoding.invoicemaker.ui.theme.Teal
import com.mastercoding.invoicemaker.util.MoneyFormat
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: AppViewModel,
    lang: String,
    dark: Boolean,
    docs: List<DocumentEntity>,
    lines: List<LineItemEntity>,
    pays: List<PaymentEntity>,
    onOpenList: (String) -> Unit,
    onNewInvoice: () -> Unit,
    onItems: () -> Unit,
    onReports: () -> Unit,
    onTemplates: () -> Unit,
    onSettings: () -> Unit,
    onPrivacy: () -> Unit,
    onLanguage: () -> Unit
) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val drawerWidth = LocalConfiguration.current.screenWidthDp.dp * 0.5f
    val online = remember { isOnline(context) }
    val invoiceDocs = docs.filter { it.type == "invoice" }
    val unpaid = invoiceDocs.count { d ->
        val st = vm.statusOf(d, lines.filter { it.documentId == d.id }, pays.filter { it.documentId == d.id })
        st == "unpaid" || st == "partial" || st == "draft"
    }
    val sales = invoiceDocs.sumOf { d ->
        vm.money(d, lines.filter { it.documentId == d.id }, pays.filter { it.documentId == d.id }).paid
    }

    BackHandler(enabled = drawer.isOpen) {
        scope.launch { drawer.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        gesturesEnabled = true,
        drawerContent = {
            Column(
                Modifier
                    .fillMaxHeight()
                    .requiredWidth(drawerWidth)
                    .width(drawerWidth)
                    .background(MaterialTheme.colorScheme.surface)
                    .statusBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                Column(Modifier.padding(20.dp)) {
                    BrandMark()
                    Spacer(Modifier.height(12.dp))
                    Text(t(lang, "app_name"), style = MaterialTheme.typography.titleLarge)
                    Text(t(lang, "tagline"), style = MaterialTheme.typography.bodySmall)
                }
                HorizontalDivider()
                NavigationDrawerItem(
                    label = {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Text(t(lang, "theme_dark"), modifier = Modifier.weight(1f))
                            Switch(checked = dark, onCheckedChange = { vm.setDark(it) })
                        }
                    },
                    selected = false,
                    onClick = { vm.setDark(!dark) },
                    icon = { Icon(Icons.Filled.Star, null) }
                )
                NavigationDrawerItem(
                    label = { Text(t(lang, "language")) },
                    selected = false,
                    onClick = { scope.launch { drawer.close() }; onLanguage() },
                    icon = { Icon(Icons.Filled.List, null) }
                )
                NavigationDrawerItem(
                    label = { Text(t(lang, "privacy")) },
                    selected = false,
                    onClick = { scope.launch { drawer.close() }; onPrivacy() },
                    icon = { Icon(Icons.Filled.Info, null) }
                )
                NavigationDrawerItem(
                    label = { Text(t(lang, "settings")) },
                    selected = false,
                    onClick = { scope.launch { drawer.close() }; onSettings() },
                    icon = { Icon(Icons.Filled.Settings, null) }
                )
                NavigationDrawerItem(
                    label = { Text(t(lang, "rate")) },
                    selected = false,
                    onClick = { rateApp(context) },
                    icon = { Icon(Icons.Filled.Star, null) }
                )
                NavigationDrawerItem(
                    label = { Text(t(lang, "share_app")) },
                    selected = false,
                    onClick = { shareApp(context, lang) },
                    icon = { Icon(Icons.Filled.Share, null) }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(t(lang, "home")) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "menu")
                        }
                    }
                )
            }
        ) { pad ->
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!online) {
                    item(span = { GridItemSpan(2) }) {
                        Card(colors = CardDefaults.cardColors(containerColor = Coral.copy(0.15f))) {
                            Text(t(lang, "offline"), Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                item(span = { GridItemSpan(2) }) {
                    Card(colors = CardDefaults.cardColors(containerColor = Teal), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text(t(lang, "sales"), color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.labelLarge)
                            Text(
                                MoneyFormat.format(sales, vm.business.value?.defaultCurrency ?: "USD"),
                                color = androidx.compose.ui.graphics.Color.White,
                                style = MaterialTheme.typography.displaySmall
                            )
                            Text("${unpaid} ${t(lang, "unpaid")}", color = androidx.compose.ui.graphics.Color.White.copy(0.85f))
                        }
                    }
                }
                item { DashCard(Icons.Filled.Edit, t(lang, "new_invoice"), onNewInvoice) }
                item { DashCard(Icons.Filled.List, t(lang, "invoices"), { onOpenList("invoice") }) }
                item { DashCard(Icons.Filled.ShoppingCart, t(lang, "unpaid"), { onOpenList("unpaid") }) }
                item { DashCard(Icons.Filled.ShoppingCart, t(lang, "items"), onItems) }
                item { DashCard(Icons.Filled.List, t(lang, "reports"), onReports) }
                item { DashCard(Icons.Filled.Favorite, t(lang, "templates"), onTemplates) }
            }
        }
    }
}

@Composable
private fun DashCard(icon: ImageVector, title: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(16.dp).height(96.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Teal, modifier = Modifier.size(28.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
        }
    }
}

private fun isOnline(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val net = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(net) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

private fun rateApp(context: Context) {
    val uri = Uri.parse("market://details?id=${context.packageName}")
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    }.onFailure {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${context.packageName}")))
    }
}

private fun shareApp(context: Context, lang: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "${t(lang, "share_msg")} https://play.google.com/store/apps/details?id=${context.packageName}")
    }
    context.startActivity(Intent.createChooser(send, t(lang, "share_app")))
}
