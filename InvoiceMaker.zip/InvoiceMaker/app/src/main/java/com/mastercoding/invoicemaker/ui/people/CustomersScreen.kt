package com.mastercoding.invoicemaker.ui.people

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.data.CustomerEntity
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.AppField
import com.mastercoding.invoicemaker.ui.theme.Teal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersScreen(vm: AppViewModel, lang: String, customers: List<CustomerEntity>, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<CustomerEntity?>(null) }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text(t(lang, "customers")) }, navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                editing = CustomerEntity(vm.newId(), "", "", "", "", 14, "")
            }, containerColor = Teal) { Icon(Icons.Filled.Add, null) }
        }
    ) { pad ->
        if (customers.isEmpty()) {
            Text(t(lang, "empty_customers"), Modifier.padding(pad).padding(24.dp))
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(customers, key = { it.id }) { c ->
                    Card(onClick = { editing = c }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp).fillMaxWidth()) {
                            Column(Modifier.weight(1f)) {
                                Text(c.name)
                                Text(c.email)
                                Text("${t(lang, "credit_days")}: ${c.creditDays}")
                            }
                            IconButton(onClick = { vm.deleteCustomer(c) }) { Icon(Icons.Filled.Delete, null) }
                        }
                    }
                }
            }
        }
    }
    editing?.let { c ->
        var name by remember(c.id) { mutableStateOf(c.name) }
        var email by remember(c.id) { mutableStateOf(c.email) }
        var phone by remember(c.id) { mutableStateOf(c.phone) }
        var address by remember(c.id) { mutableStateOf(c.address) }
        var days by remember(c.id) { mutableStateOf(c.creditDays.toString()) }
        AlertDialog(
            onDismissRequest = { editing = null },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveCustomer(c.copy(name = name, email = email, phone = phone, address = address, creditDays = days.toIntOrNull() ?: 14))
                    editing = null
                }) { Text(t(lang, "save")) }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text(t(lang, "cancel")) } },
            title = { Text(t(lang, "add_customer")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppField(name, { name = it }, t(lang, "name"))
                    AppField(email, { email = it }, t(lang, "email_field"), keyboardType = KeyboardType.Email)
                    AppField(phone, { phone = it }, t(lang, "phone"), keyboardType = KeyboardType.Phone)
                    AppField(address, { address = it }, t(lang, "address"))
                    AppField(days, { days = it }, t(lang, "credit_days"), keyboardType = KeyboardType.Number)
                }
            }
        )
    }
}
