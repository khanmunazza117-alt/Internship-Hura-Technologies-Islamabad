package com.mastercoding.invoicemaker.ui.terms

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.GoldBar
import com.mastercoding.invoicemaker.ui.components.PrimaryCta
import com.mastercoding.invoicemaker.ui.components.ScreenHeader

@Composable
fun TermsScreen(lang: String, onAccept: () -> Unit) {
    Scaffold { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(20.dp)
        ) {
            ScreenHeader(t(lang, "terms_title"), t(lang, "terms_intro"))
            Spacer(Modifier.height(12.dp))
            GoldBar()
            Spacer(Modifier.height(16.dp))
            Text(
                t(lang, "terms_body"),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())
            )
            Spacer(Modifier.height(16.dp))
            PrimaryCta(t(lang, "accept"), onClick = onAccept)
        }
    }
}
