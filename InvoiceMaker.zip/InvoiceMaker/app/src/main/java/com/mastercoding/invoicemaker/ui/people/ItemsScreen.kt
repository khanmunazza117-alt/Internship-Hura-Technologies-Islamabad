package com.mastercoding.invoicemaker.ui.people

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mastercoding.invoicemaker.AppViewModel
import com.mastercoding.invoicemaker.data.CatalogItemEntity
import com.mastercoding.invoicemaker.i18n.t
import com.mastercoding.invoicemaker.ui.components.AppField
import com.mastercoding.invoicemaker.ui.theme.Teal
import com.mastercoding.invoicemaker.util.MoneyFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemsScreen(vm: AppViewModel, lang: String, items: List<CatalogItemEntity>, currency: String, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<CatalogItemEntity?>(null) }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text(t(lang, "items")) }, navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            })
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editing = CatalogItemEntity(vm.newId(), "", "", "ea", 0.0, 0.0, 0.0) },
                containerColor = Teal
            ) { Icon(Icons.Filled.Add, null) }
        }
    ) { pad ->
        if (items.isEmpty()) {
            Text(t(lang, "empty_items"), Modifier.padding(pad).padding(24.dp))
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { i ->
                    Card(onClick = { editing = i }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(i.name)
                                Text("${MoneyFormat.format(i.price, currency)} · ${t(lang, "cost")} ${MoneyFormat.format(i.cost, currency)}")
                                Text("${t(lang, "tax")} ${i.taxPercent}%")
                            }
                            IconButton(onClick = { vm.deleteItem(i) }) { Icon(Icons.Filled.Delete, null) }
                        }
                    }
                }
            }
        }
    }
    editing?.let { i ->
        var name by remember(i.id) { mutableStateOf(i.name) }
        var desc by remember(i.id) { mutableStateOf(i.description) }
        var unit by remember(i.id) { mutableStateOf(i.unit) }
        var price by remember(i.id) { mutableStateOf(i.price.toString()) }
        var cost by remember(i.id) { mutableStateOf(i.cost.toString()) }
        var tax by remember(i.id) { mutableStateOf(i.taxPercent.toString()) }
        AlertDialog(
            onDismissRequest = { editing = null },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveItem(
                        i.copy(
                            name = name, description = desc, unit = unit,
                            price = price.toDoubleOrNull() ?: 0.0,
                            cost = cost.toDoubleOrNull() ?: 0.0,
                            taxPercent = tax.toDoubleOrNull() ?: 0.0
                        )
                    )
                    editing = null
                }) { Text(t(lang, "save")) }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text(t(lang, "cancel")) } },
            title = { Text(t(lang, "items")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppField(name, { name = it }, t(lang, "name"))
                    AppField(desc, { desc = it }, t(lang, "desc"))
                    AppField(unit, { unit = it }, t(lang, "unit"))
                    AppField(price, { price = it }, t(lang, "price"), keyboardType = KeyboardType.Decimal)
                    AppField(cost, { cost = it }, t(lang, "cost"), keyboardType = KeyboardType.Decimal)
                    AppField(tax, { tax = it }, t(lang, "tax"), keyboardType = KeyboardType.Decimal)
                }
            }
        )
    }
}
