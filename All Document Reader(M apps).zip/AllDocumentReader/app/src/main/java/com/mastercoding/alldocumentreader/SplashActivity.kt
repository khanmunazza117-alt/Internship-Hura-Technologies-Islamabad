package com.mastercoding.alldocumentreader

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupEdgeToEdge()
        setContentView(R.layout.activity_splash)

        findViewById<View>(R.id.splashRoot).applySystemBarInsets()

        val progressBar = findViewById<ProgressBar>(R.id.splashProgress)
        val animator = ObjectAnimator.ofInt(progressBar, "progress", 0, 100).apply {
            duration = 2500L
            interpolator = DecelerateInterpolator()
        }
        animator.start()

        progressBar.postDelayed({ navigateNext() }, 2600L)
    }

    private fun navigateNext() {
        val intent = when {
            PreferenceHelper.isTermsAccepted(this) -> {
                Intent(this, MainActivity::class.java)
            }
            PreferenceHelper.isOnboardingDone(this) -> {
                Intent(this, TermsActivity::class.java)
            }
            else -> {
                Intent(this, OnboardingActivity::class.java)
            }
        }
        startActivity(intent)
        finish()
    }
}
