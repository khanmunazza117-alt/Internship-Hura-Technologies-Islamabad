package com.mastercoding.alldocumentreader.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mastercoding.alldocumentreader.R
import com.mastercoding.alldocumentreader.model.CategoryItem

class CategoryAdapter(
    private val items: List<CategoryItem>,
    private val onItemClick: (CategoryItem) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    class CategoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val cardRoot: View = view.findViewById(R.id.categoryCardRoot)

        val iconBg: View = view.findViewById(R.id.categoryIconBg)

        val icon: ImageView = view.findViewById(R.id.categoryIcon)

        val count: TextView = view.findViewById(R.id.categoryCount)

        val title: TextView = view.findViewById(R.id.categoryTitle)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CategoryViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category_card, parent, false)

        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: CategoryViewHolder,
        position: Int
    ) {

        val item = items[position]

        // Card background
        holder.cardRoot.setBackgroundResource(item.cardBgRes)

        // Icon background
        holder.iconBg.setBackgroundResource(item.iconBgRes)

        // Category icon
        holder.icon.setImageResource(item.iconRes)

        // Count
        holder.count.text = String.format("%02d >", item.count)

        // Title
        holder.title.setText(item.titleRes)

        // Click
        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }
}