package com.mastercoding.alldocumentreader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mastercoding.alldocumentreader.adapter.SettingItem
import com.mastercoding.alldocumentreader.adapter.SettingsAdapter

class SettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        return inflater.inflate(
            R.layout.fragment_settings,
            container,
            false
        )
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {

        super.onViewCreated(
            view,
            savedInstanceState
        )

        val settingsRecycler =
            view.findViewById<RecyclerView>(
                R.id.settingsRecycler
            )

        val items = listOf(

            // =================================================
            // LANGUAGES
            // =================================================

            SettingItem(
                R.drawable.setting_language,
                R.string.setting_languages
            ) {
                showLanguageDialog()
            },

            // =================================================
            // PRIVACY POLICY
            // =================================================

            SettingItem(
                R.drawable.setting_privacy,
                R.string.setting_privacy_policy
            ) {
                openPrivacyPolicy()
            },

            // =================================================
            // SHARE US
            // =================================================

            SettingItem(
                R.drawable.setting_share,
                R.string.setting_share_us
            ) {
                shareApp()
            },

            // =================================================
            // RATE US
            // =================================================

            SettingItem(
                R.drawable.setting_rate,
                R.string.setting_rate_us
            ) {
                rateApp()
            }
        )

        settingsRecycler.layoutManager =
            LinearLayoutManager(
                requireContext(),
                LinearLayoutManager.VERTICAL,
                false
            )

        settingsRecycler.adapter =
            SettingsAdapter(items)

        settingsRecycler.isNestedScrollingEnabled = false
    }

    // =========================================================
    // LANGUAGE DIALOG
    // =========================================================

    private fun showLanguageDialog() {

        val languages = arrayOf(
            "English",
            "Urdu",
            "Arabic"
        )

        AlertDialog.Builder(requireContext())
            .setTitle("Languages")
            .setItems(languages) { _, which ->

                val selectedLanguage =
                    languages[which]

                Toast.makeText(
                    requireContext(),
                    "$selectedLanguage selected",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    // =========================================================
    // PRIVACY POLICY
    // =========================================================

    private fun openPrivacyPolicy() {

        val intent = Intent(
            requireContext(),
            PrivacyPolicyActivity::class.java
        )

        startActivity(intent)
    }

    // =========================================================
    // SHARE APP
    // =========================================================

    private fun shareApp() {

        val intent =
            Intent(Intent.ACTION_SEND).apply {

                type = "text/plain"

                putExtra(
                    Intent.EXTRA_TEXT,
                    getString(
                        R.string.share_message
                    )
                )
            }

        startActivity(
            Intent.createChooser(
                intent,
                getString(
                    R.string.setting_share_us
                )
            )
        )
    }

    // =========================================================
    // RATE APP
    // =========================================================

    private fun rateApp() {

        val packageName =
            requireContext().packageName

        try {

            val marketIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse(
                    "market://details?id=$packageName"
                )
            )

            startActivity(marketIntent)

        } catch (e: Exception) {

            val browserIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse(
                    "https://play.google.com/store/apps/details?id=$packageName"
                )
            )

            startActivity(browserIntent)
        }
    }
}