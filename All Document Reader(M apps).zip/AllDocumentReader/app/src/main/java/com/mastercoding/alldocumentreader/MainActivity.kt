package com.mastercoding.alldocumentreader

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TAB = "extra_tab"

        const val TAB_HOME = "home"
        const val TAB_SETTINGS = "settings"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge
        setupEdgeToEdge()

        setContentView(R.layout.activity_main)

        // -----------------------------------------------------
        // SYSTEM BAR INSETS
        // -----------------------------------------------------

        findViewById<View>(R.id.mainRoot).applySystemBarInsets(
            applyBottom = false
        )

        findViewById<View>(R.id.bottomNav).applySystemBarInsets(
            applyLeft = false,
            applyTop = false,
            applyRight = false
        )

        // -----------------------------------------------------
        // STARTING TAB
        // -----------------------------------------------------

        val startTab =
            intent.getStringExtra(EXTRA_TAB) ?: TAB_HOME

        if (savedInstanceState == null) {

            if (startTab == TAB_SETTINGS) {

                showFragment(SettingsFragment())

            } else {

                showFragment(HomeFragment())
            }
        }

        // -----------------------------------------------------
        // BOTTOM NAVIGATION
        // -----------------------------------------------------

        setupBottomNav(
            if (startTab == TAB_SETTINGS) {
                BottomNavHelper.Tab.SETTINGS
            } else {
                BottomNavHelper.Tab.HOME
            }
        )
    }

    // ---------------------------------------------------------
    // NEW INTENT
    // ---------------------------------------------------------

    override fun onNewIntent(intent: Intent) {

        super.onNewIntent(intent)

        setIntent(intent)

        val tab =
            intent.getStringExtra(EXTRA_TAB) ?: TAB_HOME

        if (tab == TAB_SETTINGS) {

            showFragment(SettingsFragment())

            setupBottomNav(
                BottomNavHelper.Tab.SETTINGS
            )

        } else {

            showFragment(HomeFragment())

            setupBottomNav(
                BottomNavHelper.Tab.HOME
            )
        }
    }

    // ---------------------------------------------------------
    // BOTTOM NAVIGATION SETUP
    // ---------------------------------------------------------

    private fun setupBottomNav(
        activeTab: BottomNavHelper.Tab
    ) {

        BottomNavHelper.setup(

            context = this,

            root = findViewById(R.id.bottomNav),

            activeTab = activeTab,

            onHomeClick = {

                showFragment(HomeFragment())

                setupBottomNav(
                    BottomNavHelper.Tab.HOME
                )
            },

            onSettingsClick = {

                showFragment(SettingsFragment())

                setupBottomNav(
                    BottomNavHelper.Tab.SETTINGS
                )
            }
        )
    }

    // ---------------------------------------------------------
    // SHOW FRAGMENT
    // ---------------------------------------------------------

    private fun showFragment(
        fragment: Fragment
    ) {

        supportFragmentManager
            .beginTransaction()
            .replace(
                R.id.fragmentContainer,
                fragment
            )
            .commit()
    }
}