package com.mastercoding.alldocumentreader.model

enum class DocumentType {
    PDF, PPT, DOC, XLS, TXT
}

enum class FileCategory {
    ALL, FAVOURITE, PDF, PPT, DOC, XLS, TXT;

    fun titleRes(): Int = when (this) {
        ALL -> com.mastercoding.alldocumentreader.R.string.category_all_files
        FAVOURITE -> com.mastercoding.alldocumentreader.R.string.category_favourite_files
        PDF -> com.mastercoding.alldocumentreader.R.string.category_pdf_files
        PPT -> com.mastercoding.alldocumentreader.R.string.category_ppt_files
        DOC -> com.mastercoding.alldocumentreader.R.string.category_doc_files
        XLS -> com.mastercoding.alldocumentreader.R.string.category_xls_files
        TXT -> com.mastercoding.alldocumentreader.R.string.category_txt_files
    }
}

data class DocumentItem(
    val id: Int,
    var name: String,
    val size: String,
    val type: DocumentType,
    var isFavorite: Boolean
)

data class CategoryItem(
    val category: FileCategory,
    val titleRes: Int,
    val count: Int,
    val iconBgRes: Int,
    val iconRes: Int,
    val cardBgRes: Int
)
