package com.mastercoding.alldocumentreader

import android.content.Context

object PreferenceHelper {

    private const val PREFS_NAME = "app_prefs"
    private const val KEY_ONBOARDING_DONE = "onboarding_done"
    private const val KEY_TERMS_ACCEPTED = "terms_accepted"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isOnboardingDone(context: Context): Boolean =
        prefs(context).getBoolean(KEY_ONBOARDING_DONE, false)

    fun setOnboardingDone(context: Context) {
        prefs(context).edit().putBoolean(KEY_ONBOARDING_DONE, true).apply()
    }

    fun isTermsAccepted(context: Context): Boolean =
        prefs(context).getBoolean(KEY_TERMS_ACCEPTED, false)

    fun setTermsAccepted(context: Context) {
        prefs(context).edit().putBoolean(KEY_TERMS_ACCEPTED, true).apply()
    }
}
