package com.mastercoding.alldocumentreader

import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

private val initialPaddingTag = R.id.tag_initial_padding

private data class ViewPadding(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
)

fun ComponentActivity.setupEdgeToEdge() {
    enableEdgeToEdge()
    WindowCompat.getInsetsController(window, window.decorView).apply {
        isAppearanceLightStatusBars = true
        isAppearanceLightNavigationBars = true
    }
}

fun View.applySystemBarInsets(
    applyLeft: Boolean = true,
    applyTop: Boolean = true,
    applyRight: Boolean = true,
    applyBottom: Boolean = true
) {
    val initialPadding = (getTag(initialPaddingTag) as? ViewPadding)
        ?: ViewPadding(paddingLeft, paddingTop, paddingRight, paddingBottom).also {
            setTag(initialPaddingTag, it)
        }

    ViewCompat.setOnApplyWindowInsetsListener(this) { view, windowInsets ->
        val insets = windowInsets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        )
        view.updatePadding(
            left = if (applyLeft) initialPadding.left + insets.left else view.paddingLeft,
            top = if (applyTop) initialPadding.top + insets.top else view.paddingTop,
            right = if (applyRight) initialPadding.right + insets.right else view.paddingRight,
            bottom = if (applyBottom) initialPadding.bottom + insets.bottom else view.paddingBottom
        )
        windowInsets
    }

    if (ViewCompat.isAttachedToWindow(this)) {
        ViewCompat.requestApplyInsets(this)
    } else {
        addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                v.removeOnAttachStateChangeListener(this)
                ViewCompat.requestApplyInsets(v)
            }

            override fun onViewDetachedFromWindow(v: View) = Unit
        })
    }
}

fun View.applySystemBarMargin(
    applyLeft: Boolean = true,
    applyTop: Boolean = true,
    applyRight: Boolean = true,
    applyBottom: Boolean = true
) {
    val initialMargin = (getTag(initialPaddingTag) as? ViewPadding)
        ?: run {
            val params = layoutParams as? android.view.ViewGroup.MarginLayoutParams
            ViewPadding(
                params?.leftMargin ?: 0,
                params?.topMargin ?: 0,
                params?.rightMargin ?: 0,
                params?.bottomMargin ?: 0
            ).also { setTag(initialPaddingTag, it) }
        }

    ViewCompat.setOnApplyWindowInsetsListener(this) { view, windowInsets ->
        val insets = windowInsets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        )
        val params = view.layoutParams as? android.view.ViewGroup.MarginLayoutParams
        if (params != null) {
            params.leftMargin = if (applyLeft) initialMargin.left + insets.left else params.leftMargin
            params.topMargin = if (applyTop) initialMargin.top + insets.top else params.topMargin
            params.rightMargin = if (applyRight) initialMargin.right + insets.right else params.rightMargin
            params.bottomMargin = if (applyBottom) initialMargin.bottom + insets.bottom else params.bottomMargin
            view.layoutParams = params
        }
        windowInsets
    }

    if (ViewCompat.isAttachedToWindow(this)) {
        ViewCompat.requestApplyInsets(this)
    } else {
        addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                v.removeOnAttachStateChangeListener(this)
                ViewCompat.requestApplyInsets(v)
            }

            override fun onViewDetachedFromWindow(v: View) = Unit
        })
    }
}
