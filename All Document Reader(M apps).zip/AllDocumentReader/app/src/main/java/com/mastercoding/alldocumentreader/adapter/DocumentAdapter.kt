package com.mastercoding.alldocumentreader.adapter

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mastercoding.alldocumentreader.R
import com.mastercoding.alldocumentreader.data.DocumentRepository
import com.mastercoding.alldocumentreader.model.DocumentItem

class DocumentAdapter(
    private var items: List<DocumentItem>,
    private val showSize: Boolean = true,
    private val onFavoriteToggle: (DocumentItem) -> Unit,
    private val onRename: (DocumentItem) -> Unit,
    private val onShare: (DocumentItem) -> Unit,
    private val onDelete: (DocumentItem) -> Unit
) : RecyclerView.Adapter<DocumentAdapter.DocumentViewHolder>() {

    class DocumentViewHolder(
        view: View
    ) : RecyclerView.ViewHolder(view) {

        val iconBg: View =
            view.findViewById(R.id.fileIconBg)

        val icon: ImageView =
            view.findViewById(R.id.fileIcon)

        val name: TextView =
            view.findViewById(R.id.fileName)

        val size: TextView =
            view.findViewById(R.id.fileSize)

        val favorite: ImageView =
            view.findViewById(R.id.fileFavorite)

        val more: ImageView =
            view.findViewById(R.id.fileMore)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): DocumentViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_document,
                parent,
                false
            )

        return DocumentViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: DocumentViewHolder,
        position: Int
    ) {

        val item = items[position]

        // -----------------------------------------------------
        // FILE ICON
        // -----------------------------------------------------

        holder.iconBg.setBackgroundResource(
            DocumentRepository.getIconBgForType(item.type)
        )

        holder.icon.setImageResource(
            DocumentRepository.getIconForType(item.type)
        )

        holder.icon.scaleType =
            ImageView.ScaleType.CENTER_INSIDE

        // -----------------------------------------------------
        // NAME
        // -----------------------------------------------------

        holder.name.text = item.name

        // -----------------------------------------------------
        // SIZE
        // -----------------------------------------------------

        holder.size.text = item.size

        holder.size.visibility =
            if (showSize) {
                View.VISIBLE
            } else {
                View.GONE
            }

        // -----------------------------------------------------
        // FAVORITE
        // -----------------------------------------------------

        holder.favorite.setImageResource(
            if (item.isFavorite) {
                R.drawable.ic_star_filled
            } else {
                R.drawable.ic_star_outline
            }
        )

        holder.favorite.scaleType =
            ImageView.ScaleType.CENTER_INSIDE

        holder.favorite.setOnClickListener {

            onFavoriteToggle(item)

            holder.favorite.setImageResource(
                if (item.isFavorite) {
                    R.drawable.ic_star_filled
                } else {
                    R.drawable.ic_star_outline
                }
            )
        }

        // -----------------------------------------------------
        // MORE ICON
        // -----------------------------------------------------

        holder.more.setImageResource(
            R.drawable.ic_more
        )

        holder.more.scaleType =
            ImageView.ScaleType.CENTER_INSIDE

        // -----------------------------------------------------
        // MORE CLICK
        // -----------------------------------------------------

        holder.more.setOnClickListener {

            showFigmaPopup(
                holder.more,
                item
            )
        }
    }

    // =========================================================
    // FIGMA POPUP
    // =========================================================

    private fun showFigmaPopup(
        anchor: View,
        item: DocumentItem
    ) {

        val context = anchor.context

        val popupView = LayoutInflater
            .from(context)
            .inflate(
                R.layout.item_file_options_popup,
                null,
                false
            )

        val density =
            context.resources.displayMetrics.density

        // Popup width = 138dp
        val popupWidth =
            (138 * density).toInt()

        // Popup height:
        // 3 x 36dp + dividers + padding
        val popupHeight =
            (116 * density).toInt()

        val popupWindow = PopupWindow(
            popupView,
            popupWidth,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )

        popupWindow.setBackgroundDrawable(
            ColorDrawable(Color.TRANSPARENT)
        )

        popupWindow.isFocusable = true
        popupWindow.isOutsideTouchable = true
        popupWindow.elevation = 8f

        // -----------------------------------------------------
        // RENAME
        // -----------------------------------------------------

        popupView.findViewById<View>(
            R.id.menuRename
        ).setOnClickListener {

            popupWindow.dismiss()

            onRename(item)
        }

        // -----------------------------------------------------
        // SHARE
        // -----------------------------------------------------

        popupView.findViewById<View>(
            R.id.menuShare
        ).setOnClickListener {

            popupWindow.dismiss()

            onShare(item)
        }

        // -----------------------------------------------------
        // DELETE
        // -----------------------------------------------------

        popupView.findViewById<View>(
            R.id.menuDelete
        ).setOnClickListener {

            popupWindow.dismiss()

            onDelete(item)
        }

        // -----------------------------------------------------
        // POSITION
        //
        // Right side of popup aligns close to the
        // three-dot button.
        // Popup is vertically centered around the button.
        // -----------------------------------------------------

        val xOffset =
            -popupWidth + anchor.width

        val yOffset =
            -(
                    (popupHeight - anchor.height) / 2
                    )

        popupWindow.showAsDropDown(
            anchor,
            xOffset,
            yOffset,
            Gravity.END
        )
    }

    // =========================================================
    // UPDATE
    // =========================================================

    fun updateItems(
        newItems: List<DocumentItem>
    ) {

        items = newItems

        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return items.size
    }
}