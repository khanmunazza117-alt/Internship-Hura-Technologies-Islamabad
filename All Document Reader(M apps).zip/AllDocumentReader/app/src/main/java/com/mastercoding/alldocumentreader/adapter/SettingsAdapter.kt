package com.mastercoding.alldocumentreader.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mastercoding.alldocumentreader.R

data class SettingItem(
    val iconRes: Int,
    val titleRes: Int,
    val action: () -> Unit
)

class SettingsAdapter(
    private val items: List<SettingItem>
) : RecyclerView.Adapter<SettingsAdapter.SettingViewHolder>() {

    class SettingViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val icon: ImageView =
            view.findViewById(R.id.settingIcon)

        val title: TextView =
            view.findViewById(R.id.settingTitle)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SettingViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_setting,
                parent,
                false
            )

        return SettingViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: SettingViewHolder,
        position: Int
    ) {

        val item = items[position]

        holder.icon.clearColorFilter()
        holder.icon.setImageResource(item.iconRes)

        holder.title.setText(item.titleRes)

        holder.itemView.setOnClickListener {
            item.action()
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }
}