package com.mastercoding.alldocumentreader

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mastercoding.alldocumentreader.adapter.DocumentAdapter
import com.mastercoding.alldocumentreader.data.DocumentRepository
import com.mastercoding.alldocumentreader.model.DocumentItem
import com.mastercoding.alldocumentreader.model.FileCategory

class FileListActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CATEGORY = "extra_category"
    }

    private lateinit var category: FileCategory
    private lateinit var documentAdapter: DocumentAdapter
    private lateinit var fileRecycler: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // -----------------------------------------------------
        // EDGE TO EDGE
        // -----------------------------------------------------

        setupEdgeToEdge()

        setContentView(R.layout.activity_file_list)

        // -----------------------------------------------------
        // SYSTEM BAR INSETS
        // -----------------------------------------------------

        findViewById<View>(R.id.fileListRoot)
            .applySystemBarInsets(
                applyBottom = false
            )

        findViewById<View>(R.id.bottomNav)
            .applySystemBarInsets(
                applyLeft = false,
                applyTop = false,
                applyRight = false
            )

        // -----------------------------------------------------
        // GET CATEGORY
        // -----------------------------------------------------

        val categoryName =
            intent.getStringExtra(EXTRA_CATEGORY)
                ?: FileCategory.ALL.name

        category = try {
            FileCategory.valueOf(categoryName)
        } catch (e: IllegalArgumentException) {
            FileCategory.ALL
        }

        // -----------------------------------------------------
        // HEADER
        // -----------------------------------------------------

        val title =
            findViewById<TextView>(R.id.fileListTitle)

        title.setText(
            category.titleRes()
        )

        val backButton =
            findViewById<ImageView>(R.id.btnBack)

        backButton.setOnClickListener {
            finish()
        }

        // -----------------------------------------------------
        // RECYCLER VIEW
        // -----------------------------------------------------

        fileRecycler =
            findViewById(R.id.fileRecycler)

        setupRecyclerView()

        // -----------------------------------------------------
        // BOTTOM NAVIGATION
        // -----------------------------------------------------

        BottomNavHelper.setup(
            context = this,
            root = findViewById(R.id.bottomNav),
            activeTab = BottomNavHelper.Tab.HOME
        )
    }

    // =========================================================
    // RECYCLER VIEW SETUP
    // =========================================================

    private fun setupRecyclerView() {

        documentAdapter = DocumentAdapter(

            items = DocumentRepository
                .getDocumentsByCategory(category),

            showSize = true,

            // -------------------------------------------------
            // FAVORITE
            // -------------------------------------------------

            onFavoriteToggle = { item ->
                toggleFavorite(item)
            },

            // -------------------------------------------------
            // RENAME
            // -------------------------------------------------

            onRename = { item ->
                showRenameDialog(item)
            },

            // -------------------------------------------------
            // SHARE
            // -------------------------------------------------

            onShare = { item ->
                shareDocument(item)
            },

            // -------------------------------------------------
            // DELETE
            // -------------------------------------------------

            onDelete = { item ->
                deleteDocument(item)
            }
        )

        fileRecycler.layoutManager =
            LinearLayoutManager(
                this,
                LinearLayoutManager.VERTICAL,
                false
            )

        fileRecycler.adapter =
            documentAdapter

        fileRecycler.isNestedScrollingEnabled = true

        fileRecycler.setHasFixedSize(false)
    }

    // =========================================================
    // REFRESH LIST
    // =========================================================

    private fun refreshList() {

        documentAdapter.updateItems(
            DocumentRepository
                .getDocumentsByCategory(category)
        )
    }

    // =========================================================
    // FAVORITE
    // =========================================================

    private fun toggleFavorite(
        item: DocumentItem
    ) {

        DocumentRepository.toggleFavorite(item.id)

        if (category == FileCategory.FAVOURITE) {

            // Remove from Favourite screen
            // when user unfavorites it.
            refreshList()

        } else {

            // Keep current screen and refresh star.
            documentAdapter.notifyDataSetChanged()
        }
    }

    // =========================================================
    // RENAME
    // =========================================================

    private fun showRenameDialog(
        item: DocumentItem
    ) {

        val input = EditText(this).apply {

            setText(item.name)

            setSelection(
                text.length
            )

            setSingleLine(true)

            val density =
                resources.displayMetrics.density

            val horizontalPadding =
                (24 * density).toInt()

            val verticalPadding =
                (12 * density).toInt()

            setPadding(
                horizontalPadding,
                verticalPadding,
                horizontalPadding,
                verticalPadding
            )
        }

        AlertDialog.Builder(this)

            .setTitle(
                R.string.rename_file
            )

            .setView(input)

            .setPositiveButton(
                R.string.accept
            ) { _, _ ->

                val newName =
                    input.text
                        .toString()
                        .trim()

                if (newName.isNotEmpty()) {

                    DocumentRepository.renameDocument(
                        item.id,
                        newName
                    )

                    refreshList()

                } else {

                    Toast.makeText(
                        this,
                        "File name cannot be empty",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            .setNegativeButton(
                R.string.decline,
                null
            )

            .show()
    }

    // =========================================================
    // SHARE
    // =========================================================

    private fun shareDocument(
        item: DocumentItem
    ) {

        val intent =
            Intent(Intent.ACTION_SEND).apply {

                type = "text/plain"

                putExtra(
                    Intent.EXTRA_TEXT,
                    item.name
                )
            }

        startActivity(
            Intent.createChooser(
                intent,
                getString(
                    R.string.action_share
                )
            )
        )
    }

    // =========================================================
    // DELETE
    // =========================================================

    private fun deleteDocument(
        item: DocumentItem
    ) {

        AlertDialog.Builder(this)

            .setTitle(
                R.string.action_delete
            )

            .setMessage(
                getString(
                    R.string.delete_confirm,
                    item.name
                )
            )

            .setPositiveButton(
                R.string.action_delete
            ) { _, _ ->

                DocumentRepository.deleteDocument(
                    item.id
                )

                refreshList()

                Toast.makeText(
                    this,
                    R.string.file_deleted,
                    Toast.LENGTH_SHORT
                ).show()
            }

            .setNegativeButton(
                R.string.decline,
                null
            )

            .show()
    }

    // =========================================================
    // RESUME
    // =========================================================

    override fun onResume() {

        super.onResume()

        if (::documentAdapter.isInitialized) {
            refreshList()
        }
    }
}