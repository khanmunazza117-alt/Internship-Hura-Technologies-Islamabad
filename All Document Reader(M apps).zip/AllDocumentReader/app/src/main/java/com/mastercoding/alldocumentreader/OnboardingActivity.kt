package com.mastercoding.alldocumentreader

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2

class OnboardingActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var titleText: TextView
    private lateinit var descriptionText: TextView
    private lateinit var dot1: View
    private lateinit var dot2: View
    private lateinit var dot3: View
    private lateinit var btnNext: TextView

    private val pages = listOf(
        OnboardingPage(
            R.drawable.ic_onboarding_1,
            R.string.onboarding_title_1,
            R.string.onboarding_desc_1
        ),
        OnboardingPage(
            R.drawable.ic_onboarding_2,
            R.string.onboarding_title_2,
            R.string.onboarding_desc_2
        ),
        OnboardingPage(
            R.drawable.ic_onboarding_3,
            R.string.onboarding_title_3,
            R.string.onboarding_desc_3
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupEdgeToEdge()
        setContentView(R.layout.activity_onboarding)

        findViewById<View>(R.id.onboardingRoot).applySystemBarInsets(applyBottom = false)
        findViewById<View>(R.id.bottomCard).applySystemBarMargin(
            applyLeft = false,
            applyTop = false,
            applyRight = false
        )

        viewPager = findViewById(R.id.onboardingViewPager)
        titleText = findViewById(R.id.onboardingTitle)
        descriptionText = findViewById(R.id.onboardingDescription)
        dot1 = findViewById(R.id.dot1)
        dot2 = findViewById(R.id.dot2)
        dot3 = findViewById(R.id.dot3)
        btnNext = findViewById(R.id.btnNext)

        viewPager.adapter = OnboardingAdapter(pages)
        updatePageContent(0)

        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updatePageContent(position)
            }
        })

        btnNext.setOnClickListener {
            if (viewPager.currentItem < pages.lastIndex) {
                viewPager.currentItem += 1
            } else {
                PreferenceHelper.setOnboardingDone(this)
                startActivity(Intent(this, TermsActivity::class.java))
                finish()
            }
        }
    }

    private fun updatePageContent(position: Int) {
        val page = pages[position]
        titleText.setText(page.titleRes)
        descriptionText.setText(page.descriptionRes)
        updateDots(position)
    }

    private fun updateDots(activeIndex: Int) {
        val dots = listOf(dot1, dot2, dot3)
        dots.forEachIndexed { index, dot ->
            if (index == activeIndex) {
                dot.setBackgroundResource(R.drawable.dot_active)
                val params = dot.layoutParams
                params.width = resources.getDimensionPixelSize(R.dimen.dot_active_size)
                params.height = resources.getDimensionPixelSize(R.dimen.dot_active_size)
                dot.layoutParams = params
            } else {
                dot.setBackgroundResource(R.drawable.dot_inactive)
                val params = dot.layoutParams
                params.width = resources.getDimensionPixelSize(R.dimen.dot_inactive_size)
                params.height = resources.getDimensionPixelSize(R.dimen.dot_inactive_size)
                dot.layoutParams = params
            }
        }
    }
}
