package com.mastercoding.alldocumentreader.data

import com.mastercoding.alldocumentreader.R
import com.mastercoding.alldocumentreader.model.CategoryItem
import com.mastercoding.alldocumentreader.model.DocumentItem
import com.mastercoding.alldocumentreader.model.DocumentType
import com.mastercoding.alldocumentreader.model.FileCategory

object DocumentRepository {

    private val documents = mutableListOf(

        DocumentItem(
            1,
            "File 01.pdf",
            "02 MB",
            DocumentType.PDF,
            true
        ),

        DocumentItem(
            2,
            "File 02.ppt",
            "02 MB",
            DocumentType.PPT,
            false
        ),

        DocumentItem(
            3,
            "New file.pdf",
            "02 MB",
            DocumentType.PDF,
            false
        ),

        DocumentItem(
            4,
            "Work.ppt",
            "02 MB",
            DocumentType.PPT,
            false
        ),

        DocumentItem(
            5,
            "File 01.doc",
            "02 MB",
            DocumentType.DOC,
            true
        ),

        DocumentItem(
            6,
            "File 02.doc",
            "02 MB",
            DocumentType.DOC,
            false
        ),

        DocumentItem(
            7,
            "File 01.xls",
            "02 MB",
            DocumentType.XLS,
            true
        ),

        DocumentItem(
            8,
            "File 02.xls",
            "02 MB",
            DocumentType.XLS,
            false
        ),

        DocumentItem(
            9,
            "File 01.txt",
            "02 MB",
            DocumentType.TXT,
            true
        ),

        DocumentItem(
            10,
            "File 02.txt",
            "02 MB",
            DocumentType.TXT,
            false
        ),

        DocumentItem(
            11,
            "Report.pdf",
            "02 MB",
            DocumentType.PDF,
            false
        ),

        DocumentItem(
            12,
            "Notes.doc",
            "02 MB",
            DocumentType.DOC,
            false
        )
    )

    // ---------------------------------------------------------
    // ALL DOCUMENTS
    // ---------------------------------------------------------

    fun getAllDocuments(): List<DocumentItem> {
        return documents.toList()
    }

    // ---------------------------------------------------------
    // RECENT DOCUMENTS
    // ---------------------------------------------------------

    fun getRecentDocuments(): List<DocumentItem> {
        return documents.take(4)
    }

    // ---------------------------------------------------------
    // DOCUMENTS BY CATEGORY
    // ---------------------------------------------------------

    fun getDocumentsByCategory(
        category: FileCategory
    ): List<DocumentItem> {

        return when (category) {

            FileCategory.ALL -> {
                documents.toList()
            }

            FileCategory.FAVOURITE -> {
                documents.filter {
                    it.isFavorite
                }
            }

            FileCategory.PDF -> {
                documents.filter {
                    it.type == DocumentType.PDF
                }
            }

            FileCategory.PPT -> {
                documents.filter {
                    it.type == DocumentType.PPT
                }
            }

            FileCategory.DOC -> {
                documents.filter {
                    it.type == DocumentType.DOC
                }
            }

            FileCategory.XLS -> {
                documents.filter {
                    it.type == DocumentType.XLS
                }
            }

            FileCategory.TXT -> {
                documents.filter {
                    it.type == DocumentType.TXT
                }
            }
        }
    }

    // ---------------------------------------------------------
    // REAL CATEGORY COUNT
    // ---------------------------------------------------------

    fun getCategoryCount(
        category: FileCategory
    ): Int {

        return getDocumentsByCategory(category).size
    }

    // ---------------------------------------------------------
    // HOME SCREEN CATEGORY CARDS
    // ---------------------------------------------------------

    fun getCategories(): List<CategoryItem> {

        return listOf(

            // ALL FILES
            CategoryItem(
                FileCategory.ALL,
                R.string.category_all_files,
                120,
                R.drawable.bg_icon_all,
                R.drawable.ic_type_all,
                R.drawable.bg_card_all
            ),

            // FAVOURITE FILES
            CategoryItem(
                FileCategory.FAVOURITE,
                R.string.category_favourite_files,
                7,
                R.drawable.bg_icon_fav,
                R.drawable.ic_type_fav,
                R.drawable.bg_card_fav
            ),

            // PDF FILES
            CategoryItem(
                FileCategory.PDF,
                R.string.category_pdf_files,
                21,
                R.drawable.bg_icon_pdf,
                R.drawable.ic_type_pdf,
                R.drawable.bg_card_pdf
            ),

            // PPT FILES
            CategoryItem(
                FileCategory.PPT,
                R.string.category_ppt_files,
                14,
                R.drawable.bg_icon_ppt,
                R.drawable.ic_type_ppt,
                R.drawable.bg_card_ppt
            ),

            // DOC FILES
            CategoryItem(
                FileCategory.DOC,
                R.string.category_doc_files,
                9,
                R.drawable.bg_icon_doc,
                R.drawable.ic_type_doc,
                R.drawable.bg_card_doc
            ),

            // XLS FILES
            CategoryItem(
                FileCategory.XLS,
                R.string.category_xls_files,
                34,
                R.drawable.bg_icon_xls,
                R.drawable.ic_type_xls,
                R.drawable.bg_card_xls
            ),

            // TXT FILES
            CategoryItem(
                FileCategory.TXT,
                R.string.category_txt_files,
                66,
                R.drawable.bg_icon_txt,
                R.drawable.ic_type_txt,
                R.drawable.bg_card_txt
            )
        )
    }

    // ---------------------------------------------------------
    // FAVOURITE
    // ---------------------------------------------------------

    fun toggleFavorite(id: Int) {

        documents.find {
            it.id == id
        }?.let { document ->

            document.isFavorite = !document.isFavorite
        }
    }

    // ---------------------------------------------------------
    // RENAME
    // ---------------------------------------------------------

    fun renameDocument(
        id: Int,
        newName: String
    ) {

        documents.find {
            it.id == id
        }?.let { document ->

            document.name = newName
        }
    }

    // ---------------------------------------------------------
    // DELETE
    // ---------------------------------------------------------

    fun deleteDocument(id: Int) {

        documents.removeAll {
            it.id == id
        }
    }

    // ---------------------------------------------------------
    // DOCUMENT ICON
    // ---------------------------------------------------------

    fun getIconForType(
        type: DocumentType
    ): Int {

        return when (type) {

            DocumentType.PDF ->
                R.drawable.ic_type_pdf

            DocumentType.PPT ->
                R.drawable.ic_type_ppt

            DocumentType.DOC ->
                R.drawable.ic_type_doc

            DocumentType.XLS ->
                R.drawable.ic_type_xls

            DocumentType.TXT ->
                R.drawable.ic_type_txt
        }
    }

    // ---------------------------------------------------------
    // DOCUMENT ICON BACKGROUND
    // ---------------------------------------------------------

    fun getIconBgForType(
        type: DocumentType
    ): Int {

        return when (type) {

            DocumentType.PDF ->
                R.drawable.bg_icon_pdf

            DocumentType.PPT ->
                R.drawable.bg_icon_ppt

            DocumentType.DOC ->
                R.drawable.bg_icon_doc

            DocumentType.XLS ->
                R.drawable.bg_icon_xls

            DocumentType.TXT ->
                R.drawable.bg_icon_txt
        }
    }
}