package com.mastercoding.alldocumentreader

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class PrivacyPolicyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupEdgeToEdge()

        setContentView(R.layout.activity_privacy_policy)

        val backButton =
            findViewById<ImageView>(R.id.btnPrivacyBack)

        backButton.setOnClickListener {
            finish()
        }
    }
}