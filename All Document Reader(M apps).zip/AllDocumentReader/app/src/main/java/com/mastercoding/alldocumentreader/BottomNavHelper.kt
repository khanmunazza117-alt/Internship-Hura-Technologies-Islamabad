package com.mastercoding.alldocumentreader

import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.mastercoding.alldocumentreader.model.FileCategory

object BottomNavHelper {

    enum class Tab {
        HOME,
        SETTINGS
    }

    fun setup(
        context: Context,
        root: View,
        activeTab: Tab,
        onHomeClick: (() -> Unit)? = null,
        onSettingsClick: (() -> Unit)? = null
    ) {

        val homeTab =
            root.findViewById<LinearLayout>(R.id.navHome)

        val settingsTab =
            root.findViewById<LinearLayout>(R.id.navSettings)

        val homeIconBg =
            root.findViewById<View>(R.id.navHomeIconBg)

        val settingsIconBg =
            root.findViewById<View>(R.id.navSettingsIconBg)

        val homeIcon =
            root.findViewById<ImageView>(R.id.navHomeIcon)

        val settingsIcon =
            root.findViewById<ImageView>(R.id.navSettingsIcon)

        val homeLabel =
            root.findViewById<TextView>(R.id.navHomeLabel)

        val settingsLabel =
            root.findViewById<TextView>(R.id.navSettingsLabel)

        when (activeTab) {

            Tab.HOME -> {

                // Backgrounds
                homeIconBg.setBackgroundResource(
                    R.drawable.bg_nav_active
                )

                settingsIconBg.setBackgroundResource(
                    R.drawable.bg_nav_inactive
                )

                // Keep the original Figma PNG icons.
                // Do NOT apply a color filter here.
                homeIcon.clearColorFilter()
                settingsIcon.clearColorFilter()

                // Labels
                homeLabel.setTextColor(
                    context.getColor(R.color.text_dark)
                )

                settingsLabel.setTextColor(
                    context.getColor(R.color.text_muted)
                )
            }

            Tab.SETTINGS -> {

                // Backgrounds
                homeIconBg.setBackgroundResource(
                    R.drawable.bg_nav_inactive
                )

                settingsIconBg.setBackgroundResource(
                    R.drawable.bg_nav_active
                )

                // Keep original PNG icons
                homeIcon.clearColorFilter()
                settingsIcon.clearColorFilter()

                // Labels
                homeLabel.setTextColor(
                    context.getColor(R.color.text_muted)
                )

                settingsLabel.setTextColor(
                    context.getColor(R.color.text_dark)
                )
            }
        }

        // HOME
        homeTab.setOnClickListener {

            if (activeTab != Tab.HOME) {

                if (onHomeClick != null) {

                    onHomeClick.invoke()

                } else {

                    val intent = Intent(
                        context,
                        MainActivity::class.java
                    ).apply {

                        flags =
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                    Intent.FLAG_ACTIVITY_SINGLE_TOP

                        putExtra(
                            MainActivity.EXTRA_TAB,
                            MainActivity.TAB_HOME
                        )
                    }

                    context.startActivity(intent)
                }
            }
        }

        // SETTINGS
        settingsTab.setOnClickListener {

            if (activeTab != Tab.SETTINGS) {

                if (onSettingsClick != null) {

                    onSettingsClick.invoke()

                } else {

                    val intent = Intent(
                        context,
                        MainActivity::class.java
                    ).apply {

                        flags =
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                    Intent.FLAG_ACTIVITY_SINGLE_TOP

                        putExtra(
                            MainActivity.EXTRA_TAB,
                            MainActivity.TAB_SETTINGS
                        )
                    }

                    context.startActivity(intent)
                }
            }
        }
    }

    fun openFileList(
        context: Context,
        category: FileCategory
    ) {

        val intent = Intent(
            context,
            FileListActivity::class.java
        ).apply {

            putExtra(
                FileListActivity.EXTRA_CATEGORY,
                category.name
            )
        }

        context.startActivity(intent)
    }
}