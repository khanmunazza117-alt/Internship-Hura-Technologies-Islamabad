package com.mastercoding.alldocumentreader

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class TermsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupEdgeToEdge()
        setContentView(R.layout.activity_terms)

        findViewById<View>(R.id.termsRoot).applySystemBarInsets(applyBottom = false)
        findViewById<View>(R.id.buttonsContainer).applySystemBarInsets(
            applyLeft = false,
            applyTop = false,
            applyRight = false
        )

        val checkbox = findViewById<CheckBox>(R.id.termsCheckbox)
        val btnDecline = findViewById<TextView>(R.id.btnDecline)
        val btnAccept = findViewById<TextView>(R.id.btnAccept)

        btnDecline.setOnClickListener {
            finishAffinity()
        }

        btnAccept.setOnClickListener {
            if (checkbox.isChecked) {
                PreferenceHelper.setTermsAccepted(this)
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(
                    this,
                    getString(R.string.terms_accept_label),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
