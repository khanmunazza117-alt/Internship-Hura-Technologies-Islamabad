package com.mastercoding.alldocumentreader.adapter

import android.content.Intent
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.mastercoding.alldocumentreader.R
import com.mastercoding.alldocumentreader.data.DocumentRepository
import com.mastercoding.alldocumentreader.model.DocumentItem

class RecentDocumentAdapter(
    private var items: List<DocumentItem>,
    private val onFavoriteToggle: (DocumentItem) -> Unit
) : RecyclerView.Adapter<RecentDocumentAdapter.RecentViewHolder>() {

    class RecentViewHolder(
        view: View
    ) : RecyclerView.ViewHolder(view) {

        val iconBg: View =
            view.findViewById(R.id.fileIconBg)

        val icon: ImageView =
            view.findViewById(R.id.fileIcon)

        val name: TextView =
            view.findViewById(R.id.fileName)

        val favorite: ImageView =
            view.findViewById(R.id.fileFavorite)

        val more: ImageView =
            view.findViewById(R.id.fileMore)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecentViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_recent_document,
                parent,
                false
            )

        return RecentViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: RecentViewHolder,
        position: Int
    ) {

        val item = items[position]

        // =====================================================
        // FILE ICON BACKGROUND
        // =====================================================

        holder.iconBg.setBackgroundResource(
            DocumentRepository.getIconBgForType(item.type)
        )


        // =====================================================
        // FILE ICON
        // =====================================================

        holder.icon.setImageResource(
            DocumentRepository.getIconForType(item.type)
        )


        // =====================================================
        // FILE NAME
        // =====================================================

        holder.name.text = item.name


        // =====================================================
        // STAR
        // =====================================================

        holder.favorite.setImageResource(
            if (item.isFavorite) {
                R.drawable.ic_star_filled
            } else {
                R.drawable.ic_star_outline
            }
        )

        holder.favorite.setOnClickListener {

            onFavoriteToggle(item)

            val currentPosition =
                holder.bindingAdapterPosition

            if (currentPosition != RecyclerView.NO_POSITION) {
                notifyItemChanged(currentPosition)
            }
        }


        // =====================================================
        // THREE DOTS
        // =====================================================

        holder.more.setImageResource(
            R.drawable.ic_more
        )

        holder.more.setOnClickListener {

            showFileOptions(
                holder.more,
                item
            )
        }
    }


    // =========================================================
    // FIGMA STYLE POPUP
    // =========================================================

    private fun showFileOptions(
        anchor: View,
        item: DocumentItem
    ) {

        val context = anchor.context

        val popupView = LayoutInflater.from(context)
            .inflate(
                R.layout.item_file_options_popup,
                null
            )


        // =====================================================
        // POPUP WINDOW
        // =====================================================

        val popupWindow = PopupWindow(
            popupView,
            dpToPx(context, 220),
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )


        popupWindow.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(
                android.graphics.Color.TRANSPARENT
            )
        )

        popupWindow.isOutsideTouchable = true
        popupWindow.isFocusable = true
        popupWindow.elevation = 10f


        // =====================================================
        // RENAME
        // =====================================================

        popupView.findViewById<View>(
            R.id.menuRename
        ).setOnClickListener {

            popupWindow.dismiss()

            showRenameDialog(
                anchor,
                item
            )
        }


        // =====================================================
        // SHARE
        // =====================================================

        popupView.findViewById<View>(
            R.id.menuShare
        ).setOnClickListener {

            popupWindow.dismiss()

            shareFile(
                anchor,
                item
            )
        }


        // =====================================================
        // DELETE
        // =====================================================

        popupView.findViewById<View>(
            R.id.menuDelete
        ).setOnClickListener {

            popupWindow.dismiss()

            deleteFile(
                anchor,
                item
            )
        }


        // =====================================================
        // SHOW POPUP
        // Above and to the LEFT of three-dot button
        // =====================================================

        popupWindow.showAsDropDown(
            anchor,
            -dpToPx(context, 190),
            -dpToPx(context, 170),
            Gravity.END
        )
    }


    // =========================================================
    // DP TO PX
    // =========================================================

    private fun dpToPx(
        context: android.content.Context,
        dp: Int
    ): Int {

        return (
                dp * context.resources.displayMetrics.density
                ).toInt()
    }


    // =========================================================
    // RENAME
    // =========================================================

    private fun showRenameDialog(
        anchor: View,
        item: DocumentItem
    ) {

        val context = anchor.context

        val editText = EditText(context)

        editText.setText(item.name)

        editText.setSelection(
            editText.text.length
        )

        AlertDialog.Builder(context)
            .setTitle("Rename file")
            .setView(editText)
            .setNegativeButton(
                "Cancel",
                null
            )
            .setPositiveButton(
                "Rename"
            ) { _, _ ->

                val newName =
                    editText.text.toString().trim()

                if (newName.isNotEmpty()) {

                    DocumentRepository.renameDocument(
                        item.id,
                        newName
                    )

                    item.name = newName

                    notifyDataSetChanged()
                }
            }
            .show()
    }


    // =========================================================
    // SHARE
    // =========================================================

    private fun shareFile(
        anchor: View,
        item: DocumentItem
    ) {

        val intent = Intent(
            Intent.ACTION_SEND
        )

        intent.type = "text/plain"

        intent.putExtra(
            Intent.EXTRA_TEXT,
            item.name
        )

        anchor.context.startActivity(
            Intent.createChooser(
                intent,
                "Share"
            )
        )
    }


    // =========================================================
    // DELETE
    // =========================================================

    private fun deleteFile(
        anchor: View,
        item: DocumentItem
    ) {

        DocumentRepository.deleteDocument(
            item.id
        )

        items =
            DocumentRepository.getRecentDocuments()

        notifyDataSetChanged()

        Toast.makeText(
            anchor.context,
            "File deleted",
            Toast.LENGTH_SHORT
        ).show()
    }


    // =========================================================
    // UPDATE
    // =========================================================

    fun updateItems(
        newItems: List<DocumentItem>
    ) {

        items = newItems

        notifyDataSetChanged()
    }


    // =========================================================
    // ITEM COUNT
    // =========================================================

    override fun getItemCount(): Int {
        return items.size
    }
}