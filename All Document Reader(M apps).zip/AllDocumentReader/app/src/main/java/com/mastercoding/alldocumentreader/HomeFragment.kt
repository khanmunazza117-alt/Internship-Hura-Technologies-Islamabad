package com.mastercoding.alldocumentreader

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.mastercoding.alldocumentreader.adapter.CategoryAdapter
import com.mastercoding.alldocumentreader.adapter.RecentDocumentAdapter
import com.mastercoding.alldocumentreader.data.DocumentRepository
import com.mastercoding.alldocumentreader.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var recentAdapter: RecentDocumentAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentHomeBinding.inflate(
            inflater,
            container,
            false
        )

        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        setupCategoryRecycler()
        setupRecentRecycler()
    }

    // ---------------------------------------------------------
    // CATEGORY SECTION
    // ---------------------------------------------------------

    private fun setupCategoryRecycler() {

        categoryAdapter = CategoryAdapter(
            DocumentRepository.getCategories()
        ) { categoryItem ->

            BottomNavHelper.openFileList(
                requireContext(),
                categoryItem.category
            )
        }

        binding.categoryRecycler.apply {

            layoutManager = GridLayoutManager(
                requireContext(),
                2
            )

            adapter = categoryAdapter

            isNestedScrollingEnabled = false

            setHasFixedSize(false)
        }
    }

    // ---------------------------------------------------------
    // RECENT DOCUMENT SECTION
    // ---------------------------------------------------------

    private fun setupRecentRecycler() {

        recentAdapter = RecentDocumentAdapter(
            DocumentRepository.getRecentDocuments()
        ) { item ->

            DocumentRepository.toggleFavorite(item.id)

            refreshRecent()
        }

        binding.recentRecycler.apply {

            layoutManager = LinearLayoutManager(
                requireContext(),
                LinearLayoutManager.VERTICAL,
                false
            )

            adapter = recentAdapter

            isNestedScrollingEnabled = false

            setHasFixedSize(false)
        }
    }

    // ---------------------------------------------------------
    // REFRESH RECENT DOCUMENTS
    // ---------------------------------------------------------

    private fun refreshRecent() {

        recentAdapter.updateItems(
            DocumentRepository.getRecentDocuments()
        )
    }

    // ---------------------------------------------------------
    // RESUME
    // ---------------------------------------------------------

    override fun onResume() {
        super.onResume()

        if (::categoryAdapter.isInitialized) {
            categoryAdapter.notifyDataSetChanged()
        }

        if (::recentAdapter.isInitialized) {
            refreshRecent()
        }
    }

    // ---------------------------------------------------------
    // CLEANUP
    // ---------------------------------------------------------

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }
}