package com.mastercoding.duplicatefileremover

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class VideoAdapter(
    private val videos: List<VideoItem>
) : RecyclerView.Adapter<VideoAdapter.VideoViewHolder>() {

    class VideoViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val imageView: ImageView =
            itemView.findViewById(R.id.imgVideo)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VideoViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_video,
                parent,
                false
            )

        return VideoViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: VideoViewHolder,
        position: Int
    ) {

        val video = videos[position]

        // Video ka thumbnail show karega
        val thumbnail = android.provider.MediaStore.Video.Thumbnails
            .getThumbnail(
                holder.itemView.context.contentResolver,
                android.content.ContentUris.parseId(video.uri),
                android.provider.MediaStore.Video.Thumbnails.MINI_KIND,
                null
            )

        holder.imageView.setImageBitmap(thumbnail)
    }

    override fun getItemCount(): Int {
        return videos.size
    }
}