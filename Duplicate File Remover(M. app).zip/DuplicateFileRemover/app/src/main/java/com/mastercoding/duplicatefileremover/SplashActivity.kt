package com.mastercoding.duplicatefileremover

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({

            val prefs =
                getSharedPreferences(
                    "AppPrefs",
                    MODE_PRIVATE
                )

            val termsAccepted =
                prefs.getBoolean(
                    "termsAccepted",
                    false
                )

            if (termsAccepted) {

                // Terms already accepted
                // Go directly to Home
                startActivity(
                    Intent(
                        this,
                        MainActivity::class.java
                    )
                )

            } else {

                // First time
                // Show Terms & Conditions
                startActivity(
                    Intent(
                        this,
                        TermsActivity::class.java
                    )
                )
            }

            finish()

        }, 2000)
    }
}