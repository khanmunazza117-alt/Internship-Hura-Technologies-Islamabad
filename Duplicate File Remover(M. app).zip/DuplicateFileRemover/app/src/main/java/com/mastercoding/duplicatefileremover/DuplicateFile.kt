package com.mastercoding.duplicatefileremover

import android.net.Uri

data class DuplicateFile(
    val uri: Uri,
    val name: String,
    val size: Long,
    val mimeType: String?,
    val hash: String = "",
    var isSelected: Boolean = false
)