package com.mastercoding.duplicatefileremover

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

object StorageHelper {

    // =========================================================
    // PERMISSION
    // =========================================================

    const val REQUEST_MEDIA_PERMISSION = 1001

    // =========================================================
    // IMAGE PERMISSION
    // =========================================================

    fun hasImagePermission(context: Context): Boolean {

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED

        } else {

            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestImagePermission(activity: Activity) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            ActivityCompat.requestPermissions(
                activity,
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES
                ),
                REQUEST_MEDIA_PERMISSION
            )

        } else {

            ActivityCompat.requestPermissions(
                activity,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ),
                REQUEST_MEDIA_PERMISSION
            )
        }
    }

    // =========================================================
    // VIDEO PERMISSION
    // =========================================================

    fun hasVideoPermission(context: Context): Boolean {

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED

        } else {

            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestVideoPermission(activity: Activity) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            ActivityCompat.requestPermissions(
                activity,
                arrayOf(
                    Manifest.permission.READ_MEDIA_VIDEO
                ),
                REQUEST_MEDIA_PERMISSION
            )

        } else {

            ActivityCompat.requestPermissions(
                activity,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ),
                REQUEST_MEDIA_PERMISSION
            )
        }
    }

    // =========================================================
    // AUDIO PERMISSION
    // =========================================================

    fun hasAudioPermission(context: Context): Boolean {

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

        } else {

            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestAudioPermission(activity: Activity) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            ActivityCompat.requestPermissions(
                activity,
                arrayOf(
                    Manifest.permission.READ_MEDIA_AUDIO
                ),
                REQUEST_MEDIA_PERMISSION
            )

        } else {

            ActivityCompat.requestPermissions(
                activity,
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ),
                REQUEST_MEDIA_PERMISSION
            )
        }
    }

    // =========================================================
    // TOTAL PHONE STORAGE
    // =========================================================

    fun getTotalStorage(): Long {

        val statFs =
            StatFs(
                Environment.getDataDirectory().path
            )

        return statFs.totalBytes
    }

    // =========================================================
    // FREE PHONE STORAGE
    // =========================================================

    fun getFreeStorage(): Long {

        val statFs =
            StatFs(
                Environment.getDataDirectory().path
            )

        return statFs.availableBytes
    }

    // =========================================================
    // USED PHONE STORAGE
    // =========================================================

    fun getUsedStorage(): Long {

        return getTotalStorage() - getFreeStorage()
    }

    // =========================================================
    // PHOTO COUNT
    // =========================================================

    fun getPhotoCount(context: Context): Int {

        var count = 0

        val collection =
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        val projection =
            arrayOf(
                MediaStore.Images.Media._ID
            )

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            null
        )?.use { cursor ->

            count = cursor.count
        }

        return count
    }

    // =========================================================
    // VIDEO COUNT
    // =========================================================

    fun getVideoCount(context: Context): Int {

        var count = 0

        val collection =
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection =
            arrayOf(
                MediaStore.Video.Media._ID
            )

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            null
        )?.use { cursor ->

            count = cursor.count
        }

        return count
    }

    // =========================================================
    // AUDIO COUNT
    // =========================================================

    fun getAudioCount(context: Context): Int {

        var count = 0

        val collection =
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection =
            arrayOf(
                MediaStore.Audio.Media._ID
            )

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            null
        )?.use { cursor ->

            count = cursor.count
        }

        return count
    }

    // =========================================================
    // DOCUMENT COUNT
    // =========================================================

    fun getDocumentCount(context: Context): Int {

        var count = 0

        val collection =
            MediaStore.Files.getContentUri("external")

        val projection =
            arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.MIME_TYPE
            )

        val selection =
            "${MediaStore.Files.FileColumns.MIME_TYPE} IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"

        val selectionArgs =
            arrayOf(
                "application/pdf",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-powerpoint",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                "text/plain",
                "text/csv",
                "application/rtf"
            )

        context.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            null
        )?.use { cursor ->

            count = cursor.count
        }

        return count
    }

    // =========================================================
    // APK COUNT
    // =========================================================

    fun getApkCount(context: Context): Int {

        var count = 0

        val collection =
            MediaStore.Files.getContentUri("external")

        val projection =
            arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.MIME_TYPE
            )

        val selection =
            "${MediaStore.Files.FileColumns.MIME_TYPE} = ?"

        val selectionArgs =
            arrayOf(
                "application/vnd.android.package-archive"
            )

        context.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            null
        )?.use { cursor ->

            count = cursor.count
        }

        return count
    }

    // =========================================================
    // PHOTO SIZE
    // =========================================================

    fun getPhotoSize(context: Context): Long {

        return getMediaSize(
            context,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        )
    }

    // =========================================================
    // VIDEO SIZE
    // =========================================================

    fun getVideoSize(context: Context): Long {

        return getMediaSize(
            context,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        )
    }

    // =========================================================
    // AUDIO SIZE
    // =========================================================

    fun getAudioSize(context: Context): Long {

        return getMediaSize(
            context,
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        )
    }

    // =========================================================
    // GENERIC MEDIA SIZE
    // =========================================================

    private fun getMediaSize(
        context: Context,
        collection: android.net.Uri
    ): Long {

        var totalSize = 0L

        val projection =
            arrayOf(
                MediaStore.MediaColumns.SIZE
            )

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            null
        )?.use { cursor ->

            val sizeColumn =
                cursor.getColumnIndex(
                    MediaStore.MediaColumns.SIZE
                )

            if (sizeColumn >= 0) {

                while (cursor.moveToNext()) {

                    val size =
                        cursor.getLong(sizeColumn)

                    if (size > 0) {
                        totalSize += size
                    }
                }
            }
        }

        return totalSize
    }

    // =========================================================
    // DOCUMENT SIZE
    // =========================================================

    fun getDocumentSize(context: Context): Long {

        var totalSize = 0L

        val collection =
            MediaStore.Files.getContentUri("external")

        val projection =
            arrayOf(
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.MIME_TYPE
            )

        val selection =
            "${MediaStore.Files.FileColumns.MIME_TYPE} IN (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"

        val selectionArgs =
            arrayOf(
                "application/pdf",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-powerpoint",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                "text/plain",
                "text/csv",
                "application/rtf"
            )

        context.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            null
        )?.use { cursor ->

            val sizeColumn =
                cursor.getColumnIndex(
                    MediaStore.Files.FileColumns.SIZE
                )

            if (sizeColumn >= 0) {

                while (cursor.moveToNext()) {

                    val size =
                        cursor.getLong(sizeColumn)

                    if (size > 0) {
                        totalSize += size
                    }
                }
            }
        }

        return totalSize
    }

    // =========================================================
    // APK SIZE
    // =========================================================

    fun getApkSize(context: Context): Long {

        var totalSize = 0L

        val collection =
            MediaStore.Files.getContentUri("external")

        val projection =
            arrayOf(
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.MIME_TYPE
            )

        val selection =
            "${MediaStore.Files.FileColumns.MIME_TYPE} = ?"

        val selectionArgs =
            arrayOf(
                "application/vnd.android.package-archive"
            )

        context.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            null
        )?.use { cursor ->

            val sizeColumn =
                cursor.getColumnIndex(
                    MediaStore.Files.FileColumns.SIZE
                )

            if (sizeColumn >= 0) {

                while (cursor.moveToNext()) {

                    val size =
                        cursor.getLong(sizeColumn)

                    if (size > 0) {
                        totalSize += size
                    }
                }
            }
        }

        return totalSize
    }

    // =========================================================
    // FORMAT STORAGE
    // =========================================================

    fun formatStorage(bytes: Long): String {

        if (bytes <= 0) {
            return "0 GB"
        }

        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0

        return when {

            bytes >= gb -> {

                String.format(
                    Locale.US,
                    "%.1f GB",
                    bytes / gb
                )
            }

            bytes >= mb -> {

                String.format(
                    Locale.US,
                    "%.1f MB",
                    bytes / mb
                )
            }

            bytes >= kb -> {

                String.format(
                    Locale.US,
                    "%.1f KB",
                    bytes / kb
                )
            }

            else -> {

                "$bytes B"
            }
        }
    }
}