package com.mastercoding.duplicatefileremover

import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class PhotosActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var photoCount: TextView

    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_photos)

        val btnBack = findViewById<ImageView>(R.id.btnBack)

        recyclerView = findViewById(R.id.rvPhotos)
        progressBar = findViewById(R.id.progressPhotos)
        photoCount = findViewById(R.id.txtPhotoCount)

        btnBack.setOnClickListener {
            finish()
        }

        recyclerView.layoutManager =
            GridLayoutManager(this, 3)

        checkPermissionAndLoadPhotos()
    }

    private fun checkPermissionAndLoadPhotos() {

        if (StorageHelper.hasImagePermission(this)) {

            loadPhotos()

        } else {

            StorageHelper.requestImagePermission(this)
        }
    }

    private fun loadPhotos() {

        progressBar.visibility = ProgressBar.VISIBLE

        executor.execute {

            val photos = getPhotosFromMediaStore()

            runOnUiThread {

                progressBar.visibility = ProgressBar.GONE

                recyclerView.adapter =
                    PhotoAdapter(photos)

                photoCount.text =
                    "${photos.size} Photos"
            }
        }
    }

    private fun getPhotosFromMediaStore(): List<PhotoItem> {

        val photos = mutableListOf<PhotoItem>()

        val collection =
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE
        )

        val sortOrder =
            "${MediaStore.Images.Media.DATE_ADDED} DESC"

        contentResolver.query(
            collection,
            projection,
            null,
            null,
            sortOrder
        )?.use { cursor ->

            val idColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Images.Media._ID
                )

            val nameColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Images.Media.DISPLAY_NAME
                )

            val sizeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Images.Media.SIZE
                )

            while (cursor.moveToNext()) {

                val id =
                    cursor.getLong(idColumn)

                val name =
                    cursor.getString(nameColumn)

                val size =
                    cursor.getLong(sizeColumn)

                val uri =
                    MediaStore.Images.Media
                        .EXTERNAL_CONTENT_URI
                        .buildUpon()
                        .appendPath(id.toString())
                        .build()

                photos.add(
                    PhotoItem(
                        uri = uri,
                        name = name,
                        size = size
                    )
                )
            }
        }

        return photos
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (
            requestCode ==
            StorageHelper.REQUEST_MEDIA_PERMISSION
        ) {

            if (
                StorageHelper.hasImagePermission(this)
            ) {

                loadPhotos()

            } else {

                Toast.makeText(
                    this,
                    "Photo permission is required",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {

        executor.shutdown()

        super.onDestroy()
    }
}