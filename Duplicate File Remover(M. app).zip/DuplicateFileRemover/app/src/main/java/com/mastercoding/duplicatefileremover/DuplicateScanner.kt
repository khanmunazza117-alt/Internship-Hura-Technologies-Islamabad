package com.mastercoding.duplicatefileremover

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.security.MessageDigest

class DuplicateScanner(
    private val context: Context
) {

    private val contentResolver: ContentResolver =
        context.contentResolver


    // =========================================================
    // PHOTOS
    // =========================================================

    fun scanImages(): List<List<DuplicateFile>> {

        val files = queryMediaStore(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        )

        return findDuplicates(files)
    }


    // =========================================================
    // VIDEOS
    // =========================================================

    fun scanVideos(): List<List<DuplicateFile>> {

        val files = queryMediaStore(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        )

        return findDuplicates(files)
    }


    // =========================================================
    // AUDIOS
    // =========================================================

    fun scanAudios(): List<List<DuplicateFile>> {

        val files = queryMediaStore(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        )

        return findDuplicates(files)
    }


    // =========================================================
    // DOCUMENTS
    // =========================================================

    fun scanDocuments(): List<List<DuplicateFile>> {

        val collection =
            MediaStore.Files.getContentUri("external")

        val files =
            queryFiles(
                collection,
                arrayOf(
                    "application/pdf",
                    "application/msword",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/vnd.ms-excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.ms-powerpoint",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    "text/plain",
                    "text/csv",
                    "application/rtf"
                )
            )

        return findDuplicates(files)
    }


    // =========================================================
    // APK
    // =========================================================

    fun scanApks(): List<List<DuplicateFile>> {

        val collection =
            MediaStore.Files.getContentUri("external")

        val files =
            queryFiles(
                collection,
                arrayOf(
                    "application/vnd.android.package-archive"
                )
            )

        return findDuplicates(files)
    }


    // =========================================================
    // MEDIA STORE QUERY
    // =========================================================

    private fun queryMediaStore(
        collection: Uri
    ): List<DuplicateFile> {

        val result =
            mutableListOf<DuplicateFile>()

        val projection =
            arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE
            )

        contentResolver.query(
            collection,
            projection,
            null,
            null,
            "${MediaStore.MediaColumns.SIZE} DESC"
        )?.use { cursor ->

            val idColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.MediaColumns._ID
                )

            val nameColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.MediaColumns.DISPLAY_NAME
                )

            val sizeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.MediaColumns.SIZE
                )

            val mimeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.MediaColumns.MIME_TYPE
                )

            while (cursor.moveToNext()) {

                val id =
                    cursor.getLong(idColumn)

                val name =
                    cursor.getString(nameColumn)
                        ?: "Unknown file"

                val size =
                    cursor.getLong(sizeColumn)

                val mimeType =
                    cursor.getString(mimeColumn)

                if (size <= 0) {
                    continue
                }

                val fileUri =
                    ContentUris.withAppendedId(
                        collection,
                        id
                    )

                result.add(
                    DuplicateFile(
                        uri = fileUri,
                        name = name,
                        size = size,
                        mimeType = mimeType
                    )
                )
            }
        }

        return result
    }


    // =========================================================
    // DOCUMENT/APK QUERY
    // =========================================================

    private fun queryFiles(
        collection: Uri,
        mimeTypes: Array<String>
    ): List<DuplicateFile> {

        val result =
            mutableListOf<DuplicateFile>()

        val projection =
            arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.MIME_TYPE
            )

        val placeholders =
            mimeTypes.joinToString(",") {
                "?"
            }

        val selection =
            "${MediaStore.Files.FileColumns.MIME_TYPE} IN ($placeholders)"

        contentResolver.query(
            collection,
            projection,
            selection,
            mimeTypes,
            "${MediaStore.Files.FileColumns.SIZE} DESC"
        )?.use { cursor ->

            val idColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns._ID
                )

            val nameColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns.DISPLAY_NAME
                )

            val sizeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns.SIZE
                )

            val mimeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns.MIME_TYPE
                )

            while (cursor.moveToNext()) {

                val id =
                    cursor.getLong(idColumn)

                val name =
                    cursor.getString(nameColumn)
                        ?: "Unknown file"

                val size =
                    cursor.getLong(sizeColumn)

                val mimeType =
                    cursor.getString(mimeColumn)

                if (size <= 0) {
                    continue
                }

                val fileUri =
                    ContentUris.withAppendedId(
                        collection,
                        id
                    )

                result.add(
                    DuplicateFile(
                        uri = fileUri,
                        name = name,
                        size = size,
                        mimeType = mimeType
                    )
                )
            }
        }

        return result
    }


    // =========================================================
    // FIND DUPLICATES
    // =========================================================

    private fun findDuplicates(
        files: List<DuplicateFile>
    ): List<List<DuplicateFile>> {

        val sameSizeGroups =
            files
                .groupBy {
                    it.size
                }
                .values
                .filter {
                    it.size > 1
                }

        val duplicateGroups =
            mutableListOf<List<DuplicateFile>>()

        for (group in sameSizeGroups) {

            val hashGroups =
                group
                    .map { file ->

                        val hash =
                            calculateHash(
                                file.uri
                            )

                        file.copy(
                            hash = hash
                        )
                    }
                    .filter {
                        it.hash.isNotEmpty()
                    }
                    .groupBy {
                        it.hash
                    }

            hashGroups
                .values
                .filter {
                    it.size > 1
                }
                .forEach {
                    duplicateGroups.add(it)
                }
        }

        return duplicateGroups
    }


    // =========================================================
    // SHA-256
    // =========================================================

    private fun calculateHash(
        uri: Uri
    ): String {

        return try {

            val digest =
                MessageDigest.getInstance(
                    "SHA-256"
                )

            contentResolver
                .openInputStream(uri)
                ?.use { inputStream ->

                    val buffer =
                        ByteArray(8192)

                    while (true) {

                        val bytesRead =
                            inputStream.read(
                                buffer
                            )

                        if (bytesRead == -1) {
                            break
                        }

                        digest.update(
                            buffer,
                            0,
                            bytesRead
                        )
                    }
                }

            digest
                .digest()
                .joinToString("") {
                    "%02x".format(it)
                }

        } catch (e: Exception) {

            ""
        }
    }
}