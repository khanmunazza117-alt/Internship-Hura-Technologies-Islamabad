package com.mastercoding.duplicatefileremover

import android.net.Uri

data class VideoItem(
    val uri: Uri,
    val name: String,
    val size: Long
)