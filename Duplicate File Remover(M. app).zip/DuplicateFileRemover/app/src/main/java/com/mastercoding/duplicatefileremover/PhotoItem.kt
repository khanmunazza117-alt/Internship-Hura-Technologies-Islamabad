package com.mastercoding.duplicatefileremover

import android.net.Uri

data class PhotoItem(
    val uri: Uri,
    val name: String,
    val size: Long
)