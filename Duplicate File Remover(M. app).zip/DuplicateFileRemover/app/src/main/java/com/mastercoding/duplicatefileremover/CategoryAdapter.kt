package com.mastercoding.duplicatefileremover

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CategoryAdapter(
    private val categories: List<Category>,
    private val onClick: (Category) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CategoryViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_home_card,
                parent,
                false
            )

        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: CategoryViewHolder,
        position: Int
    ) {

        val category = categories[position]

        holder.bind(category)

        holder.itemView.setOnClickListener {
            onClick(category)
        }
    }

    override fun getItemCount(): Int {
        return categories.size
    }

    class CategoryViewHolder(
        itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        private val icon =
            itemView.findViewById<ImageView>(
                R.id.imgCategoryIcon
            )

        private val name =
            itemView.findViewById<TextView>(
                R.id.txtCategoryName
            )

        private val count =
            itemView.findViewById<TextView>(
                R.id.txtCategoryCount
            )

        private val arrow =
            itemView.findViewById<ImageView>(
                R.id.imgArrow
            )

        fun bind(category: Category) {

            icon.setImageResource(category.icon)

            name.text = category.name

            count.text = category.count

            arrow.visibility = View.VISIBLE
        }
    }
}