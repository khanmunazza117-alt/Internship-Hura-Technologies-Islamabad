package com.mastercoding.duplicatefileremover

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ApkAdapter(
    private val apks: List<ApkItem>
) : RecyclerView.Adapter<ApkAdapter.ApkViewHolder>() {

    class ApkViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val icon: ImageView =
            itemView.findViewById(R.id.imgApk)

        val name: TextView =
            itemView.findViewById(R.id.txtApkName)

        val size: TextView =
            itemView.findViewById(R.id.txtApkSize)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ApkViewHolder {

        val view =
            LayoutInflater.from(parent.context)
                .inflate(
                    R.layout.item_apk,
                    parent,
                    false
                )

        return ApkViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: ApkViewHolder,
        position: Int
    ) {

        val apk =
            apks[position]

        holder.name.text =
            apk.name

        holder.size.text =
            formatFileSize(apk.size)
    }

    override fun getItemCount(): Int {
        return apks.size
    }

    private fun formatFileSize(
        size: Long
    ): String {

        val kb = size / 1024.0

        if (kb < 1024) {
            return "%.1f KB".format(kb)
        }

        val mb = kb / 1024.0

        if (mb < 1024) {
            return "%.1f MB".format(mb)
        }

        val gb = mb / 1024.0

        return "%.1f GB".format(gb)
    }
}