package com.mastercoding.duplicatefileremover

import android.net.Uri

data class ApkItem(
    val uri: Uri,
    val name: String,
    val size: Long
)