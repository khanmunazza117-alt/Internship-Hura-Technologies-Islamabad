package com.mastercoding.duplicatefileremover

import android.net.Uri

data class AudioItem(
    val uri: Uri,
    val name: String,
    val size: Long
)