package com.mastercoding.duplicatefileremover



import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class TermsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_terms)

        val btnAccept = findViewById<Button>(R.id.btnAccept)
        val btnCancel = findViewById<Button>(R.id.btnCancel)

        btnAccept.setOnClickListener {

            getSharedPreferences("AppPrefs", MODE_PRIVATE)
                .edit()
                .putBoolean("termsAccepted", true)
                .apply()

            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        btnCancel.setOnClickListener {
            finishAffinity()
        }
    }
}