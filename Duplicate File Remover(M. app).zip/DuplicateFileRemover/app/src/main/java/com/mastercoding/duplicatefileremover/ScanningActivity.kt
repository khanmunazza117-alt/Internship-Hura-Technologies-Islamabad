package com.mastercoding.duplicatefileremover

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ScanningActivity : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var txtStatus: TextView

    private val handler =
        Handler(Looper.getMainLooper())

    // =========================================================
    // CURRENT MEDIA TYPE
    // =========================================================

    private var mediaType: String = "photos"

    // =========================================================
    // ON CREATE
    // =========================================================

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_scanning
        )

        // =====================================================
        // GET MEDIA TYPE FROM MAIN ACTIVITY
        // =====================================================

        mediaType =
            intent.getStringExtra(
                "MEDIA_TYPE"
            )
                ?.lowercase()
                ?: "photos"

        // =====================================================
        // FIND VIEWS
        // =====================================================

        val btnBack =
            findViewById<ImageView>(
                R.id.btnBack
            )

        progressBar =
            findViewById(
                R.id.progressScanning
            )

        txtStatus =
            findViewById(
                R.id.txtScanningStatus
            )

        // =====================================================
        // BACK BUTTON
        // =====================================================

        btnBack.setOnClickListener {

            finish()
        }

        // =====================================================
        // START SCANNING
        // =====================================================

        startScanning()
    }

    // =========================================================
    // START SCANNING
    // =========================================================

    private fun startScanning() {

        progressBar.progress = 0

        txtStatus.text =
            "Scanning your storage..."

        // =====================================================
        // STEP 1
        // =====================================================

        handler.postDelayed({

            progressBar.progress = 25

            txtStatus.text =
                when (mediaType) {

                    "photos" ->
                        "Checking Photos..."

                    "videos" ->
                        "Checking Videos..."

                    "audios" ->
                        "Checking Audios..."

                    "documents" ->
                        "Checking Documents..."

                    "apks" ->
                        "Checking APKs..."

                    else ->
                        "Checking files..."
                }

        }, 400)

        // =====================================================
        // STEP 2
        // =====================================================

        handler.postDelayed({

            progressBar.progress = 50

            txtStatus.text =
                when (mediaType) {

                    "photos" ->
                        "Analyzing Photos..."

                    "videos" ->
                        "Analyzing Videos..."

                    "audios" ->
                        "Analyzing Audios..."

                    "documents" ->
                        "Analyzing Documents..."

                    "apks" ->
                        "Analyzing APKs..."

                    else ->
                        "Analyzing files..."
                }

        }, 800)

        // =====================================================
        // STEP 3
        // =====================================================

        handler.postDelayed({

            progressBar.progress = 70

            txtStatus.text =
                when (mediaType) {

                    "photos" ->
                        "Comparing Photos..."

                    "videos" ->
                        "Comparing Videos..."

                    "audios" ->
                        "Comparing Audios..."

                    "documents" ->
                        "Comparing Documents..."

                    "apks" ->
                        "Comparing APKs..."

                    else ->
                        "Comparing files..."
                }

        }, 1200)

        // =====================================================
        // STEP 4
        // =====================================================

        handler.postDelayed({

            progressBar.progress = 85

            txtStatus.text =
                "Finding duplicate files..."

        }, 1600)

        // =====================================================
        // STEP 5
        // =====================================================

        handler.postDelayed({

            progressBar.progress = 100

            txtStatus.text =
                "Duplicates found!"

        }, 2000)

        // =====================================================
        // OPEN DUPLICATE ACTIVITY
        // =====================================================

        handler.postDelayed({

            val intent =
                Intent(
                    this,
                    DuplicateActivity::class.java
                )

            // =================================================
            // VERY IMPORTANT
            // PASS MEDIA TYPE TO DUPLICATE ACTIVITY
            // =================================================

            intent.putExtra(
                "MEDIA_TYPE",
                mediaType
            )

            startActivity(intent)

            finish()

        }, 2400)
    }

    // =========================================================
    // DESTROY
    // =========================================================

    override fun onDestroy() {

        handler.removeCallbacksAndMessages(
            null
        )

        super.onDestroy()
    }
}