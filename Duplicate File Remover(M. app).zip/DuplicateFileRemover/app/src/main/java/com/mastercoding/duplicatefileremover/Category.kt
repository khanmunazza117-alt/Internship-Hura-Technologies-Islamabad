package com.mastercoding.duplicatefileremover

data class Category(
    val name: String,
    val icon: Int,
    val count: String = "0 items"
)