package com.mastercoding.duplicatefileremover

import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class AudiosActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var audioCount: TextView

    private val executor =
        Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_audios)

        val btnBack =
            findViewById<ImageView>(R.id.btnBack)

        recyclerView =
            findViewById(R.id.rvAudios)

        progressBar =
            findViewById(R.id.progressAudios)

        audioCount =
            findViewById(R.id.txtAudioCount)

        btnBack.setOnClickListener {
            finish()
        }

        recyclerView.layoutManager =
            LinearLayoutManager(this)

        checkPermissionAndLoadAudios()
    }


    // =========================================================
    // PERMISSION
    // =========================================================

    private fun checkPermissionAndLoadAudios() {

        if (StorageHelper.hasAudioPermission(this)) {

            loadAudios()

        } else {

            StorageHelper.requestAudioPermission(this)
        }
    }


    // =========================================================
    // LOAD AUDIOS
    // =========================================================

    private fun loadAudios() {

        progressBar.visibility =
            ProgressBar.VISIBLE

        executor.execute {

            val audios =
                getAudiosFromMediaStore()

            runOnUiThread {

                progressBar.visibility =
                    ProgressBar.GONE

                recyclerView.adapter =
                    AudioAdapter(audios)

                audioCount.text =
                    "${audios.size} Audios"
            }
        }
    }


    // =========================================================
    // GET AUDIO FILES
    // =========================================================

    private fun getAudiosFromMediaStore():
            List<AudioItem> {

        val audios =
            mutableListOf<AudioItem>()

        val collection =
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE
        )

        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        val sortOrder =
            "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        contentResolver.query(
            collection,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->

            val idColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Audio.Media._ID
                )

            val nameColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Audio.Media.DISPLAY_NAME
                )

            val sizeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Audio.Media.SIZE
                )

            while (cursor.moveToNext()) {

                val id =
                    cursor.getLong(idColumn)

                val name =
                    cursor.getString(nameColumn)
                        ?: "Unknown Audio"

                val size =
                    cursor.getLong(sizeColumn)

                val uri =
                    MediaStore.Audio.Media
                        .EXTERNAL_CONTENT_URI
                        .buildUpon()
                        .appendPath(id.toString())
                        .build()

                audios.add(
                    AudioItem(
                        uri = uri,
                        name = name,
                        size = size
                    )
                )
            }
        }

        return audios
    }


    // =========================================================
    // PERMISSION RESULT
    // =========================================================

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (
            requestCode ==
            StorageHelper.REQUEST_MEDIA_PERMISSION
        ) {

            if (
                StorageHelper.hasAudioPermission(this)
            ) {

                loadAudios()

            } else {

                Toast.makeText(
                    this,
                    "Audio permission is required",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }


    // =========================================================
    // DESTROY
    // =========================================================

    override fun onDestroy() {

        executor.shutdown()

        super.onDestroy()
    }
}