package com.mastercoding.duplicatefileremover

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.Size
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale
import java.util.concurrent.Executors

class DuplicateAdapter(
    private val groups: List<List<DuplicateFile>>,
    private val onSelectionChanged: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_MEDIA = 1
        private const val TYPE_LIST = 2
    }

    private val executor =
        Executors.newFixedThreadPool(3)

    private val items =
        mutableListOf<AdapterItem>()

    init {
        groups.forEachIndexed { index, group ->

            items.add(
                AdapterItem.Header(
                    "Duplicate Group ${index + 1}",
                    group.size
                )
            )

            group.forEach { file ->

                if (isImageOrVideo(file)) {
                    items.add(
                        AdapterItem.MediaItem(file)
                    )
                } else {
                    items.add(
                        AdapterItem.ListItem(file)
                    )
                }
            }
        }
    }

    // =========================================================
    // ITEMS
    // =========================================================

    sealed class AdapterItem {

        data class Header(
            val title: String,
            val count: Int
        ) : AdapterItem()

        data class MediaItem(
            val file: DuplicateFile
        ) : AdapterItem()

        data class ListItem(
            val file: DuplicateFile
        ) : AdapterItem()
    }

    // =========================================================
    // VIEW TYPE
    // =========================================================

    override fun getItemViewType(position: Int): Int {

        return when (items[position]) {

            is AdapterItem.Header ->
                TYPE_HEADER

            is AdapterItem.MediaItem ->
                TYPE_MEDIA

            is AdapterItem.ListItem ->
                TYPE_LIST
        }
    }

    // =========================================================
    // CREATE VIEW HOLDER
    // =========================================================

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {

        return when (viewType) {

            TYPE_HEADER -> {

                val view =
                    LayoutInflater.from(parent.context)
                        .inflate(
                            R.layout.item_duplicate_group_header,
                            parent,
                            false
                        )

                HeaderViewHolder(view)
            }

            TYPE_MEDIA -> {

                val view =
                    LayoutInflater.from(parent.context)
                        .inflate(
                            R.layout.item_duplicate_gallery,
                            parent,
                            false
                        )

                MediaViewHolder(view)
            }

            else -> {

                val view =
                    LayoutInflater.from(parent.context)
                        .inflate(
                            R.layout.item_duplicate_file,
                            parent,
                            false
                        )

                ListViewHolder(view)
            }
        }
    }

    // =========================================================
    // BIND
    // =========================================================

    override fun onBindViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int
    ) {

        when (val item = items[position]) {

            is AdapterItem.Header -> {
                (holder as HeaderViewHolder).bind(item)
            }

            is AdapterItem.MediaItem -> {
                (holder as MediaViewHolder).bind(item.file)
            }

            is AdapterItem.ListItem -> {
                (holder as ListViewHolder).bind(item.file)
            }
        }
    }

    override fun getItemCount(): Int =
        items.size

    // =========================================================
    // IMAGE / VIDEO
    // =========================================================

    private fun isImageOrVideo(
        file: DuplicateFile
    ): Boolean {

        return file.mimeType?.startsWith("image/") == true ||
                file.mimeType?.startsWith("video/") == true
    }

    // =========================================================
    // SELECT ALL
    // =========================================================

    fun selectAll(selected: Boolean) {

        groups.flatten().forEach { file ->
            file.isSelected = selected
        }

        notifyDataSetChanged()

        onSelectionChanged()
    }

    // =========================================================
    // SELECTED FILES
    // =========================================================

    fun getSelectedFiles(): List<DuplicateFile> {

        return groups
            .flatten()
            .filter { it.isSelected }
    }

    // =========================================================
    // HEADER
    // =========================================================

    inner class HeaderViewHolder(
        itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        private val title =
            itemView.findViewById<TextView>(
                R.id.txtGroupTitle
            )

        private val count =
            itemView.findViewById<TextView>(
                R.id.txtGroupCount
            )

        private val selectAll =
            itemView.findViewById<CheckBox>(
                R.id.checkboxSelectAll
            )

        fun bind(item: AdapterItem.Header) {

            title.text = item.title
            count.text = "${item.count} files"

            // Prevent listener from firing while RecyclerView re-binds
            selectAll.setOnCheckedChangeListener(null)

            val groupIndex =
                item.title
                    .removePrefix("Duplicate Group ")
                    .toIntOrNull()
                    ?.minus(1)

            if (
                groupIndex != null &&
                groupIndex in groups.indices
            ) {

                val group =
                    groups[groupIndex]

                selectAll.isChecked =
                    group.isNotEmpty() &&
                            group.all {
                                it.isSelected
                            }
            }

            selectAll.setOnCheckedChangeListener { _, checked ->

                if (
                    groupIndex != null &&
                    groupIndex in groups.indices
                ) {

                    groups[groupIndex].forEach { file ->

                        file.isSelected = checked
                    }

                    notifyDataSetChanged()

                    onSelectionChanged()
                }
            }
        }
    }

    // =========================================================
    // PHOTO / VIDEO GALLERY HOLDER
    // =========================================================

    inner class MediaViewHolder(
        itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        private val thumbnail =
            itemView.findViewById<ImageView>(
                R.id.imgThumbnail
            )

        private val selection =
            itemView.findViewById<TextView>(
                R.id.txtSelection
            )

        private val name =
            itemView.findViewById<TextView>(
                R.id.txtFileName
            )

        private val size =
            itemView.findViewById<TextView>(
                R.id.txtFileSize
            )

        fun bind(file: DuplicateFile) {

            name.text = file.name

            size.text =
                formatSize(file.size)

            updateSelection(file)

            loadThumbnail(file)

            itemView.setOnClickListener {

                toggleSelection(file)
            }

            selection.setOnClickListener {

                toggleSelection(file)
            }
        }

        private fun toggleSelection(
            file: DuplicateFile
        ) {

            file.isSelected =
                !file.isSelected

            updateSelection(file)

            onSelectionChanged()
        }

        // =====================================================
        // UPDATED CIRCULAR SELECTION
        // =====================================================

        private fun updateSelection(
            file: DuplicateFile
        ) {

            selection.visibility =
                View.VISIBLE

            selection.text =
                if (file.isSelected) {
                    "✓"
                } else {
                    ""
                }

            // 22dp circle
            val size =
                (
                        22 *
                                itemView.resources
                                    .displayMetrics
                                    .density
                        ).toInt()

            val drawable =
                GradientDrawable().apply {

                    shape =
                        GradientDrawable.OVAL

                    if (file.isSelected) {

                        // Purple filled circle
                        setColor(
                            Color.rgb(
                                108,
                                55,
                                235
                            )
                        )

                    } else {

                        // Transparent circle
                        setColor(
                            Color.TRANSPARENT
                        )

                        // Purple border
                        setStroke(
                            (
                                    2 *
                                            itemView.resources
                                                .displayMetrics
                                                .density
                                    ).toInt(),
                            Color.rgb(
                                108,
                                55,
                                235
                            )
                        )
                    }
                }

            selection.background =
                drawable

            selection.layoutParams =
                selection.layoutParams.apply {

                    width = size
                    height = size
                }

            selection.gravity =
                Gravity.CENTER

            selection.setTextColor(
                Color.WHITE
            )

            selection.textSize =
                12f
        }

        private fun loadThumbnail(
            file: DuplicateFile
        ) {

            // Clear old recycled image
            thumbnail.setImageDrawable(null)

            // Temporary fallback
            thumbnail.setImageResource(
                if (
                    file.mimeType
                        ?.startsWith("video/") == true
                ) {
                    R.drawable.ic_videos
                } else {
                    R.drawable.ic_photos
                }
            )

            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.Q
            ) {

                executor.execute {

                    try {

                        val bitmap: Bitmap? =
                            itemView.context
                                .contentResolver
                                .loadThumbnail(
                                    file.uri,
                                    Size(500, 500),
                                    null
                                )

                        itemView.post {

                            if (
                                bitmap != null &&
                                itemView.isAttachedToWindow
                            ) {

                                thumbnail.setImageBitmap(
                                    bitmap
                                )
                            }
                        }

                    } catch (_: Exception) {
                        // Keep fallback icon
                    }
                }

            } else {

                try {

                    thumbnail.setImageURI(
                        file.uri
                    )

                } catch (_: Exception) {
                    // Keep fallback icon
                }
            }
        }
    }

    // =========================================================
    // AUDIO / DOCUMENT / APK LIST HOLDER
    // =========================================================

    inner class ListViewHolder(
        itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        private val icon =
            itemView.findViewById<ImageView>(
                R.id.imgFileIcon
            )

        private val selection =
            itemView.findViewById<TextView>(
                R.id.txtSelection
            )

        private val name =
            itemView.findViewById<TextView>(
                R.id.txtFileName
            )

        private val size =
            itemView.findViewById<TextView>(
                R.id.txtFileSize
            )

        fun bind(file: DuplicateFile) {

            name.text = file.name

            size.text =
                formatSize(file.size)

            setFileIcon(file)

            updateSelection(file)

            itemView.setOnClickListener {

                toggleSelection(file)
            }

            selection.setOnClickListener {

                toggleSelection(file)
            }
        }

        private fun toggleSelection(
            file: DuplicateFile
        ) {

            file.isSelected =
                !file.isSelected

            updateSelection(file)

            onSelectionChanged()
        }

        private fun setFileIcon(
            file: DuplicateFile
        ) {

            when {

                file.mimeType
                    ?.startsWith("audio/") == true -> {

                    icon.setImageResource(
                        R.drawable.ic_audios
                    )
                }

                file.mimeType
                    ?.contains("apk") == true -> {

                    icon.setImageResource(
                        R.drawable.apks_icon
                    )
                }

                file.mimeType
                    ?.contains("pdf") == true ||
                        file.mimeType
                            ?.contains("document") == true ||
                        file.mimeType
                            ?.startsWith("text/") == true -> {

                    icon.setImageResource(
                        R.drawable.ic_documents
                    )
                }

                else -> {

                    icon.setImageResource(
                        R.drawable.ic_documents
                    )
                }
            }
        }

        // =====================================================
        // UPDATED CIRCULAR SELECTION
        // =====================================================

        private fun updateSelection(
            file: DuplicateFile
        ) {

            selection.visibility =
                View.VISIBLE

            selection.text =
                if (file.isSelected) {
                    "✓"
                } else {
                    ""
                }

            // 22dp circle
            val size =
                (
                        22 *
                                itemView.resources
                                    .displayMetrics
                                    .density
                        ).toInt()

            val drawable =
                GradientDrawable().apply {

                    shape =
                        GradientDrawable.OVAL

                    if (file.isSelected) {

                        // Purple filled circle
                        setColor(
                            Color.rgb(
                                108,
                                55,
                                235
                            )
                        )

                    } else {

                        // Transparent circle
                        setColor(
                            Color.TRANSPARENT
                        )

                        // Purple border
                        setStroke(
                            (
                                    2 *
                                            itemView.resources
                                                .displayMetrics
                                                .density
                                    ).toInt(),
                            Color.rgb(
                                108,
                                55,
                                235
                            )
                        )
                    }
                }

            selection.background =
                drawable

            selection.layoutParams =
                selection.layoutParams.apply {

                    width = size
                    height = size
                }

            selection.gravity =
                Gravity.CENTER

            selection.setTextColor(
                Color.WHITE
            )

            selection.textSize =
                12f
        }
    }

    // =========================================================
    // FORMAT SIZE
    // =========================================================

    private fun formatSize(
        bytes: Long
    ): String {

        if (bytes <= 0) {
            return "0 B"
        }

        val kb = 1024.0
        val mb = kb * 1024
        val gb = mb * 1024

        return when {

            bytes >= gb -> {

                String.format(
                    Locale.US,
                    "%.1f GB",
                    bytes / gb
                )
            }

            bytes >= mb -> {

                String.format(
                    Locale.US,
                    "%.1f MB",
                    bytes / mb
                )
            }

            bytes >= kb -> {

                String.format(
                    Locale.US,
                    "%.1f KB",
                    bytes / kb
                )
            }

            else -> {
                "$bytes B"
            }
        }
    }

    // =========================================================
    // SHUTDOWN
    // =========================================================

    fun shutdown() {
        executor.shutdown()
    }
}