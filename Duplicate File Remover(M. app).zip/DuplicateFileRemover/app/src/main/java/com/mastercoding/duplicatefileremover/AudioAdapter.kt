package com.mastercoding.duplicatefileremover

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AudioAdapter(
    private val audios: List<AudioItem>
) : RecyclerView.Adapter<AudioAdapter.AudioViewHolder>() {

    class AudioViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val icon: ImageView =
            itemView.findViewById(R.id.imgAudio)

        val name: TextView =
            itemView.findViewById(R.id.txtAudioName)

        val size: TextView =
            itemView.findViewById(R.id.txtAudioSize)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): AudioViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_audio,
                parent,
                false
            )

        return AudioViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: AudioViewHolder,
        position: Int
    ) {

        val audio = audios[position]

        holder.name.text = audio.name

        holder.size.text =
            formatFileSize(audio.size)

        holder.icon.setImageResource(
            R.drawable.ic_audios
        )
    }

    override fun getItemCount(): Int {
        return audios.size
    }

    private fun formatFileSize(size: Long): String {

        if (size <= 0) {
            return "0 KB"
        }

        val kb = size / 1024.0

        if (kb < 1024) {
            return "%.1f KB".format(kb)
        }

        val mb = kb / 1024.0

        if (mb < 1024) {
            return "%.1f MB".format(mb)
        }

        val gb = mb / 1024.0

        return "%.1f GB".format(gb)
    }
}