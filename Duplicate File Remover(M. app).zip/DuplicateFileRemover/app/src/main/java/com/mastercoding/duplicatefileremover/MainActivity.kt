package com.mastercoding.duplicatefileremover

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView

    private lateinit var txtUsedStorage: TextView
    private lateinit var txtTotalStorage: TextView
    private lateinit var storageProgress: ProgressBar

    private lateinit var txtStoragePhotos: TextView
    private lateinit var txtStorageAudios: TextView
    private lateinit var txtStorageVideos: TextView
    private lateinit var txtStorageDocuments: TextView
    private lateinit var txtStorageApks: TextView

    private val executor =
        Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        recyclerView =
            findViewById(R.id.rvCategories)

        recyclerView.layoutManager =
            GridLayoutManager(this, 2)

        txtUsedStorage =
            findViewById(R.id.txtUsedStorage)

        txtTotalStorage =
            findViewById(R.id.txtTotalStorage)

        storageProgress =
            findViewById(R.id.storageProgress)

        txtStoragePhotos =
            findViewById(R.id.txtStoragePhotos)

        txtStorageAudios =
            findViewById(R.id.txtStorageAudios)

        txtStorageVideos =
            findViewById(R.id.txtStorageVideos)

        txtStorageDocuments =
            findViewById(R.id.txtStorageDocuments)

        txtStorageApks =
            findViewById(R.id.txtStorageApks)

        checkPermissions()

        // =====================================================
        // EXIT CONFIRMATION
        // =====================================================

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {

                override fun handleOnBackPressed() {
                    showExitDialog()
                }
            }
        )
    }


    // =========================================================
    // EXIT DIALOG
    // =========================================================

    private fun showExitDialog() {

        val dialog =
            Dialog(this)

        dialog.window?.setBackgroundDrawableResource(
            android.R.color.transparent
        )

        // Main dialog container
        val container =
            android.widget.LinearLayout(this).apply {

                orientation =
                    android.widget.LinearLayout.VERTICAL

                gravity =
                    Gravity.CENTER

                setPadding(
                    dp(24),
                    dp(22),
                    dp(24),
                    dp(20)
                )

                background =
                    GradientDrawable().apply {

                        shape =
                            GradientDrawable.RECTANGLE

                        setColor(
                            Color.WHITE
                        )

                        cornerRadius =
                            dp(20).toFloat()
                    }
            }


        // =====================================================
        // TITLE
        // =====================================================

        val title =
            TextView(this).apply {

                text =
                    "Are you sure want to exit?"

                textSize =
                    19f

                setTextColor(
                    Color.rgb(
                        35,
                        35,
                        35
                    )
                )

                setTypeface(
                    typeface,
                    android.graphics.Typeface.BOLD
                )

                gravity =
                    Gravity.CENTER

                layoutParams =
                    android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            }

        container.addView(title)


        // =====================================================
        // MESSAGE
        // =====================================================

        val message =
            TextView(this).apply {

                text =
                    "Do you really want to close the app?"

                textSize =
                    13f

                setTextColor(
                    Color.rgb(
                        110,
                        110,
                        110
                    )
                )

                gravity =
                    Gravity.CENTER

                layoutParams =
                    android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {

                        topMargin =
                            dp(8)

                        bottomMargin =
                            dp(20)
                    }
            }

        container.addView(message)


        // =====================================================
        // BUTTON ROW
        // =====================================================

        val buttonRow =
            android.widget.LinearLayout(this).apply {

                orientation =
                    android.widget.LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER

                layoutParams =
                    android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            }


        // =====================================================
        // CANCEL BUTTON
        // =====================================================

        val cancelButton =
            Button(this).apply {

                text =
                    "Cancel"

                textSize =
                    13f

                setTextColor(
                    Color.rgb(
                        108,
                        55,
                        235
                    )
                )

                isAllCaps =
                    false

                background =
                    GradientDrawable().apply {

                        shape =
                            GradientDrawable.RECTANGLE

                        setColor(
                            Color.TRANSPARENT
                        )

                        setStroke(
                            dp(1),
                            Color.rgb(
                                108,
                                55,
                                235
                            )
                        )

                        cornerRadius =
                            dp(12).toFloat()
                    }

                stateListAnimator =
                    null

                layoutParams =
                    android.widget.LinearLayout.LayoutParams(
                        0,
                        dp(46),
                        1f
                    ).apply {

                        marginEnd =
                            dp(6)
                    }
            }

        buttonRow.addView(cancelButton)


        // =====================================================
        // EXIT BUTTON
        // =====================================================

        val exitButton =
            Button(this).apply {

                text =
                    "Exit"

                textSize =
                    13f

                setTextColor(
                    Color.WHITE
                )

                isAllCaps =
                    false

                background =
                    GradientDrawable().apply {

                        shape =
                            GradientDrawable.RECTANGLE

                        setColor(
                            Color.rgb(
                                108,
                                55,
                                235
                            )
                        )

                        cornerRadius =
                            dp(12).toFloat()
                    }

                stateListAnimator =
                    null

                layoutParams =
                    android.widget.LinearLayout.LayoutParams(
                        0,
                        dp(46),
                        1f
                    ).apply {

                        marginStart =
                            dp(6)
                    }
            }

        buttonRow.addView(exitButton)

        container.addView(buttonRow)


        // =====================================================
        // BUTTON ACTIONS
        // =====================================================

        cancelButton.setOnClickListener {

            dialog.dismiss()
        }

        exitButton.setOnClickListener {

            dialog.dismiss()

            finishAffinity()
        }


        // =====================================================
        // SHOW DIALOG
        // =====================================================

        dialog.setContentView(
            container
        )

        dialog.setCancelable(true)

        dialog.show()

        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.88).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.window?.setGravity(
            Gravity.CENTER
        )
    }


    // =========================================================
    // DP HELPER
    // =========================================================

    private fun dp(
        value: Int
    ): Int {

        return (
                value *
                        resources.displayMetrics.density
                ).toInt()
    }


    // =========================================================
    // AUTOMATIC RUNTIME PERMISSION
    // =========================================================

    private fun checkPermissions() {

        val imagePermission =
            StorageHelper.hasImagePermission(this)

        val videoPermission =
            StorageHelper.hasVideoPermission(this)

        val audioPermission =
            StorageHelper.hasAudioPermission(this)


        if (!imagePermission) {

            StorageHelper.requestImagePermission(this)

            return
        }

        if (!videoPermission) {

            StorageHelper.requestVideoPermission(this)

            return
        }

        if (!audioPermission) {

            StorageHelper.requestAudioPermission(this)

            return
        }

        loadHomeData()
    }


    // =========================================================
    // PERMISSION RESULT
    // =========================================================

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (
            requestCode ==
            StorageHelper.REQUEST_MEDIA_PERMISSION
        ) {

            checkPermissions()
        }
    }


    // =========================================================
    // LOAD REAL PHONE DATA
    // =========================================================

    private fun loadHomeData() {

        executor.execute {

            val totalStorage =
                StorageHelper.getTotalStorage()

            val usedStorage =
                StorageHelper.getUsedStorage()

            val photoCount =
                StorageHelper.getPhotoCount(this)

            val videoCount =
                StorageHelper.getVideoCount(this)

            val audioCount =
                StorageHelper.getAudioCount(this)

            val documentCount =
                StorageHelper.getDocumentCount(this)

            val apkCount =
                StorageHelper.getApkCount(this)

            val photoSize =
                StorageHelper.getPhotoSize(this)

            val videoSize =
                StorageHelper.getVideoSize(this)

            val audioSize =
                StorageHelper.getAudioSize(this)

            val documentSize =
                StorageHelper.getDocumentSize(this)

            val apkSize =
                StorageHelper.getApkSize(this)


            val categories =
                listOf(

                    Category(
                        name = "Photos",
                        icon = R.drawable.photos_icon,
                        count = "$photoCount items"
                    ),

                    Category(
                        name = "Videos",
                        icon = R.drawable.videos_icon,
                        count = "$videoCount items"
                    ),

                    Category(
                        name = "Audios",
                        icon = R.drawable.audios_icon,
                        count = "$audioCount items"
                    ),

                    Category(
                        name = "Documents",
                        icon = R.drawable.documents_icon,
                        count = "$documentCount items"
                    ),

                    Category(
                        name = "APKs",
                        icon = R.drawable.apks_icon,
                        count = "$apkCount items"
                    ),

                    Category(
                        name = "Privacy Policy",
                        icon = R.drawable.ic_privacy,
                        count = ""
                    )
                )


            val storagePercentage =
                if (totalStorage > 0) {

                    (
                            usedStorage.toDouble()
                                    / totalStorage.toDouble()
                                    * 100
                            ).toInt()

                } else {
                    0
                }


            runOnUiThread {

                txtUsedStorage.text =
                    StorageHelper.formatStorage(
                        usedStorage
                    )

                txtTotalStorage.text =
                    " Used from ${
                        StorageHelper.formatStorage(
                            totalStorage
                        )
                    }"

                storageProgress.progress =
                    storagePercentage.coerceIn(
                        0,
                        100
                    )


                // =================================================
                // STORAGE CARD COLORED DOTS
                // =================================================

                txtStoragePhotos.text =
                    createColoredDotText(
                        "Photos",
                        StorageHelper.formatStorage(
                            photoSize
                        ),
                        Color.rgb(
                            110,
                            62,
                            255
                        )
                    )


                txtStorageAudios.text =
                    createColoredDotText(
                        "Audios",
                        StorageHelper.formatStorage(
                            audioSize
                        ),
                        Color.rgb(
                            98,
                            192,
                            54
                        )
                    )


                txtStorageVideos.text =
                    createColoredDotText(
                        "Videos",
                        StorageHelper.formatStorage(
                            videoSize
                        ),
                        Color.rgb(
                            255,
                            62,
                            65
                        )
                    )


                txtStorageDocuments.text =
                    createColoredDotText(
                        "Documents",
                        StorageHelper.formatStorage(
                            documentSize
                        ),
                        Color.rgb(
                            0,
                            0,
                            0
                        )
                    )


                txtStorageApks.text =
                    createColoredDotText(
                        "APKs",
                        StorageHelper.formatStorage(
                            apkSize
                        ),
                        Color.rgb(
                            255,
                            142,
                            62
                        )
                    )


                recyclerView.adapter =
                    CategoryAdapter(
                        categories
                    ) { category ->

                        openCategory(category)
                    }
            }
        }
    }


    // =========================================================
    // COLORED STORAGE DOT
    // =========================================================

    private fun createColoredDotText(
        name: String,
        size: String,
        dotColor: Int
    ): SpannableString {

        val text =
            "▪ $name                 $size"

        val spannable =
            SpannableString(text)

        spannable.setSpan(
            ForegroundColorSpan(dotColor),
            0,
            1,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        return spannable
    }


    // =========================================================
    // CATEGORY CLICK
    // =========================================================

    private fun openCategory(
        category: Category
    ) {

        when (category.name) {

            "Photos" -> {
                startScanning("photos")
            }

            "Videos" -> {
                startScanning("videos")
            }

            "Audios" -> {
                startScanning("audios")
            }

            "Documents" -> {
                startScanning("documents")
            }

            "APKs" -> {
                startScanning("apks")
            }

            "Privacy Policy" -> {

                startActivity(
                    android.content.Intent(
                        this,
                        PrivacyActivity::class.java
                    )
                )
            }
        }
    }


    // =========================================================
    // SCANNING
    // =========================================================

    private fun startScanning(
        type: String
    ) {

        val intent =
            android.content.Intent(
                this,
                ScanningActivity::class.java
            )

        intent.putExtra(
            "MEDIA_TYPE",
            type
        )

        startActivity(intent)
    }


    // =========================================================
    // REFRESH
    // =========================================================

    override fun onResume() {

        super.onResume()

        if (::recyclerView.isInitialized) {

            if (
                StorageHelper.hasImagePermission(this) &&
                StorageHelper.hasVideoPermission(this) &&
                StorageHelper.hasAudioPermission(this)
            ) {
                loadHomeData()
            }
        }
    }


    // =========================================================
    // DESTROY
    // =========================================================

    override fun onDestroy() {

        executor.shutdown()

        super.onDestroy()
    }
}