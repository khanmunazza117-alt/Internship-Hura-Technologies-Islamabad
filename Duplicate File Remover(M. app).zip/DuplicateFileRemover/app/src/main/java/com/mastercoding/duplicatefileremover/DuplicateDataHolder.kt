package com.mastercoding.duplicatefileremover

object DuplicateDataHolder {

    var groups: List<List<DuplicateFile>> = emptyList()

}