package com.mastercoding.duplicatefileremover

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DocumentAdapter(
    private val documents: List<DocumentItem>
) : RecyclerView.Adapter<DocumentAdapter.DocumentViewHolder>() {

    class DocumentViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val icon: ImageView =
            itemView.findViewById(R.id.imgDocument)

        val name: TextView =
            itemView.findViewById(R.id.txtDocumentName)

        val size: TextView =
            itemView.findViewById(R.id.txtDocumentSize)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): DocumentViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_document,
                parent,
                false
            )

        return DocumentViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: DocumentViewHolder,
        position: Int
    ) {

        val document =
            documents[position]

        holder.name.text =
            document.name

        holder.size.text =
            formatFileSize(document.size)
    }

    override fun getItemCount(): Int {
        return documents.size
    }

    private fun formatFileSize(size: Long): String {

        val kb = size / 1024.0

        if (kb < 1024) {
            return "%.1f KB".format(kb)
        }

        val mb = kb / 1024.0

        if (mb < 1024) {
            return "%.1f MB".format(mb)
        }

        val gb = mb / 1024.0

        return "%.1f GB".format(gb)
    }
}