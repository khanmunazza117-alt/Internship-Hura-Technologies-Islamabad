package com.mastercoding.duplicatefileremover

import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class ApksActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var apkCount: TextView

    private val executor =
        Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_apks
        )

        val btnBack =
            findViewById<ImageView>(R.id.btnBack)

        recyclerView =
            findViewById(R.id.rvApks)

        progressBar =
            findViewById(R.id.progressApks)

        apkCount =
            findViewById(R.id.txtApkCount)

        btnBack.setOnClickListener {
            finish()
        }

        recyclerView.layoutManager =
            LinearLayoutManager(this)

        loadApks()
    }

    private fun loadApks() {

        progressBar.visibility =
            ProgressBar.VISIBLE

        executor.execute {

            val apks =
                getApksFromStorage()

            runOnUiThread {

                progressBar.visibility =
                    ProgressBar.GONE

                recyclerView.adapter =
                    ApkAdapter(apks)

                apkCount.text =
                    "${apks.size} APKs"
            }
        }
    }

    private fun getApksFromStorage():
            List<ApkItem> {

        val apks =
            mutableListOf<ApkItem>()

        val collection =
            MediaStore.Files.getContentUri(
                "external"
            )

        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE
        )

        val selection =
            "${MediaStore.Files.FileColumns.MIME_TYPE} = ?"

        val selectionArgs =
            arrayOf(
                "application/vnd.android.package-archive"
            )

        val sortOrder =
            "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"

        contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            sortOrder
        )?.use { cursor ->

            val idColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns._ID
                )

            val nameColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns.DISPLAY_NAME
                )

            val sizeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns.SIZE
                )

            while (cursor.moveToNext()) {

                val id =
                    cursor.getLong(idColumn)

                val name =
                    cursor.getString(nameColumn)

                val size =
                    cursor.getLong(sizeColumn)

                val uri =
                    MediaStore.Files
                        .getContentUri("external")
                        .buildUpon()
                        .appendPath(id.toString())
                        .build()

                apks.add(
                    ApkItem(
                        uri = uri,
                        name = name,
                        size = size
                    )
                )
            }
        }

        return apks
    }

    override fun onDestroy() {

        executor.shutdown()

        super.onDestroy()
    }
}