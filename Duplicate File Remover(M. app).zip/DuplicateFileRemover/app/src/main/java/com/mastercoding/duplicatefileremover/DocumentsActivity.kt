package com.mastercoding.duplicatefileremover

import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class DocumentsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var documentCount: TextView

    private val executor =
        Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_documents
        )

        val btnBack =
            findViewById<ImageView>(R.id.btnBack)

        recyclerView =
            findViewById(R.id.rvDocuments)

        progressBar =
            findViewById(R.id.progressDocuments)

        documentCount =
            findViewById(R.id.txtDocumentCount)

        btnBack.setOnClickListener {
            finish()
        }

        recyclerView.layoutManager =
            LinearLayoutManager(this)

        loadDocuments()
    }

    private fun loadDocuments() {

        progressBar.visibility =
            ProgressBar.VISIBLE

        executor.execute {

            val documents =
                getDocumentsFromStorage()

            runOnUiThread {

                progressBar.visibility =
                    ProgressBar.GONE

                recyclerView.adapter =
                    DocumentAdapter(documents)

                documentCount.text =
                    "${documents.size} Documents"
            }
        }
    }

    private fun getDocumentsFromStorage():
            List<DocumentItem> {

        val documents =
            mutableListOf<DocumentItem>()

        val collection =
            MediaStore.Files.getContentUri(
                "external"
            )

        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE
        )

        val selection = """
            ${MediaStore.Files.FileColumns.MIME_TYPE} IN (
                'application/pdf',
                'text/plain',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-powerpoint',
                'application/vnd.openxmlformats-officedocument.presentationml.presentation'
            )
        """.trimIndent()

        val sortOrder =
            "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"

        contentResolver.query(
            collection,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->

            val idColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns._ID
                )

            val nameColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns.DISPLAY_NAME
                )

            val sizeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns.SIZE
                )

            val mimeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Files.FileColumns.MIME_TYPE
                )
           
            while (cursor.moveToNext()) {

                val id =
                    cursor.getLong(idColumn)

                val name =
                    cursor.getString(nameColumn)

                val size =
                    cursor.getLong(sizeColumn)

                val mimeType =
                    cursor.getString(mimeColumn)

                val uri =
                    MediaStore.Files
                        .getContentUri("external")
                        .buildUpon()
                        .appendPath(id.toString())
                        .build()

                documents.add(
                    DocumentItem(
                        uri = uri,
                        name = name,
                        size = size,
                        mimeType = mimeType
                    )
                )
            }
        }

        return documents
    }

    override fun onDestroy() {

        executor.shutdown()

        super.onDestroy()
    }
}