package com.mastercoding.duplicatefileremover

import android.net.Uri

data class DocumentItem(
    val uri: Uri,
    val name: String,
    val size: Long,
    val mimeType: String
)