package com.mastercoding.duplicatefileremover

import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class VideosActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var videoCount: TextView

    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_videos)

        val btnBack = findViewById<ImageView>(R.id.btnBack)

        recyclerView = findViewById(R.id.rvVideos)
        progressBar = findViewById(R.id.progressVideos)
        videoCount = findViewById(R.id.txtVideoCount)

        btnBack.setOnClickListener {
            finish()
        }

        recyclerView.layoutManager =
            GridLayoutManager(this, 3)

        checkPermissionAndLoadVideos()
    }

    private fun checkPermissionAndLoadVideos() {

        if (StorageHelper.hasVideoPermission(this)) {

            loadVideos()

        } else {

            StorageHelper.requestVideoPermission(this)
        }
    }

    private fun loadVideos() {

        progressBar.visibility = ProgressBar.VISIBLE

        executor.execute {

            val videos = getVideosFromMediaStore()

            runOnUiThread {

                progressBar.visibility = ProgressBar.GONE

                recyclerView.adapter =
                    VideoAdapter(videos)

                videoCount.text =
                    "${videos.size} Videos"
            }
        }
    }

    private fun getVideosFromMediaStore(): List<VideoItem> {

        val videos = mutableListOf<VideoItem>()

        val collection =
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE
        )

        val sortOrder =
            "${MediaStore.Video.Media.DATE_ADDED} DESC"

        contentResolver.query(
            collection,
            projection,
            null,
            null,
            sortOrder
        )?.use { cursor ->

            val idColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Video.Media._ID
                )

            val nameColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Video.Media.DISPLAY_NAME
                )

            val sizeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.Video.Media.SIZE
                )

            while (cursor.moveToNext()) {

                val id =
                    cursor.getLong(idColumn)

                val name =
                    cursor.getString(nameColumn)

                val size =
                    cursor.getLong(sizeColumn)

                val uri =
                    MediaStore.Video.Media
                        .EXTERNAL_CONTENT_URI
                        .buildUpon()
                        .appendPath(id.toString())
                        .build()

                videos.add(
                    VideoItem(
                        uri = uri,
                        name = name,
                        size = size
                    )
                )
            }
        }

        return videos
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (
            requestCode ==
            StorageHelper.REQUEST_MEDIA_PERMISSION
        ) {

            if (StorageHelper.hasVideoPermission(this)) {

                loadVideos()

            } else {

                Toast.makeText(
                    this,
                    "Video permission is required",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {

        executor.shutdown()

        super.onDestroy()
    }
}