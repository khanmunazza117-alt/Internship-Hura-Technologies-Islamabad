package com.mastercoding.duplicatefileremover

import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class DuplicateActivity : AppCompatActivity() {

    // =========================================================
    // VIEWS
    // =========================================================

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var duplicateCount: TextView
    private lateinit var btnSelectAll: TextView
    private lateinit var btnDelete: Button
    private lateinit var txtPageTitle: TextView

    // =========================================================
    // ADAPTER
    // =========================================================

    private var adapter: DuplicateAdapter? = null

    // =========================================================
    // EXECUTOR
    // =========================================================

    private val executor =
        Executors.newSingleThreadExecutor()

    // =========================================================
    // DELETE RESULT
    // =========================================================

    private val deleteLauncher =
        registerForActivityResult(
            ActivityResultContracts.StartIntentSenderForResult()
        ) { result ->

            if (result.resultCode == RESULT_OK) {

                Toast.makeText(
                    this,
                    "Selected files deleted",
                    Toast.LENGTH_SHORT
                ).show()

                scanDuplicates()
            }
        }

    // =========================================================
    // ON CREATE
    // =========================================================

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.activity_duplicates
        )

        // =====================================================
        // FIND VIEWS
        // =====================================================

        val btnBack =
            findViewById<ImageView>(
                R.id.btnBack
            )

        recyclerView =
            findViewById(
                R.id.rvDuplicates
            )

        progressBar =
            findViewById(
                R.id.progressScan
            )

        duplicateCount =
            findViewById(
                R.id.txtDuplicateCount
            )

        btnSelectAll =
            findViewById(
                R.id.btnSelectAll
            )

        btnDelete =
            findViewById(
                R.id.btnDelete
            )

        txtPageTitle =
            findViewById(
                R.id.txtPageTitle
            )

        // =====================================================
        // GET CURRENT MEDIA TYPE
        // =====================================================

        val mediaType =
            intent.getStringExtra(
                "MEDIA_TYPE"
            )
                ?.lowercase()
                ?: "photos"

        // =====================================================
        // PAGE TITLE
        // =====================================================

        txtPageTitle.text =
            when (mediaType) {

                "photos" -> {
                    "Photos"
                }

                "videos" -> {
                    "Videos"
                }

                "audios" -> {
                    "Audios"
                }

                "documents" -> {
                    "Documents"
                }

                "apks" -> {
                    "APKs"
                }

                else -> {
                    "Duplicates"
                }
            }

        // =====================================================
        // BACK BUTTON
        // =====================================================

        btnBack.setOnClickListener {

            finish()
        }

        // =====================================================
        // GRID
        // =====================================================

        val gridLayoutManager =
            GridLayoutManager(
                this,
                3
            )

        recyclerView.layoutManager =
            gridLayoutManager

        // =====================================================
        // GRID SPAN SIZE
        // =====================================================
        //
        // Media thumbnails = 3 columns
        // Headers / list items = full width
        //
        // =====================================================

        gridLayoutManager.spanSizeLookup =
            object : GridLayoutManager.SpanSizeLookup() {

                override fun getSpanSize(
                    position: Int
                ): Int {

                    val currentAdapter =
                        recyclerView.adapter
                                as? DuplicateAdapter
                            ?: return 3

                    return when (
                        currentAdapter.getItemViewType(
                            position
                        )
                    ) {

                        // Media thumbnail
                        1 -> 1

                        // Header / list item
                        else -> 3
                    }
                }
            }

        // =====================================================
        // SELECT ALL
        // =====================================================

        btnSelectAll.setOnClickListener {

            adapter?.selectAll(true)

            updateDeleteButton()
        }

        // =====================================================
        // DELETE
        // =====================================================

        btnDelete.setOnClickListener {

            deleteSelectedFiles()
        }

        // =====================================================
        // SCAN CURRENT CATEGORY
        // =====================================================

        scanDuplicates()
    }

    // =========================================================
    // SCAN DUPLICATES
    // =========================================================

    private fun scanDuplicates() {

        progressBar.visibility =
            View.VISIBLE

        duplicateCount.text =
            "Scanning your storage..."

        executor.execute {

            try {

                val scanner =
                    DuplicateScanner(this)

                // =================================================
                // GET CURRENT CATEGORY
                // =================================================

                val mediaType =
                    intent.getStringExtra(
                        "MEDIA_TYPE"
                    )
                        ?.lowercase()
                        ?: "photos"

                // =================================================
                // SCAN ONLY CURRENT CATEGORY
                // =================================================

                val allGroups =
                    when (mediaType) {

                        "photos" -> {

                            scanner.scanImages()
                        }

                        "videos" -> {

                            scanner.scanVideos()
                        }

                        "audios" -> {

                            scanner.scanAudios()
                        }

                        "documents" -> {

                            scanner.scanDocuments()
                        }

                        "apks" -> {

                            scanner.scanApks()
                        }

                        else -> {

                            emptyList()
                        }
                    }

                // =================================================
                // TOTAL DUPLICATE FILES
                // =================================================

                val totalFiles =
                    allGroups.sumOf {
                        it.size
                    }

                // =================================================
                // UPDATE UI
                // =================================================

                runOnUiThread {

                    progressBar.visibility =
                        View.GONE

                    duplicateCount.text =
                        if (allGroups.isEmpty()) {

                            "Duplicates Found : 0"

                        } else {

                            "Duplicates Found : $totalFiles"
                        }

                    // =================================================
                    // CREATE ADAPTER
                    // =================================================

                    adapter =
                        DuplicateAdapter(
                            allGroups
                        ) {

                            updateDeleteButton()
                        }

                    recyclerView.adapter =
                        adapter

                    // =================================================
                    // REFRESH GRID
                    // =================================================

                    recyclerView.layoutManager =
                        recyclerView.layoutManager

                    // =================================================
                    // SHOW / HIDE DELETE
                    // =================================================

                    btnDelete.visibility =
                        if (allGroups.isEmpty()) {

                            View.GONE

                        } else {

                            View.VISIBLE
                        }

                    // =================================================
                    // SHOW / HIDE SELECT ALL
                    // =================================================

                    btnSelectAll.visibility =
                        if (allGroups.isEmpty()) {

                            View.GONE

                        } else {

                            View.VISIBLE
                        }

                    // =================================================
                    // UPDATE DELETE BUTTON
                    // =================================================

                    updateDeleteButton()
                }

            } catch (e: Exception) {

                e.printStackTrace()

                runOnUiThread {

                    progressBar.visibility =
                        View.GONE

                    duplicateCount.text =
                        "Duplicates Found : 0"

                    Toast.makeText(
                        this,
                        "Unable to scan storage",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    // =========================================================
    // DELETE SELECTED FILES
    // =========================================================

    private fun deleteSelectedFiles() {

        val selectedFiles =
            adapter
                ?.getSelectedFiles()
                ?: emptyList()

        // =====================================================
        // NOTHING SELECTED
        // =====================================================

        if (selectedFiles.isEmpty()) {

            Toast.makeText(
                this,
                "Please select files first",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        // =====================================================
        // GET URIS
        // =====================================================

        val uris =
            selectedFiles.map {
                it.uri
            }

        // =====================================================
        // ANDROID 11+
        // =====================================================

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.R
        ) {

            try {

                val pendingIntent =
                    MediaStore.createDeleteRequest(
                        contentResolver,
                        uris
                    )

                val request =
                    IntentSenderRequest
                        .Builder(
                            pendingIntent.intentSender
                        )
                        .build()

                deleteLauncher.launch(
                    request
                )

            } catch (e: Exception) {

                e.printStackTrace()

                Toast.makeText(
                    this,
                    "Unable to delete files",
                    Toast.LENGTH_LONG
                ).show()
            }

        } else {

            // =================================================
            // ANDROID 10 AND BELOW
            // =================================================

            executor.execute {

                var deleted =
                    0

                selectedFiles.forEach {

                    try {

                        val result =
                            contentResolver.delete(
                                it.uri,
                                null,
                                null
                            )

                        if (result > 0) {

                            deleted++
                        }

                    } catch (e: Exception) {

                        e.printStackTrace()
                    }
                }

                runOnUiThread {

                    Toast.makeText(
                        this,
                        "$deleted files deleted",
                        Toast.LENGTH_SHORT
                    ).show()

                    scanDuplicates()
                }
            }
        }
    }

    // =========================================================
    // UPDATE DELETE BUTTON
    // =========================================================

    private fun updateDeleteButton() {

        val count =
            adapter
                ?.getSelectedFiles()
                ?.size
                ?: 0

        btnDelete.text =
            if (count > 0) {

                "Delete ($count)"

            } else {

                "Delete Selected"
            }
    }

    // =========================================================
    // DESTROY
    // =========================================================

    override fun onDestroy() {

        adapter?.shutdown()

        executor.shutdown()

        super.onDestroy()
    }
}