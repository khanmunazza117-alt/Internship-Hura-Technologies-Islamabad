package com.mastercoding.phonecleaner

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.mastercoding.phonecleaner.databinding.ActivityDuplicateCategoryBinding
import java.security.MessageDigest


class DuplicateCategoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDuplicateCategoryBinding

    private lateinit var kind: DuplicateFile.Kind

    // All files found in the selected category
    private val allFiles = mutableListOf<DuplicateFile>()

    // Only duplicate files (candidates for deletion)
    private val files = mutableListOf<DuplicateFile>()

    // Duplicate sets grouped by content hash
    private val duplicateGroups = mutableListOf<List<DuplicateFile>>()

    private val selected = linkedSetOf<Uri>()

    private var ignoreSelectAllCallback = false

    private lateinit var adapter: DuplicateGroupAdapter

    // ---------------------------------------------------------
    // PERMISSION
    // ---------------------------------------------------------

    private val permissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->

            if (hasRequiredPermissions(result)) {
                loadFiles()
            } else {
                showEmpty("Storage permission is required")
            }
        }

    // ---------------------------------------------------------
    // DELETE PERMISSION
    // ---------------------------------------------------------

    private val deleteLauncher =
        registerForActivityResult(
            ActivityResultContracts.StartIntentSenderForResult()
        ) { result ->

            if (result.resultCode == RESULT_OK) {

                allFiles.removeAll {
                    selected.contains(it.uri)
                }

                files.removeAll {
                    selected.contains(it.uri)
                }

                duplicateGroups.removeAll { group ->
                    group.all { selected.contains(it.uri) }
                }

                duplicateGroups.replaceAll { group ->
                    group.filterNot { selected.contains(it.uri) }
                }

                duplicateGroups.removeAll { it.size < 2 }

                selected.clear()

                if (duplicateGroups.isEmpty()) {
                    showEmpty("No Duplicate ${labelForKind()}s Found")
                } else {
                    renderResults()
                }
            }
        }

    // ---------------------------------------------------------
    // ON CREATE
    // ---------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding =
            ActivityDuplicateCategoryBinding.inflate(layoutInflater)

        setContentView(binding.root)

        window.enablePhoneCleanerEdgeToEdge(binding.root)

        // Get selected category
        kind = DuplicateFile.Kind.valueOf(
            intent.getStringExtra("kind") ?: "PHOTO"
        )

        // Dynamic title
        binding.tvTitle.text = titleForKind()

        // Back
        binding.btnBack.setOnClickListener {
            finish()
        }

        // Clean
        binding.btnCleanNow.setOnClickListener {
            deleteSelected()
        }

        // Select all
        binding.checkSelectAll.setOnCheckedChangeListener { _, checked ->

            if (ignoreSelectAllCallback) {
                return@setOnCheckedChangeListener
            }

            selected.clear()

            if (checked) {
                selected.addAll(
                    files.map { it.uri }
                )
            }

            refreshSelectionVisuals()
        }

        // RecyclerView renders groups lazily to avoid blocking the UI thread.
        adapter = DuplicateGroupAdapter(this) { uri, checked ->
            if (checked) {
                selected.add(uri)
            } else {
                selected.remove(uri)
            }
            adapter.submit(duplicateGroups, selected)
            updateSelectAllState()
        }

        binding.rvGroups.layoutManager =
            GridLayoutManager(this, 1)

        binding.rvGroups.setHasFixedSize(false)

        binding.rvGroups.adapter = adapter

        // Start loading
        showScanning()

        requestPermissionAndScan()
    }

    // ---------------------------------------------------------
    // PERMISSION
    // ---------------------------------------------------------

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when (kind) {
                DuplicateFile.Kind.PHOTO ->
                    arrayOf(Manifest.permission.READ_MEDIA_IMAGES)

                DuplicateFile.Kind.VIDEO ->
                    arrayOf(Manifest.permission.READ_MEDIA_VIDEO)

                DuplicateFile.Kind.AUDIO ->
                    arrayOf(Manifest.permission.READ_MEDIA_AUDIO)

                DuplicateFile.Kind.DOCUMENT ->
                    arrayOf(
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_AUDIO
                    )
            }
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    private fun hasRequiredPermissions(
        granted: Map<String, Boolean>? = null
    ): Boolean {

        val permissions = requiredPermissions()

        return if (
            kind == DuplicateFile.Kind.DOCUMENT &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
        ) {
            permissions.any { permission ->
                granted?.get(permission)
                    ?: (
                            ContextCompat.checkSelfPermission(
                                this,
                                permission
                            ) == PackageManager.PERMISSION_GRANTED
                            )
            }
        } else {
            permissions.all { permission ->
                granted?.get(permission)
                    ?: (
                            ContextCompat.checkSelfPermission(
                                this,
                                permission
                            ) == PackageManager.PERMISSION_GRANTED
                            )
            }
        }
    }

    private fun requestPermissionAndScan() {

        if (hasRequiredPermissions()) {
            loadFiles()
        } else {
            permissionLauncher.launch(requiredPermissions())
        }
    }

    // ---------------------------------------------------------
    // LOADING SCREEN
    // ---------------------------------------------------------

    private fun showScanning() {

        binding.scanningContainer.visibility = View.VISIBLE
        binding.resultsContainer.visibility = View.GONE

        binding.ivScanArtwork.setImageResource(
            artworkForKind()
        )

        binding.tvScanPercent.text = "Loading..."

        binding.tvScanMessage.text =
            "Finding ${labelForKind()}s..."
    }

    // ---------------------------------------------------------
    // LOAD REAL FILES
    // ---------------------------------------------------------

    private fun loadFiles() {

        showScanning()

        Thread {

            try {

                // First get actual files.
                val result = queryMedia()

                runOnUiThread {

                    allFiles.clear()
                    allFiles.addAll(result)
                }

                /*
                 * Duplicate detection is run separately. The scanning screen
                 * (with the category artwork) stays visible until both the
                 * media query and the duplicate detection are finished, then
                 * the results are shown.
                 */
                findDuplicates(result)

            } catch (e: Exception) {

                runOnUiThread {

                    showEmpty(
                        "Unable to load ${labelForKind()}s"
                    )
                }
            }

        }.start()
    }

    // ---------------------------------------------------------
    // FIND DUPLICATES
    // ---------------------------------------------------------

    private fun findDuplicates(
        sourceFiles: List<DuplicateFile>
    ) {

        Thread {

            try {

                // Nothing to scan.
                if (sourceFiles.isEmpty()) {

                    runOnUiThread {

                        showEmpty(
                            "No ${labelForKind()}s Found"
                        )
                    }

                    return@Thread
                }

                /*
                 * Only files that share the same byte size can be
                 * duplicates, so group by size first.
                 */
                val sameSizeGroups =
                    sourceFiles
                        .groupBy { it.size }
                        .values
                        .filter { it.size > 1 }

                // No two files share a size -> no duplicates possible.
                if (sameSizeGroups.isEmpty()) {

                    runOnUiThread {

                        showEmpty(
                            "No Duplicate ${labelForKind()}s Found"
                        )
                    }

                    return@Thread
                }

                /*
                 * Hash each same-size group. The scanning screen stays
                 * visible and the percentage updates as groups complete.
                 */
                val groups = mutableListOf<List<DuplicateFile>>()

                val totalGroups = sameSizeGroups.size

                sameSizeGroups.forEachIndexed { index, sameSizeFiles ->

                    val hashed =
                        sameSizeFiles
                            .asSequence()
                            .mapNotNull { file ->
                                sha256(file.uri)?.let { hash ->
                                    hash to file
                                }
                            }
                            .groupBy(
                                { it.first },
                                { it.second }
                            )
                            .values
                            .filter { it.size > 1 }

                    groups.addAll(hashed)

                    val percent =
                        ((index + 1) * 100 / totalGroups)
                            .coerceIn(0, 100)

                    runOnUiThread {

                        binding.tvScanPercent.text =
                            "$percent%"
                    }
                }

                val duplicateFiles =
                    groups.flatMap { group ->
                        group.drop(1)
                    }

                runOnUiThread {

                    duplicateGroups.clear()
                    duplicateGroups.addAll(groups)

                    files.clear()
                    files.addAll(duplicateFiles)

                    selected.clear()
                    selected.addAll(
                        files.map { it.uri }
                    )

                    if (duplicateGroups.isNotEmpty()) {

                        renderResults()

                    } else {

                        showEmpty(
                            "No Duplicate ${labelForKind()}s Found"
                        )
                    }
                }

            } catch (_: Exception) {

                runOnUiThread {

                    if (allFiles.isEmpty()) {

                        showEmpty(
                            "Unable to load ${labelForKind()}s"
                        )

                    } else {

                        showEmpty(
                            "No Duplicate ${labelForKind()}s Found"
                        )
                    }
                }
            }

        }.start()
    }

    // ---------------------------------------------------------
    // QUERY MEDIA STORE
    // ---------------------------------------------------------

    private fun queryMedia(): List<DuplicateFile> {

        val collection = when (kind) {

            DuplicateFile.Kind.PHOTO ->
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI

            DuplicateFile.Kind.VIDEO ->
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI

            DuplicateFile.Kind.AUDIO ->
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

            DuplicateFile.Kind.DOCUMENT ->
                MediaStore.Files.getContentUri("external")
        }

        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE
        )

        /*
         * Proper document filtering.
         */
        val selection: String?
        val selectionArgs: Array<String>?

        if (kind == DuplicateFile.Kind.DOCUMENT) {

            selection =
                "${MediaStore.MediaColumns.MIME_TYPE} IN (?, ?, ?, ?, ?, ?, ?, ?, ?)"

            selectionArgs = arrayOf(
                "application/pdf",
                "text/plain",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-powerpoint",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                "text/csv"
            )

        } else {

            selection = null
            selectionArgs = null
        }

        val output = mutableListOf<DuplicateFile>()

        contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { cursor ->

            val idColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.MediaColumns._ID
                )

            val nameColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.MediaColumns.DISPLAY_NAME
                )

            val sizeColumn =
                cursor.getColumnIndexOrThrow(
                    MediaStore.MediaColumns.SIZE
                )

            while (cursor.moveToNext()) {

                val id =
                    cursor.getLong(idColumn)

                val name =
                    cursor.getString(nameColumn)
                        ?: "File"

                val size =
                    cursor.getLong(sizeColumn)

                val uri =
                    ContentUris.withAppendedId(
                        collection,
                        id
                    )

                output += DuplicateFile(
                    uri = uri,
                    name = name,
                    size = size,
                    kind = kind,
                )
            }
        }

        return output
    }

    // ---------------------------------------------------------
    // SHA-256
    // ---------------------------------------------------------

    private fun sha256(uri: Uri): String? {

        return try {

            val digest =
                MessageDigest.getInstance("SHA-256")

            contentResolver
                .openInputStream(uri)
                .use { input ->

                    if (input == null) {
                        return null
                    }

                    val buffer =
                        ByteArray(8192)

                    var read: Int

                    while (
                        input.read(buffer).also {
                            read = it
                        } > 0
                    ) {

                        digest.update(
                            buffer,
                            0,
                            read
                        )
                    }
                }

            digest.digest()
                .joinToString("") {
                    "%02x".format(it)
                }

        } catch (_: Exception) {

            null
        }
    }

    // ---------------------------------------------------------
    // SHOW DUPLICATES
    // ---------------------------------------------------------

    private fun renderResults() {

        binding.scanningContainer.visibility =
            View.GONE

        binding.resultsContainer.visibility =
            View.VISIBLE

        binding.checkSelectAll.visibility =
            View.VISIBLE

        binding.tvSelectedCount.visibility =
            View.VISIBLE

        binding.btnCleanNow.visibility =
            View.VISIBLE

        binding.tvSelectedCount.text =
            "${selected.size} Selected"

        /*
         * Display duplicate groups by hash.
         */
        adapter.submit(duplicateGroups, selected)

        updateSelectAllState()
    }

    // ---------------------------------------------------------
    // SELECTION
    // ---------------------------------------------------------

    private fun refreshSelectionVisuals() {

        renderResults()
    }

    private fun updateSelectAllState() {

        ignoreSelectAllCallback = true

        binding.checkSelectAll.isChecked =
            files.isNotEmpty() &&
                    selected.size == files.size

        ignoreSelectAllCallback = false

        binding.tvSelectedCount.text =
            "${selected.size} Selected"
    }

    // ---------------------------------------------------------
    // DELETE
    // ---------------------------------------------------------

    private fun deleteSelected() {

        if (selected.isEmpty()) {

            Toast.makeText(
                this,
                "Select duplicate files first",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val uris =
            selected.toList()

        if (Build.VERSION.SDK_INT >= 30) {

            val request =
                MediaStore.createDeleteRequest(
                    contentResolver,
                    uris
                )

            deleteLauncher.launch(
                IntentSenderRequest
                    .Builder(
                        request.intentSender
                    )
                    .build()
            )

        } else {

            try {

                uris.forEach { uri ->

                    contentResolver.delete(
                        uri,
                        null,
                        null
                    )
                }

                files.removeAll {
                    selected.contains(it.uri)
                }

                allFiles.removeAll {
                    selected.contains(it.uri)
                }

                duplicateGroups.removeAll { group ->
                    group.all { selected.contains(it.uri) }
                }

                duplicateGroups.replaceAll { group ->
                    group.filterNot { selected.contains(it.uri) }
                }

                duplicateGroups.removeAll { it.size < 2 }

                selected.clear()

                if (duplicateGroups.isEmpty()) {

                    showEmpty(
                        "No Duplicate ${labelForKind()}s Found"
                    )

                } else {

                    renderResults()
                }

            } catch (
                _: RecoverableSecurityException
            ) {

                Toast.makeText(
                    this,
                    "Android requires deletion permission",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // ---------------------------------------------------------
    // EMPTY STATE
    // ---------------------------------------------------------

    private fun showEmpty(
        message: String
    ) {

        binding.scanningContainer.visibility =
            View.VISIBLE

        binding.resultsContainer.visibility =
            View.GONE

        binding.ivScanArtwork.setImageResource(
            artworkForKind()
        )

        binding.tvScanPercent.text =
            ""

        binding.tvScanMessage.text =
            message
    }

    // ---------------------------------------------------------
    // LABELS
    // ---------------------------------------------------------

    private fun labelForKind() =
        when (kind) {

            DuplicateFile.Kind.PHOTO ->
                "Photo"

            DuplicateFile.Kind.VIDEO ->
                "Video"

            DuplicateFile.Kind.AUDIO ->
                "Audio"

            DuplicateFile.Kind.DOCUMENT ->
                "Document"
        }

    private fun titleForKind() =
        "Duplicate ${labelForKind()}s"

    private fun artworkForKind() =
        when (kind) {

            DuplicateFile.Kind.PHOTO ->
                R.drawable.dup_img

            DuplicateFile.Kind.VIDEO ->
                R.drawable.dup_vid

            DuplicateFile.Kind.AUDIO ->
                R.drawable.dup_aud

            DuplicateFile.Kind.DOCUMENT ->
                R.drawable.dup_docs
        }
}
