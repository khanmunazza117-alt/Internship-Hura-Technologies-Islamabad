package com.mastercoding.phonecleaner

import android.net.Uri


data class DuplicateFile(
    val uri: Uri,
    val name: String,
    val size: Long,
    val kind: Kind,
    var selected: Boolean = false
) {
    enum class Kind {
        PHOTO,
        VIDEO,
        AUDIO,
        DOCUMENT
    }
}
