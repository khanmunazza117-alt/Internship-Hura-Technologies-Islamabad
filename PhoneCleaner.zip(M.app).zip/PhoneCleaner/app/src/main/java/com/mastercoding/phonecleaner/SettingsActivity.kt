package com.mastercoding.phonecleaner

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFFFF8F6.toInt()) }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.WHITE) }
        header.addView(ImageButton(this).apply { setImageResource(R.drawable.ic_back); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { finish() } }, LinearLayout.LayoutParams(dp(48), dp(56)))
        header.addView(TextView(this).apply { text = "Setting"; gravity = Gravity.CENTER; textSize = 16f; setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, dp(56), 1f))
        header.addView(android.view.View(this), LinearLayout.LayoutParams(dp(48), dp(56)))
        root.addView(header)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), 0) }
        root.addView(body)
        row(body, "Premium Plan", R.drawable.daimond_crown) { startActivity(Intent(this, PaywallActivity::class.java)) }
        row(body, "Languages", R.drawable.ic_language) { startActivity(Intent(this, LanguageActivity::class.java)) }
        row(body, "Privacy Policy", R.drawable.ic_privacy) { startActivity(Intent(this, PrivacyPolicyActivity::class.java)) }
        row(body, "Share", R.drawable.ic_share) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Try Phone Cleaner") }, "Share app"))
        }
        row(body, "Rate Us", R.drawable.ic_rate) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        }
        row(body, "Replay First-time Screens", R.drawable.ic_language) {
            getSharedPreferences(SplashActivity.PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(SplashActivity.KEY_SETUP_COMPLETE)
                .remove(SplashActivity.KEY_LANGUAGE_SELECTED)
                .apply()
            startActivity(
                Intent(
                    this,
                    SplashActivity::class.java
                ).addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
                )
            )
        }
        setContentView(root)
        window.enablePhoneCleanerEdgeToEdge(root)
    }
    private fun row(parent: LinearLayout, title: String, icon: Int, click: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = rounded(Color.WHITE, dp(12)); setPadding(dp(12), 0, dp(12), 0); setOnClickListener { click() } }
        row.addView(ImageView(this).apply { setImageResource(icon) }, LinearLayout.LayoutParams(dp(38), dp(52)))
        row.addView(TextView(this).apply { text = title; textSize = 12f; setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(8) })
        row.addView(TextView(this).apply { text = "›"; textSize = 24f }, LinearLayout.LayoutParams(dp(24), dp(52)))
        parent.addView(row, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}