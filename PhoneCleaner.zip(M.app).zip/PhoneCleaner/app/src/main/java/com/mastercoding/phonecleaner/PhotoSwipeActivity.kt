package com.mastercoding.phonecleaner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mastercoding.phonecleaner.databinding.ActivityPhotoSwipeBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class PhotoSwipeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhotoSwipeBinding
    private val executor = Executors.newSingleThreadExecutor()
    private val photos = mutableListOf<Uri>()
    private var position = 0

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) loadPhotos()
        else showEmpty("Photo permission is required")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoSwipeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.enablePhoneCleanerEdgeToEdge(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnCheckTrash.setOnClickListener {
            startActivity(Intent(this, TrashBinActivity::class.java))
        }

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(event: MotionEvent): Boolean = true

            override fun onFling(
                first: MotionEvent?,
                last: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (first == null || photos.isEmpty()) return false
                val distanceX = last.x - first.x
                val distanceY = last.y - first.y

                if (abs(distanceX) > dp(80) && abs(distanceX) > abs(distanceY)) {
                    if (distanceX < 0) {
                        TrashStore.add(this@PhotoSwipeActivity, photos[position])
                    }
                    position++
                    showPhoto()
                    return true
                }
                return false
            }
        })

        binding.ivPhoto.setOnTouchListener { _, event ->
            detector.onTouchEvent(event)
            true
        }

        loadTrashCount()
        requestPhotoPermission()
    }

    private fun requestPhotoPermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadPhotos()
        } else {
            permissionLauncher.launch(permission)
        }
    }

    private fun loadPhotos() {
        executor.execute {
            val result = mutableListOf<Uri>()
            val projection = arrayOf(MediaStore.Images.Media._ID)

            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Images.Media.DATE_TAKEN} DESC"
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (cursor.moveToNext()) {
                    result += Uri.withAppendedPath(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        cursor.getLong(idColumn).toString()
                    )
                }
            }

            runOnUiThread {
                photos.clear()
                photos.addAll(result)
                position = 0
                showPhoto()
            }
        }
    }

    private fun showPhoto() {
        loadTrashCount()

        if (position >= photos.size) {
            showEmpty("No Photos Found")
            return
        }

        binding.empty.visibility = View.GONE
        binding.ivPhoto.visibility = View.VISIBLE
        binding.ivPhoto.setImageURI(photos[position])
        binding.tvPhotoCounter.text = "${position + 1}/${photos.size}"
        binding.tvMonth.text = SimpleDateFormat(
            "MMMM yyyy",
            Locale.getDefault()
        ).format(Date())
    }

    private fun showEmpty(message: String) {
        binding.ivPhoto.visibility = View.GONE
        binding.empty.visibility = View.VISIBLE
        binding.tvEmptyPhoto.text = message
    }

    private fun loadTrashCount() {
        val count = TrashStore.get(this).size
        binding.tvTrashCount.text = "$count Photos in the\nTrash Bin"
    }

    private fun dp(value: Int): Float =
        value * resources.displayMetrics.density

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
