package com.mastercoding.phonecleaner

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mastercoding.phonecleaner.databinding.ActivityLanguageSelectionBinding
import java.util.Locale

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_splash_screen)

        window.decorView.postDelayed({
            routeFromSplash()
        }, 900L)
    }

    private fun routeFromSplash() {

        val preferences = getSharedPreferences(
            PREFS_NAME,
            MODE_PRIVATE
        )

        /*
         * FIRST CHECK:
         * If the first-time setup has already been completed,
         * ALWAYS open MainActivity.
         *
         * This is what makes the second and later launches go
         * directly from Splash -> Main.
         */
        if (preferences.getBoolean(KEY_SETUP_COMPLETE, false)) {

            startActivity(
                Intent(
                    this,
                    MainActivity::class.java
                )
            )

            finish()
            return
        }

        /*
         * FIRST TIME:
         * Language has not been selected yet.
         */
        if (!preferences.getBoolean(KEY_LANGUAGE_SELECTED, false)) {

            startActivity(
                Intent(
                    this,
                    LanguageSelectionActivity::class.java
                )
            )

            finish()
            return
        }

        /*
         * Language was selected but setup is not complete yet,
         * so run the rest of the first-time flow:
         *
         *   Onboarding -> Paywall -> Terms -> Main
         */
        startActivity(
            Intent(
                this,
                OnboardingActivity::class.java
            )
        )

        finish()
    }

    companion object {

        const val PREFS_NAME = "phone_cleaner_preferences"

        const val KEY_LANGUAGE_SELECTED = "language_selected"

        const val KEY_SETUP_COMPLETE = "setup_complete"

        const val KEY_LANGUAGE = "selected_language"
    }
}


class LanguageSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLanguageSelectionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLanguageSelectionBinding.inflate(
            layoutInflater
        )

        setContentView(binding.root)

        /*
         * Get previously saved language.
         */
        val savedLanguage =
            getSharedPreferences(
                SplashActivity.PREFS_NAME,
                MODE_PRIVATE
            ).getString(
                SplashActivity.KEY_LANGUAGE,
                "en"
            ) ?: "en"

        checkForCode(savedLanguage)

        /*
         * Select Language button
         */
        binding.btnSelectLanguage.setOnClickListener {

            val code = selectedCode()

            /*
             * Save language selection.
             *
             * IMPORTANT:
             * We DO NOT set KEY_SETUP_COMPLETE here.
             *
             * Setup is completed only after the user finishes
             * the complete first-time flow.
             */
            getSharedPreferences(
                SplashActivity.PREFS_NAME,
                MODE_PRIVATE
            )
                .edit()
                .putBoolean(
                    SplashActivity.KEY_LANGUAGE_SELECTED,
                    true
                )
                .putString(
                    SplashActivity.KEY_LANGUAGE,
                    code
                )
                .apply()

            applyLocale(code)

            /*
             * Go to onboarding.
             */
            startActivity(
                Intent(
                    this,
                    OnboardingActivity::class.java
                )
            )

            finish()
        }
    }

    private fun selectedCode(): String {

        return when (
            binding.languageGroup.checkedRadioButtonId
        ) {

            R.id.radioEnglish -> "en"

            R.id.radioUrdu -> "ur"

            R.id.radioItalian -> "it"

            R.id.radioHindi -> "hi"

            R.id.radioGerman -> "de"

            R.id.radioPolish -> "pl"

            R.id.radioJapanese -> "ja"

            R.id.radioArabic -> "ar"

            R.id.radioThai -> "th"

            R.id.radioSpanish -> "es"

            else -> "en"
        }
    }

    private fun checkForCode(code: String) {

        val radioButtonId = when (code) {

            "en" -> R.id.radioEnglish

            "ur" -> R.id.radioUrdu

            "it" -> R.id.radioItalian

            "hi" -> R.id.radioHindi

            "de" -> R.id.radioGerman

            "pl" -> R.id.radioPolish

            "ja" -> R.id.radioJapanese

            "ar" -> R.id.radioArabic

            "th" -> R.id.radioThai

            "es" -> R.id.radioSpanish

            else -> R.id.radioEnglish
        }

        binding.languageGroup.check(radioButtonId)
    }

    private fun applyLocale(code: String) {

        val locale = Locale(code)

        Locale.setDefault(locale)

        val configuration = resources.configuration

        configuration.setLocale(locale)

        @Suppress("DEPRECATION")
        resources.updateConfiguration(
            configuration,
            resources.displayMetrics
        )
    }
}