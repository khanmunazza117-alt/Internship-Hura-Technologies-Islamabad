package com.mastercoding.phonecleaner

import android.net.Uri

data class LargeFileItem(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val isVideo: Boolean,
    var selected: Boolean = true
)