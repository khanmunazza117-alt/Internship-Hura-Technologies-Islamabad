package com.mastercoding.phonecleaner

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class LargeFilesAdapter(
    private val onSelectionChanged: (LargeFileItem) -> Unit
) : RecyclerView.Adapter<LargeFilesAdapter.FileViewHolder>() {

    private val items = mutableListOf<LargeFileItem>()

    fun submitList(newItems: List<LargeFileItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun getSelectedItems(): List<LargeFileItem> {
        return items.filter { it.selected }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_large_file, parent, false)
        return FileViewHolder(view)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class FileViewHolder(
        private val itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        private val thumbnail: ImageView =
            itemView.findViewById(R.id.ivFileThumbnail)

        private val name: TextView =
            itemView.findViewById(R.id.tvFileName)

        private val size: TextView =
            itemView.findViewById(R.id.tvFileSize)

        private val check: ImageView =
            itemView.findViewById(R.id.ivFileCheck)

//        private val typeOverlay: ImageView? =
//            itemView.findViewById(R.id.ivFileTypeOverlay)

        fun bind(item: LargeFileItem) {
            itemView.isSelected = item.selected

            name.text = item.name
            size.text = formatSize(item.sizeBytes)

            if (item.isVideo) {
                val bitmap: Bitmap? = try {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(itemView.context, item.uri)
                    val frame = retriever.getFrameAtTime(
                        0L,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                    )
                    retriever.release()
                    frame
                } catch (_: Exception) {
                    null
                }

                if (bitmap != null) {
                    thumbnail.setImageBitmap(bitmap)
                } else {
                    thumbnail.setImageResource(R.drawable.ic_videos)
                }
            } else {
                thumbnail.setImageResource(R.drawable.ic_documents)
            }

//            typeOverlay?.setImageResource(
//                if (item.isVideo) R.drawable.ic_videos
//                else R.drawable.ic_documents
//            )

            check.setImageResource(
                if (item.selected) R.drawable.ic_circle_check
                else R.drawable.ic_radio_unchecked
            )

            itemView.setOnClickListener {
                item.selected = !item.selected
                itemView.isSelected = item.selected

                check.setImageResource(
                    if (item.selected) R.drawable.ic_circle_check
                    else R.drawable.ic_radio_unchecked
                )

                onSelectionChanged(item)
            }

            check.setOnClickListener {
                itemView.performClick()
            }
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 1024L * 1024L) {
            return "${bytes / 1024L} KB"
        }
        return "${bytes / (1024L * 1024L)} MB"
    }
}
