package com.mastercoding.phonecleaner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mastercoding.phonecleaner.databinding.ActivityStorageStatsBinding
import java.util.Locale
import java.util.concurrent.Executors

class StorageStatsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStorageStatsBinding
    private val executor = Executors.newSingleThreadExecutor()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        loadStats()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityStorageStatsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.enablePhoneCleanerEdgeToEdge(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        requestStoragePermissions()
    }

    private fun requestStoragePermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        if (permissions.all { hasPermission(it) }) loadStats()
        else permissionLauncher.launch(permissions)
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun loadStats() {
        executor.execute {
            val statFs = StatFs(Environment.getDataDirectory().path)
            val totalBytes = statFs.totalBytes
            val availableBytes = statFs.availableBytes
            val usedBytes = totalBytes - availableBytes
            val percent = if (totalBytes == 0L) 0 else {
                ((usedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100)
            }
            val categories = queryCategories()

            runOnUiThread {
                binding.storageRing.percentage = percent
                binding.tvTotalSpace.text = formatStorage(totalBytes)
                binding.tvAvailableSpace.text = formatStorage(availableBytes)
                binding.breakdownContainer.removeAllViews()
                categories.forEach { addBreakdownRow(it) }
            }
        }
    }

    private fun queryCategories(): List<Category> {
        val photos = querySize(MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        val videos = querySize(MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        val audios = querySize(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
        val documents = querySize(
            MediaStore.Files.getContentUri("external"),
            "${MediaStore.Files.FileColumns.MIME_TYPE} LIKE 'application/%'"
        )

        return listOf(
            Category("Photos", photos, R.drawable.ic_photo2),
            Category("Videos", videos, R.drawable.videos_ic),
            Category("Audios", audios, R.drawable.audio_ic),
            Category("Documents", documents, R.drawable.documents_ic),
            Category("Apps", 0L, R.drawable.apps_ic)
        )
    }

    private fun querySize(
        uri: android.net.Uri,
        selection: String? = null
    ): Long {
        var total = 0L
        contentResolver.query(
            uri,
            arrayOf(MediaStore.MediaColumns.SIZE),
            selection,
            null,
            null
        )?.use { cursor ->
            val sizeColumn = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
            if (sizeColumn >= 0) {
                while (cursor.moveToNext()) {
                    if (!cursor.isNull(sizeColumn)) total += cursor.getLong(sizeColumn)
                }
            }
        }
        return total
    }

    private fun addBreakdownRow(category: Category) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(0xFFFFFFFF.toInt(), dp(12))
            setPadding(dp(12), 0, dp(12), 0)
        }

        val icon = ImageView(this).apply {
            setImageResource(category.icon)
            background = rounded(0xFFFFF9F1.toInt(), dp(24))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(34), dp(34)))

        val title = TextView(this).apply {
            text = category.name
            textSize = 12f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(0xFF222222.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        row.addView(title, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
            marginStart = dp(10)
        })

        val amount = TextView(this).apply {
            text = formatStorage(category.bytes)
            textSize = 12f
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setTextColor(0xFF222222.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        row.addView(amount, LinearLayout.LayoutParams(dp(78), dp(54)))

        binding.breakdownContainer.addView(
            row,
            LinearLayout.LayoutParams(-1, dp(54)).apply {
                bottomMargin = dp(8)
            }
        )
    }

    private fun formatStorage(bytes: Long): String {
        return if (bytes >= 1024L * 1024L * 1024L) {
            String.format(Locale.getDefault(), "%.1f GB", bytes / 1073741824.0)
        } else {
            String.format(Locale.getDefault(), "%.1f MB", bytes / 1048576.0)
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private data class Category(
        val name: String,
        val bytes: Long,
        val icon: Int
    )
}
