package com.mastercoding.phonecleaner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Lazy adapter that renders duplicate groups (or file preview groups) inside a
 * RecyclerView. View creation is virtualized, so only the groups currently on
 * screen are inflated, which prevents the main thread from being blocked when a
 * device has a large media library.
 */
class DuplicateGroupAdapter(
    private val context: Context,
    private val onToggle: (Uri, Boolean) -> Unit
) : RecyclerView.Adapter<DuplicateGroupAdapter.GroupVH>() {

    private val thumbnailLoader = ThumbnailLoader(context)
    private val density = context.resources.displayMetrics.density

    private val groups = mutableListOf<List<DuplicateFile>>()
    private var selected: Set<Uri> = emptySet()

    fun submit(
        newGroups: List<List<DuplicateFile>>,
        newSelected: Set<Uri>
    ) {
        selected = newSelected
        groups.clear()
        groups.addAll(newGroups)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = groups.size

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): GroupVH {
        val inflater = LayoutInflater.from(parent.context)
        return GroupVH(
            inflater.inflate(
                R.layout.item_duplicate_group,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(
        holder: GroupVH,
        position: Int
    ) {
        holder.bind(groups[position], position)
    }

    inner class GroupVH(
        itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        private val tvHeading: TextView =
            itemView.findViewById(R.id.tvHeading)

        val gridGroup: GridLayout =
            itemView.findViewById(R.id.gridGroup)

        fun bind(
            groupFiles: List<DuplicateFile>,
            index: Int
        ) {
            tvHeading.text =
                "Group ${String.format("%02d", index + 1)}"

            gridGroup.removeAllViews()

            groupFiles.forEach { file ->
                val params =
                    GridLayout.LayoutParams().apply {
                        width = 0
                        height = dp(86)

                        columnSpec =
                            GridLayout.spec(
                                GridLayout.UNDEFINED,
                                1f
                            )

                        setMargins(
                            dp(3),
                            dp(3),
                            dp(3),
                            dp(3)
                        )
                    }

                gridGroup.addView(
                    cell(file),
                    params
                )
            }
            itemView.layoutParams =
                itemView.layoutParams.apply {
                    height =
                        ViewGroup.LayoutParams.WRAP_CONTENT
                }
        }

        private fun cell(file: DuplicateFile): View {
            val inflater = LayoutInflater.from(context)

            val cellView =
                inflater.inflate(
                    R.layout.item_duplicate_cell,
                    gridGroup,
                    false
                )

            val image: ImageView =
                cellView.findViewById(R.id.ivCell)

            val check: CheckBox =
                cellView.findViewById(R.id.cbCell)

            when (file.kind) {
                DuplicateFile.Kind.PHOTO ->
                    thumbnailLoader.load(file.uri, image)

                DuplicateFile.Kind.VIDEO ->
                    image.setImageResource(R.drawable.dup_vid)

                DuplicateFile.Kind.AUDIO ->
                    image.setImageResource(R.drawable.dup_aud)

                DuplicateFile.Kind.DOCUMENT ->
                    image.setImageResource(R.drawable.dup_docs)
            }

            check.isChecked = selected.contains(file.uri)
            check.setOnCheckedChangeListener { _, checked ->
                onToggle(file.uri, checked)
            }

            cellView.setOnClickListener {
                check.isChecked = !check.isChecked
            }

            return cellView
        }
    }

    override fun onViewRecycled(holder: GroupVH) {
        super.onViewRecycled(holder)
        holder.gridGroup.removeAllViews()
    }

    private fun dp(value: Int): Int =
        (value * density).toInt()
}

/**
 * Minimal async thumbnail loader. Decodes images off the main thread and caches
 * the decoded bitmaps, avoiding the main-thread ANR caused by the previous
 * synchronous ImageView.setImageURI() calls.
 */
class ThumbnailLoader(
    private val context: Context
) {

    private val executor: ExecutorService =
        Executors.newFixedThreadPool(2)

    private val cache =
        LruCache<String, Bitmap>(
            (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()
        )

    fun load(uri: Uri, imageView: ImageView) {
        val key = uri.toString()

        val cached = cache.get(key)
        if (cached != null) {
            imageView.setImageBitmap(cached)
            return
        }

        imageView.setTag(R.id.thumbnailLoaderTag, key)
        imageView.setImageResource(R.drawable.dup_img)

        executor.execute {
            val bitmap = decode(uri)
            if (bitmap == null) {
                return@execute
            }

            cache.put(key, bitmap)

            val current =
                imageView.getTag(R.id.thumbnailLoaderTag)

            // Only apply if this view is still showing the same uri.
            if (current == key) {
                imageView.post {
                    if (imageView.getTag(R.id.thumbnailLoaderTag) == key) {
                        imageView.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    private fun decode(uri: Uri): Bitmap? {
        return try {
            // First pass: read bounds only.
            val bounds =
                BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }

            context.contentResolver
                .openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(
                        stream,
                        null,
                        bounds
                    )
                }

            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                return null
            }

            var sampleSize = 1
            val maxDim = 256

            while (
                bounds.outWidth / sampleSize > maxDim ||
                bounds.outHeight / sampleSize > maxDim
            ) {
                sampleSize *= 2
            }

            val options =
                BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                }

            context.contentResolver
                .openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(
                        stream,
                        null,
                        options
                    )
                }
        } catch (_: Exception) {
            null
        }
    }
}
