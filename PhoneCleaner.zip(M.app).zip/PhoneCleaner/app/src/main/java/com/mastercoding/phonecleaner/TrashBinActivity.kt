package com.mastercoding.phonecleaner

import android.app.RecoverableSecurityException
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.mastercoding.phonecleaner.databinding.ActivityTrashBinBinding

class TrashBinActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTrashBinBinding
    private val trashUris = mutableListOf<Uri>()

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            TrashStore.removeAll(this)
            render()
            Toast.makeText(this, "Trash Bin cleared", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityTrashBinBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.enablePhoneCleanerEdgeToEdge(binding.root)


        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnClearTrash.setOnClickListener {
            clearTrash()
        }

        binding.btnRecoverAll.setOnClickListener {
            TrashStore.removeAll(this)
            render()
            Toast.makeText(this, "Photos recovered", Toast.LENGTH_SHORT).show()
        }

        render()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            render()
        }
    }

    private fun render() {
        trashUris.clear()
        trashUris.addAll(
            TrashStore.get(this).filter { uriExists(it) }
        )

        val totalBytes = trashUris.sumOf { getSize(it) }

        binding.tvTrashSummary.text = String.format(
            "%02d Photos",
            trashUris.size
        )
        binding.tvTrashSize.text = formatSize(totalBytes)
        binding.gridTrashPhotos.adapter = TrashGridAdapter()
    }

    private fun clearTrash() {
        if (trashUris.isEmpty()) {
            Toast.makeText(this, "Trash Bin is empty", Toast.LENGTH_SHORT).show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val request = MediaStore.createDeleteRequest(
                contentResolver,
                trashUris
            )

            deleteLauncher.launch(
                IntentSenderRequest.Builder(request.intentSender).build()
            )
        } else {
            try {
                trashUris.forEach { uri ->
                    contentResolver.delete(uri, null, null)
                }

                TrashStore.removeAll(this)
                render()
                Toast.makeText(this, "Trash Bin cleared", Toast.LENGTH_SHORT).show()
            } catch (_: RecoverableSecurityException) {
                Toast.makeText(
                    this,
                    "Permission is required to delete these photos",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun uriExists(uri: Uri): Boolean {
        return try {
            contentResolver.openAssetFileDescriptor(uri, "r")?.use {
                true
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun getSize(uri: Uri): Long {
        return try {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (index >= 0 && !cursor.isNull(index)) {
                        cursor.getLong(index)
                    } else {
                        0L
                    }
                } else {
                    0L
                }
            } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    private inner class TrashGridAdapter : BaseAdapter() {

        override fun getCount(): Int = trashUris.size

        override fun getItem(position: Int): Uri = trashUris[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(
            position: Int,
            recycled: View?,
            parent: ViewGroup
        ): View {
            val image = (recycled as? ImageView)
                ?: ImageView(this@TrashBinActivity).apply {
                    layoutParams = AbsListView.LayoutParams(
                        dp(84),
                        dp(90)
                    )
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = rounded(Color.WHITE, dp(10))
                    setPadding(dp(2), dp(2), dp(2), dp(2))
                }

            image.setImageURI(trashUris[position])
            return image
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 1024L * 1024L) {
            return "${bytes / 1024L} KB"
        }

        return String.format(
            "%.1f MB",
            bytes / (1024.0 * 1024.0)
        )
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun rounded(color: Int, radius: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }
}
