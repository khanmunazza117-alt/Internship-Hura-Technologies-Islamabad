package com.mastercoding.phonecleaner

import android.content.Context
import android.net.Uri

object TrashStore {
    private const val PREFS = "phone_cleaner_trash"
    private const val KEY_URIS = "photo_uris"

    fun get(context: Context): MutableList<Uri> {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_URIS, emptySet())
            .orEmpty()
            .map { Uri.parse(it) }
            .toMutableList()
    }

    fun add(context: Context, uri: Uri) {
        val values = get(context).map { it.toString() }.toMutableSet()
        values.add(uri.toString())
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_URIS, values).apply()
    }

    fun removeAll(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY_URIS).apply()
    }
}