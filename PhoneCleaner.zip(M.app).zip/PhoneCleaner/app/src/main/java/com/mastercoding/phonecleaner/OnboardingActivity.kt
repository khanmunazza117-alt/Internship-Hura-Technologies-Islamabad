package com.mastercoding.phonecleaner

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.mastercoding.phonecleaner.databinding.ActivityOnboardingBinding

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding
    private lateinit var onboardingList: List<OnboardingItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityOnboardingBinding.inflate(layoutInflater)

        setContentView(binding.root)

        window.enablePhoneCleanerEdgeToEdge(binding.root)

        setupItems()
        setupViewPager()

        binding.btnAction.setOnClickListener {
            val current = binding.viewPager.currentItem

            if (current < onboardingList.size - 1) {
                binding.viewPager.currentItem = current + 1
            } else {
                val intent = Intent(
                    this,
                    PaywallActivity::class.java
                )

                startActivity(intent)
                finish()
            }
        }
    }

    private fun setupItems() {
        onboardingList = listOf(
            OnboardingItem(
                R.drawable.img_onboarding_1,
                "Phone Cleaner",
                "Clean your phone effortlessly by removing\nscreenshots, duplicates, and large\nunwanted files",
                "Continue"
            ),
            OnboardingItem(
                R.drawable.img_onboarding_2,
                "Storage Stats",
                "Check your phone's storage usage and see\nexactly how much space is available",
                "Continue"
            ),
            OnboardingItem(
                R.drawable.img_onboarding_3,
                "Photo Swipe",
                "Quickly review your photos and swipe left to\ndelete unwanted ones or right to keep them",
                "Let's Start"
            )
        )
    }

    private fun setupViewPager() {
        binding.viewPager.adapter = OnboardingAdapter(onboardingList)

        // Setup indicators for total pages
        setupIndicators(onboardingList.size, 0)

        if (onboardingList.isNotEmpty()) {
            binding.btnAction.text = onboardingList[0].buttonText
        }

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                if (position in onboardingList.indices) {
                    binding.btnAction.text = onboardingList[position].buttonText
                    setupIndicators(onboardingList.size, position)
                }
            }
        })
    }

    private fun setupIndicators(count: Int, activePosition: Int) {
        binding.layoutIndicators.removeAllViews()

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(8, 0, 8, 0)
        }

        for (i in 0 until count) {
            val imageView = ImageView(this).apply {
                layoutParams = params
                if (i == activePosition) {
                    setImageResource(R.drawable.ic_indicator_active)
                } else {
                    setImageResource(R.drawable.ic_indicator_inactive)
                }
            }
            binding.layoutIndicators.addView(imageView)
        }
    }
}