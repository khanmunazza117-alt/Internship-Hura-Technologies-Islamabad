package com.mastercoding.phonecleaner

import android.graphics.Color
import android.os.Build
import android.view.View
import android.view.Window
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

/**
 * Enables edge-to-edge content while preserving the root view's
 * original XML padding.
 */
fun Window.enablePhoneCleanerEdgeToEdge(root: View) {
    WindowCompat.setDecorFitsSystemWindows(this, false)

    statusBarColor = Color.TRANSPARENT
    navigationBarColor = Color.TRANSPARENT

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        isStatusBarContrastEnforced = false
        isNavigationBarContrastEnforced = false
    }

    WindowCompat.getInsetsController(this, root).apply {
        isAppearanceLightStatusBars = true
        isAppearanceLightNavigationBars = true
    }

    // Capture XML padding once. This prevents padding from accumulating
    // every time Android dispatches window insets.
    val initialLeft = root.paddingLeft
    val initialTop = root.paddingTop
    val initialRight = root.paddingRight
    val initialBottom = root.paddingBottom

    ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
        val bars = insets.getInsets(
            WindowInsetsCompat.Type.statusBars() or
                    WindowInsetsCompat.Type.navigationBars() or
                    WindowInsetsCompat.Type.displayCutout()
        )

        view.updatePadding(
            left = initialLeft + bars.left,
            top = initialTop + bars.top,
            right = initialRight + bars.right,
            bottom = initialBottom + bars.bottom
        )

        insets
    }

    ViewCompat.requestApplyInsets(root)
}
