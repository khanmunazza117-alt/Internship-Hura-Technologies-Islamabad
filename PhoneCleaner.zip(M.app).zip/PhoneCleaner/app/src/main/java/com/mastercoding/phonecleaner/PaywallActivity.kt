package com.mastercoding.phonecleaner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mastercoding.phonecleaner.databinding.ActivityPaywallBinding

class PaywallActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPaywallBinding

    private var selectedOption = 1 // Default: 6 Months

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPaywallBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.enablePhoneCleanerEdgeToEdge(binding.mainRoot)

        setupClickListeners()
        updateSelectionUI()
    }

    private fun setupClickListeners() {

        // Close button
        binding.btnClose.setOnClickListener {
            navigateToTermsActivity()
        }

        // Subscribe button
        binding.btnSubscribe.setOnClickListener {
            navigateToTermsActivity()
        }

        // Monthly
        binding.cardMonthly.setOnClickListener {
            selectedOption = 0
            updateSelectionUI()
        }

        // 6 Months
        binding.cardSixMonths.setOnClickListener {
            selectedOption = 1
            updateSelectionUI()
        }

        // Yearly
        binding.cardYearly.setOnClickListener {
            selectedOption = 2
            updateSelectionUI()
        }

        // Terms of Use
        binding.tvTerms.setOnClickListener {
            openWebUrl("https://yourdomain.com/terms")
        }

        // Privacy Policy
        binding.tvPrivacy.setOnClickListener {
            openWebUrl("https://yourdomain.com/privacy")
        }
    }

    private fun navigateToTermsActivity() {

        startActivity(
            Intent(
                this,
                TermsActivity::class.java
            )
        )

        finish()
    }

    private fun openWebUrl(url: String) {

        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse(url)
        )

        startActivity(intent)
    }

    private fun updateSelectionUI() {

        binding.radioMonthly.setImageResource(
            if (selectedOption == 0)
                R.drawable.ic_radio_checked
            else
                R.drawable.ic_radio_unchecked
        )

        binding.radioSixMonths.setImageResource(
            if (selectedOption == 1)
                R.drawable.ic_radio_checked
            else
                R.drawable.ic_radio_unchecked
        )

        binding.radioYearly.setImageResource(
            if (selectedOption == 2)
                R.drawable.ic_radio_checked
            else
                R.drawable.ic_radio_unchecked
        )
    }
}