package com.mastercoding.phonecleaner


data class OnboardingItem(
    val imageRes: Int,
    val title: String,
    val description: String,
    val buttonText: String
)
