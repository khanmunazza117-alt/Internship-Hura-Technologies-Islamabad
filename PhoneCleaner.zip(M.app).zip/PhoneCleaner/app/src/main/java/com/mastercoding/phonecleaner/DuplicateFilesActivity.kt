package com.mastercoding.phonecleaner

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DuplicateFilesActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFF8F6.toInt())
        }
        setContentView(root)
        window.enablePhoneCleanerEdgeToEdge(root)
        renderHome()
    }

    private fun renderHome() {
        root.removeAllViews()
        root.addView(header("Duplicate Files"))
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(20))
        }
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        categoryCard(body, "Photos", R.drawable.ic_photo2, DuplicateFile.Kind.PHOTO)
        categoryCard(body, "Videos", R.drawable.videos_ic, DuplicateFile.Kind.VIDEO)
        categoryCard(body, "Audios", R.drawable.audio_ic, DuplicateFile.Kind.AUDIO)
        categoryCard(body, "Documents", R.drawable.documents_ic, DuplicateFile.Kind.DOCUMENT)
    }

    private fun categoryCard(
        parent: LinearLayout,
        title: String,
        icon: Int,
        kind: DuplicateFile.Kind
    ) {
        val card = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.WHITE, dp(12))
            setPadding(dp(12), 0, dp(10), 0)
            setOnClickListener {
                startActivity(android.content.Intent(this@DuplicateFilesActivity,
                    DuplicateCategoryActivity::class.java).putExtra("kind", kind.name))
            }
        }
        val image = ImageView(this).apply {
            setImageResource(icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        card.addView(image, LinearLayout.LayoutParams(dp(36), dp(52)))
        card.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(0xFF222222.toInt())
            setTypeface(null, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(8) })
        card.addView(TextView(this).apply {
            text = "›"
            textSize = 25f
            setTextColor(0xFF222222.toInt())
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(25), dp(52)))
        parent.addView(card, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
    }

    private fun header(title: String): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(Color.WHITE)
        addView(ImageButton(this@DuplicateFilesActivity).apply {
            setImageResource(R.drawable.ic_back)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(56)))
        addView(TextView(this@DuplicateFilesActivity).apply {
            text = title
            gravity = Gravity.CENTER
            textSize = 16f
            setTextColor(0xFF17201E.toInt())
            setTypeface(null, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, dp(56), 1f))
        addView(View(this@DuplicateFilesActivity), LinearLayout.LayoutParams(dp(48), dp(56)))
    }

    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}