package com.mastercoding.phonecleaner

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mastercoding.phonecleaner.databinding.ActivityScreenshotCleanupBinding

class ScreenshotCleanupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScreenshotCleanupBinding
    private val screenshots = mutableListOf<Uri>()
    private val selected = linkedSetOf<Uri>()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scanScreenshots()
        else showEmpty("Photo permission is required")
    }

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            screenshots.removeAll(selected)
            selected.clear()
            showComplete()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScreenshotCleanupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.enablePhoneCleanerEdgeToEdge(binding.root)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnCleanScreenshots.setOnClickListener { deleteSelected() }
        binding.checkSelectAll.setOnCheckedChangeListener { _, checked ->
            if (checked) selected.addAll(screenshots) else selected.clear()
            updateResults()
        }
        requestPermission()
    }

    private fun requestPermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            scanScreenshots()
        } else permissionLauncher.launch(permission)
    }

    private fun scanScreenshots() {
        binding.scanningContainer.visibility = View.VISIBLE
        binding.resultsContainer.visibility = View.GONE
        binding.completeContainer.visibility = View.GONE
        Thread {
            val found = mutableListOf<Uri>()
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.RELATIVE_PATH
            )
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val pathColumn = cursor.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH)
                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameColumn) ?: ""
                    val path = if (pathColumn >= 0) cursor.getString(pathColumn) ?: "" else ""
                    if (name.contains("screenshot", true) || path.contains("screenshot", true)) {
                        found += Uri.withAppendedPath(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            cursor.getLong(idColumn).toString()
                        )
                    }
                }
            }
            runOnUiThread {
                screenshots.clear(); screenshots.addAll(found)
                selected.retainAll(found.toSet())
                if (found.isEmpty()) showEmpty("No Screenshots Found") else updateResults()
            }
        }.start()
    }

    private fun updateResults() {
        binding.scanningContainer.visibility = View.GONE
        binding.completeContainer.visibility = View.GONE
        binding.resultsContainer.visibility = View.VISIBLE
        binding.tvSelectedCount.text = "${selected.size} Selected"
        binding.checkSelectAll.setOnCheckedChangeListener(null)
        binding.checkSelectAll.isChecked = screenshots.isNotEmpty() && selected.size == screenshots.size
        binding.checkSelectAll.setOnCheckedChangeListener { _, checked ->
            if (checked) selected.addAll(screenshots) else selected.clear()
            updateResults()
        }
        binding.gridScreenshots.adapter = ScreenshotAdapter()
    }

    private inner class ScreenshotAdapter : BaseAdapter() {
        override fun getCount(): Int = screenshots.size
        override fun getItem(position: Int): Uri = screenshots[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, recycled: View?, parent: android.view.ViewGroup): View {
            val cell = (recycled as? ViewGroupCell) ?: ViewGroupCell()
            cell.bind(screenshots[position])
            return cell
        }
    }

    private inner class ViewGroupCell : androidx.appcompat.widget.LinearLayoutCompat(this) {
        private val image = ImageView(this@ScreenshotCleanupActivity)
        private val check = CheckBox(this@ScreenshotCleanupActivity)
        private var uri: Uri? = null

        init {
            orientation = VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
            addView(image, LayoutParams(-1, dp(72)))
            addView(check, LayoutParams(-1, dp(28)))
            image.scaleType = ImageView.ScaleType.CENTER_CROP
            check.text = ""
            check.gravity = android.view.Gravity.CENTER
            setOnClickListener { check.isChecked = !check.isChecked }
            check.setOnCheckedChangeListener { _, checked ->
                uri?.let { if (checked) selected.add(it) else selected.remove(it) }
                binding.tvSelectedCount.text = "${selected.size} Selected"
            }
        }

        fun bind(value: Uri) {
            uri = value
            image.setImageURI(value)
            check.isChecked = selected.contains(value)
        }
    }

    private fun deleteSelected() {
        if (selected.isEmpty()) {
            Toast.makeText(this, "Select screenshots first", Toast.LENGTH_SHORT).show()
            return
        }
        val uris = selected.toList()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val request = MediaStore.createDeleteRequest(contentResolver, uris)
            deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        } else {
            try {
                uris.forEach { contentResolver.delete(it, null, null) }
                screenshots.removeAll(uris.toSet()); selected.clear(); showComplete()
            } catch (_: RecoverableSecurityException) {
                Toast.makeText(this, "Permission is required to delete screenshots", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showEmpty(message: String) {
        binding.scanningContainer.visibility = View.GONE
        binding.resultsContainer.visibility = View.GONE
        binding.completeContainer.visibility = View.GONE
        binding.ivScanning.setImageResource(R.drawable.screenshot_cleanup)
        binding.tvScanPercent.text = ""
        binding.scanningContainer.findViewById<View>(R.id.tvScanPercent).visibility = View.GONE
        binding.scanningContainer.getChildAt(2).let { if (it is android.widget.TextView) it.text = message }
        binding.scanningContainer.visibility = View.VISIBLE
    }

    private fun showComplete() {
        binding.scanningContainer.visibility = View.GONE
        binding.resultsContainer.visibility = View.GONE
        binding.completeContainer.visibility = View.VISIBLE
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
