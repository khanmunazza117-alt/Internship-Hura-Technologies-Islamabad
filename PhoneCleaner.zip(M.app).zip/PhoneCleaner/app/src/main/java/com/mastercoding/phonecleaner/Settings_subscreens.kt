package com.mastercoding.phonecleaner

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PrivacyPolicyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = createPage()
        setContentView(root)
        window.enablePhoneCleanerEdgeToEdge(root)
    }

    private fun createPage(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFF8F6.toInt())
        }
        root.addView(header("Privacy Policy"), LinearLayout.LayoutParams(-1, dp(56)))
        val scroll = ScrollView(this)
        scroll.addView(TextView(this).apply {
            text = "Privacy Policy\n\nPhone Cleaner respects your privacy. Storage and usage access are used only to display device cleanup information and to perform actions that you explicitly confirm.\n\nYou can revoke permissions at any time from Android Settings."
            textSize = 14f
            setTextColor(0xFF222222.toInt())
            setPadding(dp(24), dp(30), dp(24), dp(24))
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun header(title: String) = TextView(this).apply {
        text = "‹    $title"
        textSize = 17f
        gravity = Gravity.CENTER_VERTICAL
        setTypeface(null, Typeface.BOLD)
        setTextColor(0xFF17201E.toInt())
        setPadding(dp(16), 0, 0, 0)
        setBackgroundColor(Color.WHITE)
        setOnClickListener { finish() }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

class LanguageActivity : AppCompatActivity() {
    private val languages = listOf("English", "Spanish", "French", "German", "Urdu")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFF8F6.toInt())
        }
        root.addView(header(), LinearLayout.LayoutParams(-1, dp(56)))
        val group = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val saved = getPreferences(0).getString("language", "English")
        languages.forEachIndexed { index, language ->
            group.addView(RadioButton(this).apply {
                id = 1000 + index
                text = language
                textSize = 13f
                setTextColor(0xFF222222.toInt())
                isChecked = language == saved
                setOnClickListener { getPreferences(0).edit().putString("language", language).apply() }
            }, RadioGroup.LayoutParams(-1, dp(52)))
        }
        root.addView(group, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(18), dp(16), 0) })
        setContentView(root)
        window.enablePhoneCleanerEdgeToEdge(root)
    }

    private fun header() = TextView(this).apply {
        text = "‹    Languages"
        textSize = 17f
        gravity = Gravity.CENTER_VERTICAL
        setTypeface(null, Typeface.BOLD)
        setTextColor(0xFF17201E.toInt())
        setPadding(dp(16), 0, 0, 0)
        setBackgroundColor(Color.WHITE)
        setOnClickListener { finish() }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
