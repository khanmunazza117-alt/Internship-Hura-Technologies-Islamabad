package com.mastercoding.phonecleaner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

class UsageRingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var valueText: String = "0h 0m"
        set(value) {
            field = value
            invalidate()
        }

    var percent: Int = 0
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }

    private val density = resources.displayMetrics.density
    private val stroke = 13f * density

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = stroke
        strokeCap = Paint.Cap.ROUND
    }

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = stroke
        strokeCap = Paint.Cap.ROUND
        color = 0xFFE6E6E6.toInt()
    }

    private val mainTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF111111.toInt()
        textAlign = Paint.Align.CENTER
        textSize = 19f * density
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private val usedTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF333333.toInt()
        textAlign = Paint.Align.CENTER
        textSize = 10f * density
    }

    private val bounds = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Use the smaller dimension for both width and height.
        // This prevents an oval when the parent gives the view extra width.
        val diameter = min(width, height).toFloat()
        val left = (width - diameter) / 2f
        val top = (height - diameter) / 2f
        val inset = stroke / 2f + 5f * density
        bounds.set(
            left + inset,
            top + inset,
            left + diameter - inset,
            top + diameter - inset
        )

        val centerX = width / 2f
        val centerY = height / 2f
        ringPaint.shader = SweepGradient(
            centerX,
            centerY,
            intArrayOf(0xFFFF4D73.toInt(), 0xFFFF8A45.toInt(), 0xFFFF4D73.toInt()),
            floatArrayOf(0f, 0.55f, 1f)
        )

        canvas.drawArc(bounds, -90f, 360f, false, trackPaint)
        canvas.drawArc(bounds, -90f, percent * 3.6f, false, ringPaint)

        val percentBaseline = centerY -
                (mainTextPaint.ascent() + mainTextPaint.descent()) / 2f - 3f * density
        canvas.drawText(valueText, centerX, percentBaseline, mainTextPaint)
        canvas.drawText("Used", centerX, percentBaseline + 19f * density, usedTextPaint)
    }
}
