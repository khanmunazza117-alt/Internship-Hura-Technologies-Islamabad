package com.mastercoding.phonecleaner

import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mastercoding.phonecleaner.databinding.ActivityScreenTimeBinding
import java.util.Calendar

class ScreenTimeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScreenTimeBinding

    // false = Today
    // true = Last 7 Days
    private var showingWeek = false

    private var permissionMessageShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityScreenTimeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.enablePhoneCleanerEdgeToEdge(binding.root)

        binding.btnBack.setOnClickListener {
            finish()
        }

        // Setup Today / Last 7 Days tabs
        setupPeriodTabs()

        binding.appUsageContainer.setOnClickListener {
            if (!hasUsageAccess()) {
                startActivity(
                    Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (::binding.isInitialized) {
            refresh()
        }
    }

    /**
     * Setup Today / Last 7 Days tabs.
     *
     * Today:
     * Active by default.
     *
     * Last 7 Days:
     * Becomes active when clicked.
     */
    private fun setupPeriodTabs() {

        binding.tvTodayTab.setOnClickListener {
            showTodayTab()
        }

        binding.tvWeekTab.setOnClickListener {
            showLastSevenDaysTab()
        }

        // Today is selected by default
        showTodayTab()
    }

    /**
     * Show Today tab as active.
     */
    private fun showTodayTab() {

        // Today = active
        binding.tvTodayTab.setBackgroundResource(
            R.drawable.bg_screen_time_segment_active
        )

        binding.tvTodayTab.setTextColor(Color.WHITE)

        // Last 7 Days = inactive / white
        binding.tvWeekTab.setBackgroundResource(
            R.drawable.bg_screen_time_segment_inactive
        )

        binding.tvWeekTab.setTextColor(
            Color.rgb(85, 85, 85)
        )

        showingWeek = false

        loadUsageForCurrentPeriod()
    }

    /**
     * Show Last 7 Days tab as active.
     */
    private fun showLastSevenDaysTab() {

        // Today = inactive / white
        binding.tvTodayTab.setBackgroundResource(
            R.drawable.bg_screen_time_segment_inactive
        )

        binding.tvTodayTab.setTextColor(
            Color.rgb(85, 85, 85)
        )

        // Last 7 Days = active
        binding.tvWeekTab.setBackgroundResource(
            R.drawable.bg_screen_time_segment_active
        )

        binding.tvWeekTab.setTextColor(Color.WHITE)

        showingWeek = true

        loadUsageForCurrentPeriod()
    }

    /**
     * Load usage according to currently selected tab.
     */
    private fun loadUsageForCurrentPeriod() {
        refresh()
    }

    /**
     * Refresh screen-time information.
     */
    private fun refresh() {

        /*
         * Keep tab UI synchronized with current selection.
         */
        updateTabs()

        /*
         * Check Usage Access permission.
         */
        if (!hasUsageAccess()) {

            binding.tvPeriodLabel.text =
                if (showingWeek) {
                    "Last 7 Days"
                } else {
                    "Total"
                }

            binding.tvTotalTime.text = "0h 0m"

            binding.screenTimeRing.valueText = "0h 0m"

            binding.screenTimeRing.percent = 0

            binding.appUsageContainer.removeAllViews()

            binding.appUsageContainer.addView(
                permissionRow()
            )

            if (!permissionMessageShown) {

                Toast.makeText(
                    this,
                    "Tap the Apps area to enable Usage Access",
                    Toast.LENGTH_LONG
                ).show()

                permissionMessageShown = true
            }

            return
        }

        /*
         * Determine usage range.
         *
         * Today = 1 day
         * Last 7 Days = 7 days
         */
        val range = usageRange(
            if (showingWeek) 7 else 1
        )

        val stats = queryUsage(
            range.first,
            range.second
        )
            .filter {
                it.totalTimeInForeground > 0L
            }
            .sortedByDescending {
                it.totalTimeInForeground
            }

        val total = stats.sumOf {
            it.totalTimeInForeground
        }

        /*
         * Maximum possible usage:
         *
         * Today = 24 hours
         * Last 7 Days = 7 x 24 hours
         */
        val maxRange =
            if (showingWeek) {
                7L * DAY
            } else {
                DAY
            }

        val percent =
            (
                    (total.toDouble() / maxRange.toDouble()) * 100.0
                    )
                .toInt()
                .coerceIn(0, 100)

        /*
         * Update period label.
         */
        binding.tvPeriodLabel.text =
            if (showingWeek) {
                "Last 7 Days"
            } else {
                "Total"
            }

        /*
         * Update total usage.
         */
        binding.tvTotalTime.text =
            formatDuration(total)

        binding.screenTimeRing.valueText =
            formatDuration(total)

        binding.screenTimeRing.percent =
            percent

        /*
         * Update application usage list.
         */
        binding.appUsageContainer.removeAllViews()

        val maxUsage =
            stats.maxOfOrNull {
                it.totalTimeInForeground
            } ?: 1L

        stats
            .take(8)
            .forEach { stat ->

                binding.appUsageContainer.addView(
                    appRow(
                        stat,
                        maxUsage
                    )
                )
            }
    }

    /**
     * Keeps tab UI synchronized with showingWeek.
     *
     * Active tab:
     * coral-to-orange gradient
     *
     * Inactive tab:
     * white background
     */
    private fun updateTabs() {

        if (!showingWeek) {

            // TODAY ACTIVE
            binding.tvTodayTab.setBackgroundResource(
                R.drawable.bg_screen_time_segment_active
            )

            binding.tvTodayTab.setTextColor(
                Color.WHITE
            )

            // LAST 7 DAYS INACTIVE



            binding.tvWeekTab.setTextColor(
                Color.rgb(85, 85, 85)
            )

        } else {

            // TODAY INACTIVE
            binding.tvTodayTab.setBackgroundResource(
                R.drawable.bg_screen_time_segment_inactive
            )

            binding.tvTodayTab.setTextColor(
                Color.rgb(85, 85, 85)
            )

            // LAST 7 DAYS ACTIVE
            binding.tvWeekTab.setBackgroundResource(
                R.drawable.bg_screen_time_segment_active
            )

            binding.tvWeekTab.setTextColor(
                Color.WHITE
            )
        }
    }

    /**
     * Permission message row.
     */
    private fun permissionRow(): View {

        return TextView(this).apply {

            text =
                "Usage Access is required\nTap here to open Settings"

            gravity = Gravity.CENTER

            textSize = 10f

            setTextColor(
                0xFF777777.toInt()
            )

            setTypeface(
                null,
                Typeface.BOLD
            )

            setPadding(
                0,
                dp(14),
                0,
                dp(14)
            )
        }
    }

    /**
     * Create individual application usage row.
     */
    private fun appRow(
        stat: UsageStats,
        maxUsage: Long
    ): View {

        val row = LinearLayout(this).apply {

            orientation =
                LinearLayout.HORIZONTAL

            gravity =
                Gravity.CENTER_VERTICAL

            setPadding(
                0,
                dp(5),
                0,
                dp(5)
            )
        }

        /*
         * App icon
         */
        val icon = ImageView(this).apply {

            try {

                setImageDrawable(
                    packageManager.getApplicationIcon(
                        stat.packageName
                    )
                )

            } catch (_: Exception) {

                setImageResource(
                    R.drawable.ic_instagram
                )
            }

            scaleType =
                ImageView.ScaleType.CENTER_INSIDE

            setPadding(
                dp(7),
                dp(7),
                dp(7),
                dp(7)
            )
        }

        row.addView(
            icon,
            LinearLayout.LayoutParams(
                dp(34),
                dp(34)
            )
        )

        /*
         * Middle section:
         * App name + progress bar
         */
        val middle =
            LinearLayout(this).apply {
                orientation =
                    LinearLayout.VERTICAL
            }

        /*
         * App name
         */
        val label = try {

            packageManager
                .getApplicationLabel(
                    packageManager.getApplicationInfo(
                        stat.packageName,
                        0
                    )
                )
                .toString()

        } catch (_: Exception) {

            stat.packageName
        }

        middle.addView(
            TextView(this).apply {

                text = label

                textSize = 10f

                setTextColor(
                    0xFF222222.toInt()
                )

                setTypeface(
                    null,
                    Typeface.BOLD
                )
            }
        )

        /*
         * Progress track.
         */
        val track =
            LinearLayout(this).apply {

                background =
                    rounded(
                        0xFFE6E6E6.toInt(),
                        dp(3)
                    )
            }

        /*
         * Progress.
         */
        val progress =
            View(this).apply {

                background =
                    rounded(
                        0xFFFF6876.toInt(),
                        dp(3)
                    )
            }

        track.addView(
            progress,
            LinearLayout.LayoutParams(
                0,
                dp(4)
            )
        )

        middle.addView(
            track,
            LinearLayout.LayoutParams(
                -1,
                dp(4)
            ).apply {
                topMargin = dp(5)
            }
        )

        row.addView(
            middle,
            LinearLayout.LayoutParams(
                0,
                dp(42),
                1f
            ).apply {

                marginStart = dp(10)

                marginEnd = dp(8)
            }
        )

        /*
         * Usage time.
         */
        row.addView(
            TextView(this).apply {

                text =
                    formatDuration(
                        stat.totalTimeInForeground
                    )

                textSize = 9f

                gravity =
                    Gravity.CENTER_VERTICAL or
                            Gravity.END

                setTextColor(
                    0xFF222222.toInt()
                )
            },
            LinearLayout.LayoutParams(
                dp(50),
                dp(42)
            )
        )

        /*
         * Set progress width after layout.
         */
        row.post {

            val width =
                track.width.coerceAtLeast(1)

            progress.layoutParams =
                LinearLayout.LayoutParams(
                    (
                            width *
                                    stat.totalTimeInForeground /
                                    maxUsage
                            )
                        .toInt()
                        .coerceAtLeast(
                            dp(3)
                        ),
                    dp(4)
                )
        }

        return row
    }

    /**
     * Query Android Usage Stats.
     */
    private fun queryUsage(
        begin: Long,
        end: Long
    ): List<UsageStats> {

        val manager =
            getSystemService(
                Context.USAGE_STATS_SERVICE
            ) as UsageStatsManager

        return manager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            begin,
            end
        ) ?: emptyList()
    }

    /**
     * Get usage range.
     *
     * Today:
     * Start of today -> now
     *
     * Last 7 Days:
     * Start of six days ago -> now
     */
    private fun usageRange(
        days: Int
    ): Pair<Long, Long> {

        val end =
            System.currentTimeMillis()

        val calendar =
            Calendar.getInstance().apply {

                timeInMillis = end

                set(
                    Calendar.HOUR_OF_DAY,
                    0
                )

                set(
                    Calendar.MINUTE,
                    0
                )

                set(
                    Calendar.SECOND,
                    0
                )

                set(
                    Calendar.MILLISECOND,
                    0
                )
            }

        return (
                calendar.timeInMillis -
                        (days - 1L) * DAY
                ) to end
    }

    /**
     * Check Usage Access permission.
     */
    private fun hasUsageAccess(): Boolean {

        val ops =
            getSystemService(
                Context.APP_OPS_SERVICE
            ) as AppOpsManager

        return ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Format milliseconds into hours/minutes.
     */
    private fun formatDuration(
        milliseconds: Long
    ): String {

        val minutes =
            milliseconds / 60000L

        return "${minutes / 60}h ${minutes % 60}m"
    }

    /**
     * Rounded background drawable.
     */
    private fun rounded(
        color: Int,
        radius: Int
    ) =
        android.graphics.drawable.GradientDrawable().apply {

            setColor(color)

            cornerRadius =
                radius.toFloat()
        }

    /**
     * Convert dp to pixels.
     */
    private fun dp(
        value: Int
    ): Int =
        (
                value *
                        resources.displayMetrics.density
                ).toInt()

    companion object {

        private const val DAY =
            86_400_000L
    }
}