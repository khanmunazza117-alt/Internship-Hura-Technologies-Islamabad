package com.mastercoding.phonecleaner

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class TermsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_terms)

        val content =
            findViewById<android.view.ViewGroup>(
                android.R.id.content
            )

        window.enablePhoneCleanerEdgeToEdge(content.getChildAt(0))

        val btnAccept = findViewById<AppCompatButton>(R.id.btnAccept)
        val btnDecline = findViewById<AppCompatButton>(R.id.btnDecline)

        // ACCEPT
        btnAccept.setOnClickListener {

            Toast.makeText(
                this,
                "Terms Accepted!",
                Toast.LENGTH_SHORT
            ).show()

            /*
             * User has completed the first-time setup.
             *
             * Save this in SharedPreferences so that
             * next time the app opens:
             *
             * Splash -> MainActivity
             */
            getSharedPreferences(
                SplashActivity.PREFS_NAME,
                MODE_PRIVATE
            )
                .edit()
                .putBoolean(
                    SplashActivity.KEY_SETUP_COMPLETE,
                    true
                )
                .apply()

            // Go to MainActivity
            val intent = Intent(
                this,
                MainActivity::class.java
            )

            startActivity(intent)
            finish()
        }

        // DECLINE
        btnDecline.setOnClickListener {
            finish()
        }
    }
}