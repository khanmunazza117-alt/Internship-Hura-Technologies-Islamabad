package com.mastercoding.phonecleaner

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.mastercoding.phonecleaner.databinding.ActivityLargeFilesBinding
import java.util.concurrent.Executors

class LargeFilesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLargeFilesBinding
    private lateinit var adapter: LargeFilesAdapter
    private val executor = Executors.newSingleThreadExecutor()
    private var currentTab = TAB_VIDEOS

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.any { it }) scanCurrentTab()
        else showPermissionMessage()
    }

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            Toast.makeText(this, "Selected files deleted", Toast.LENGTH_SHORT).show()
            scanCurrentTab()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLargeFilesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.enablePhoneCleanerEdgeToEdge(binding.root)

        adapter = LargeFilesAdapter { updateCleanButton() }
        binding.rvLargeFiles.layoutManager = GridLayoutManager(this, 2)
        binding.rvLargeFiles.adapter = adapter

        binding.btnBack.setOnClickListener { finish() }
        binding.btnVideos.setOnClickListener { selectTab(TAB_VIDEOS) }
        binding.btnDocuments.setOnClickListener { selectTab(TAB_DOCUMENTS) }
        binding.btnCleanNow.setOnClickListener { deleteSelectedFiles() }

        selectTab(TAB_VIDEOS)
        requestStorageAccessIfNeeded()
    }

    private fun requestStorageAccessIfNeeded() {
        val permissions = requiredPermissions()
        if (permissions.all { hasPermission(it) }) scanCurrentTab()
        else permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun requiredPermissions(): List<String> = if (
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
    ) {
        listOf(Manifest.permission.READ_MEDIA_VIDEO)
    } else {
        listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun selectTab(tab: Int) {
        currentTab = tab
        binding.btnVideos.isSelected = tab == TAB_VIDEOS
        binding.btnDocuments.isSelected = tab == TAB_DOCUMENTS
        binding.btnVideos.setTextColor(if (tab == TAB_VIDEOS) WHITE else GREY)
        binding.btnDocuments.setTextColor(if (tab == TAB_DOCUMENTS) WHITE else GREY)
        scanCurrentTab()
    }

    private fun scanCurrentTab() {
        showScanning(true)
        executor.execute {
            val files = if (currentTab == TAB_VIDEOS) queryVideos() else queryDocuments()
            runOnUiThread {
                showScanning(false)
                adapter.submitList(files)
                updateCleanButton()

                binding.emptyContainer.visibility =
                    if (files.isEmpty()) View.VISIBLE else View.GONE

                binding.rvLargeFiles.visibility =
                    if (files.isEmpty()) View.GONE else View.VISIBLE

                binding.tvEmpty.text = if (currentTab == TAB_VIDEOS) {
                    "No Videos Found\n\nYou don't have any large videos\ntaking up space"
                } else {
                    "No Documents Found\n\nYou don't have any large documents\ntaking up space"
                }

                updateEmptyIcon(false)
            }
        }
    }

    private fun updateEmptyIcon(isScanning: Boolean) {
        val icon = when {
            isScanning && currentTab == TAB_VIDEOS -> R.drawable.ic_searching1
            isScanning && currentTab == TAB_DOCUMENTS -> R.drawable.ic_searching2
            !isScanning && currentTab == TAB_VIDEOS -> R.drawable.ic_videos
            else -> R.drawable.ic_documents
        }
        binding.ivEmpty.setImageResource(icon)
    }

    private fun showScanning(scanning: Boolean) {
        binding.emptyContainer.visibility = View.VISIBLE
        binding.rvLargeFiles.visibility = View.GONE
        binding.ivEmpty.visibility = View.VISIBLE
        binding.tvEmpty.visibility = View.VISIBLE
        binding.progressBar.visibility = View.GONE
        updateEmptyIcon(scanning)
        binding.tvEmpty.text = if (scanning) {
            if (currentTab == TAB_VIDEOS) "34%\nFinding Large Videos..."
            else "34%\nFinding Large Documents..."
        } else {
            if (currentTab == TAB_VIDEOS) "No Videos Found"
            else "No Documents Found"
        }
    }

    private fun showPermissionMessage() {
        binding.emptyContainer.visibility = View.VISIBLE
        binding.rvLargeFiles.visibility = View.GONE
        binding.ivEmpty.visibility = View.VISIBLE
        binding.tvEmpty.visibility = View.VISIBLE
        binding.tvEmpty.text = "Storage permission is needed\nto find large files"
        updateEmptyIcon(false)
    }

    private fun queryVideos(): List<LargeFileItem> {
        val result = mutableListOf<LargeFileItem>()
        val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE
        )
        val selection = "${MediaStore.Video.Media.SIZE} >= ?"
        val selectionArgs = arrayOf((5L * 1024L * 1024L).toString())

        contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            "${MediaStore.Video.Media.SIZE} DESC"
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                result += LargeFileItem(
                    ContentUris.withAppendedId(collection, id),
                    cursor.getString(nameColumn) ?: "Video file",
                    cursor.getLong(sizeColumn),
                    true,
                    false
                )
            }
        }
        return result
    }

    private fun queryDocuments(): List<LargeFileItem> {
        val result = mutableListOf<LargeFileItem>()
        val collection = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE
        )
        val selection = "${MediaStore.Files.FileColumns.MIME_TYPE} IN (?, ?, ?) AND ${MediaStore.Files.FileColumns.SIZE} >= ?"
        val selectionArgs = arrayOf(
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            (1L * 1024L * 1024L).toString()
        )

        contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            "${MediaStore.Files.FileColumns.SIZE} DESC"
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                result += LargeFileItem(
                    ContentUris.withAppendedId(collection, id),
                    cursor.getString(nameColumn) ?: "Document file",
                    cursor.getLong(sizeColumn),
                    false,
                    false
                )
            }
        }
        return result
    }

    private fun deleteSelectedFiles() {
        val selectedFiles = adapter.getSelectedItems()
        if (selectedFiles.isEmpty()) {
            Toast.makeText(this, "Select at least one file", Toast.LENGTH_SHORT).show()
            return
        }
        val selectedUris = selectedFiles.map { it.uri }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val request = MediaStore.createDeleteRequest(contentResolver, selectedUris)
            deleteLauncher.launch(
                IntentSenderRequest.Builder(request.intentSender).build()
            )
        } else {
            try {
                selectedUris.forEach { contentResolver.delete(it, null, null) }
                Toast.makeText(this, "Selected files deleted", Toast.LENGTH_SHORT).show()
                scanCurrentTab()
            } catch (_: RecoverableSecurityException) {
                Toast.makeText(
                    this,
                    "Android requires permission to delete these files",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun updateCleanButton() {
        val count = adapter.getSelectedItems().size
        binding.btnCleanNow.text = if (count == 0) "Clean Now" else "Clean Now ($count)"
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val TAB_VIDEOS = 0
        private const val TAB_DOCUMENTS = 1
        private const val WHITE = 0xFFFFFFFF.toInt()
        private const val GREY = 0xFF777777.toInt()
    }
}
