package com.mastercoding.phonecleaner

import android.content.Intent
import android.os.Bundle
import android.os.StatFs
import androidx.appcompat.app.AppCompatActivity
import com.mastercoding.phonecleaner.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Apply edge-to-edge handling after setContentView().
        window.enablePhoneCleanerEdgeToEdge(binding.mainRoot)

        setupClickListeners()
        loadStorageData()
    }

    private fun setupClickListeners() {
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnVip.setOnClickListener {
            startActivity(Intent(this, PaywallActivity::class.java))
        }

        binding.btnCleanNow.setOnClickListener {
            startActivity(Intent(this, LargeFilesActivity::class.java))
        }

        binding.cardPhotoSwipe.setOnClickListener {
            startActivity(Intent(this, PhotoSwipeActivity::class.java))
        }

        binding.cardStorageStats.setOnClickListener {
            startActivity(Intent(this, StorageStatsActivity::class.java))
        }

        binding.cardScreenTime.setOnClickListener {
            startActivity(Intent(this, ScreenTimeActivity::class.java))
        }

        binding.cardScreenshots.setOnClickListener {
            startActivity(Intent(this, ScreenshotCleanupActivity::class.java))
        }

        binding.cardDuplicates.setOnClickListener {
            startActivity(Intent(this, DuplicateFilesActivity::class.java))
        }
    }

    private fun loadStorageData() {
        val statFs = StatFs(filesDir.absolutePath)
        val totalBytes = statFs.totalBytes
        val freeBytes = statFs.availableBytes
        val usedBytes = (totalBytes - freeBytes).coerceAtLeast(0L)

        val usedPercent = if (totalBytes > 0L) {
            (usedBytes * 100L / totalBytes).toInt()
        } else {
            0
        }

        binding.tvStoragePercentage.text = "$usedPercent%"
        binding.tvStorageUsageDetails.text =
            "${formatBytes(usedBytes)} of ${formatBytes(totalBytes)}"
    }

    private fun formatBytes(bytes: Long): String {
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)

        return if (gb >= 1.0) {
            String.format("%.1f GB", gb)
        } else {
            String.format("%.0f MB", bytes / (1024.0 * 1024.0))
        }
    }
}
