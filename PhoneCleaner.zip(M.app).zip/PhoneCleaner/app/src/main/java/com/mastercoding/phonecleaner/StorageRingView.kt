package com.mastercoding.phonecleaner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View

class StorageRingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var percentage: Int = 0
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 22f
        strokeCap = Paint.Cap.ROUND
    }

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 22f
        strokeCap = Paint.Cap.ROUND
        color = 0xFFFFE4D2.toInt()
    }

    private val percentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF541A16.toInt()
        textSize = 28f
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.DEFAULT,
            android.graphics.Typeface.BOLD
        )
    }

    private val usedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF222222.toInt()
        textSize = 13f
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.DEFAULT,
            android.graphics.Typeface.BOLD
        )
    }

    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val centerX = width / 2f
        val centerY = height / 2f
        val padding = ringPaint.strokeWidth / 2f + 5f
        rect.set(padding, padding, width - padding, height - padding)

        ringPaint.shader = SweepGradient(
            centerX,
            centerY,
            intArrayOf(
                0xFFFF4D73.toInt(),
                0xFFFF8541.toInt(),
                0xFFFF4D73.toInt()
            ),
            floatArrayOf(0f, 0.55f, 1f)
        )

        canvas.drawArc(rect, -90f, 360f, false, trackPaint)
        canvas.drawArc(rect, -90f, 3.6f * percentage, false, ringPaint)

        val percentBaseline = centerY - (percentPaint.ascent() + percentPaint.descent()) / 2f - 5f
        canvas.drawText("$percentage%", centerX, percentBaseline, percentPaint)
        canvas.drawText("Used", centerX, percentBaseline + 22f, usedPaint)
    }
}