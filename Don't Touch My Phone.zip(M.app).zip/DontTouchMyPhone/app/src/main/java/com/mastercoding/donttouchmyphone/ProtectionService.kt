package com.mastercoding.donttouchmyphone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlin.math.sqrt

class ProtectionService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var proximitySensor: Sensor? = null

    private lateinit var soundManager: SoundManager
    private lateinit var settingsHelper: SettingsHelper
    private lateinit var appSettings: AppSettings

    private var chargerReceiver: ChargerReceiver? = null
    private var isAlarmTriggered = false
    private var wasPocketCovered = false

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)

        soundManager = SoundManager(this)
        settingsHelper = SettingsHelper(this)
        appSettings = AppSettings(this)

        startForegroundServiceNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (appSettings.activeMode == "TOUCH") {
            unregisterChargerReceiver()
            registerSensors()
        } else if (appSettings.activeMode == "CHARGER") {
            unregisterSensors()
            registerChargerReceiver()
        }
        return START_STICKY
    }

    private fun registerSensors() {
        unregisterSensors()
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        proximitySensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    private fun unregisterSensors() {
        sensorManager.unregisterListener(this)
    }

    private fun registerChargerReceiver() {
        if (chargerReceiver == null) {
            chargerReceiver = ChargerReceiver()
            val filter = IntentFilter(Intent.ACTION_POWER_DISCONNECTED)
            registerReceiver(chargerReceiver, filter)
        }
    }

    private fun unregisterChargerReceiver() {
        chargerReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            chargerReceiver = null
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        if (isAlarmTriggered || appSettings.activeMode != "TOUCH") return

        when (event.sensor.type) {
            Sensor.TYPE_PROXIMITY -> {
                val distance = event.values[0]
                val maxRange = event.sensor.maximumRange
                if (distance < maxRange) {
                    wasPocketCovered = true
                } else if (wasPocketCovered) {
                    triggerAlarm()
                }
            }
            Sensor.TYPE_ACCELEROMETER -> {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                val gForce = sqrt((x * x + y * y + z * z).toDouble()) / SensorManager.GRAVITY_EARTH

                if (gForce > 1.4) {
                    triggerAlarm()
                }
            }
        }
    }

    private fun triggerAlarm() {
        isAlarmTriggered = true

        soundManager.playSound(appSettings.selectedSoundResId, isLooping = true)

        if (appSettings.isFlashlightEnabled) {
            settingsHelper.setFlashlight(true)
        }

        if (appSettings.isVibrationEnabled) {
            settingsHelper.triggerVibration()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        unregisterSensors()
        unregisterChargerReceiver()
        soundManager.stopSound()
        settingsHelper.setFlashlight(false)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundServiceNotification() {
        val channelId = "protection_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Phone Protection", NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val modeText = if (appSettings.activeMode == "TOUCH") "Motion & Pocket" else "Charger Unplug"
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Protection Active")
            .setContentText("Monitoring $modeText mode...")
            .setSmallIcon(R.drawable.shield_icon)
            .build()

        startForeground(1, notification)
    }
}