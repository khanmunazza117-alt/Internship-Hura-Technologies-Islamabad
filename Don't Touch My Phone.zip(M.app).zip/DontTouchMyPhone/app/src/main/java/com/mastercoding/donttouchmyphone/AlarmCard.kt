package com.mastercoding.donttouchmyphone

class AlarmCard {
}