package com.mastercoding.donttouchmyphone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ChargerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_POWER_DISCONNECTED) {
            val appSettings = AppSettings(context)

            // Agar Charger Mode active hai tabhi sound bajayega
            if (appSettings.activeMode == "CHARGER") {
                val soundManager = SoundManager(context)
                val settingsHelper = SettingsHelper(context)

                // User ka selected sound loop par bajayega
                soundManager.playSound(appSettings.selectedSoundResId, isLooping = true)

                if (appSettings.isFlashlightEnabled) {
                    settingsHelper.setFlashlight(true)
                }

                if (appSettings.isVibrationEnabled) {
                    settingsHelper.triggerVibration()
                }
            }
        }
    }
}