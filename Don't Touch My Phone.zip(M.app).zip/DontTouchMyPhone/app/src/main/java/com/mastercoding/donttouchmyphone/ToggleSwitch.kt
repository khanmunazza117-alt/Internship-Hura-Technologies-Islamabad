package com.mastercoding.donttouchmyphone

class ToggleSwitch {
}