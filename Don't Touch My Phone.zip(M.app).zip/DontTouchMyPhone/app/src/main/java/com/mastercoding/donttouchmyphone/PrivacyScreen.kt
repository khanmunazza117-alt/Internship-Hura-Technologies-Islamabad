package com.mastercoding.donttouchmyphone

class PrivacyScreen {
}