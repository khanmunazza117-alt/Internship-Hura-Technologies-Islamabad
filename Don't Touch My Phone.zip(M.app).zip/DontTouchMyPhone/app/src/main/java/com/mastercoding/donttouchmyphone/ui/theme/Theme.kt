package com.mastercoding.donttouchmyphone.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = Green,
    onPrimary = White,

    secondary = Green,
    onSecondary = White,

    background = Background,
    onBackground = Black,

    surface = White,
    onSurface = Black,

    error = Red,
    onError = White
)

private val DarkColorScheme = darkColorScheme(
    primary = Green,
    onPrimary = Black,

    secondary = Green,
    onSecondary = Black,

    background = Black,
    onBackground = White,

    surface = Black,
    onSurface = White,

    error = Red,
    onError = White
)

@Composable
fun DontTouchMyPhoneTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}