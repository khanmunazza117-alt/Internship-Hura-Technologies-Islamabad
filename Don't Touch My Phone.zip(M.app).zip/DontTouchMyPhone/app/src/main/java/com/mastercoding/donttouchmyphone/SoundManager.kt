package com.mastercoding.donttouchmyphone

import android.content.Context
import android.media.MediaPlayer

class SoundManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null


    fun playSound(rawResId: Int, isLooping: Boolean = false) {
        stopSound()
        mediaPlayer = MediaPlayer.create(context, rawResId).apply {
            this.isLooping = isLooping
            start()
        }
    }


    fun stopSound() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
        }
        mediaPlayer = null
    }
}