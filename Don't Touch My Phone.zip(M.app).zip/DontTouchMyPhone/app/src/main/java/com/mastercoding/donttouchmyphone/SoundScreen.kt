package com.mastercoding.donttouchmyphone

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SoundScreen(
    onBack: () -> Unit
) {

    val green = Color(0xFF2AD490)
    val black = Color(0xFF000000)
    val white = Color(0xFFFFFFFF)
    val background = Color(0xFFF7F7F7)
    val gray = Color(0xFF777777)

    var selectedSound by remember {
        mutableStateOf("Default Alarm")
    }

    val sounds = listOf(
        "Default Alarm",
        "Security Alarm",
        "Police Alarm",
        "Warning Alarm",
        "Loud Siren"
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = background
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(
                    rememberScrollState()
                )
                .padding(
                    start = 20.dp,
                    end = 20.dp,
                    top = 20.dp,
                    bottom = 25.dp
                )
        ) {

            // =====================================================
            // TOP BAR
            // =====================================================

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(green)
                        .clickable {
                            onBack()
                        },
                    contentAlignment = Alignment.Center
                ) {

                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = black,
                        modifier = Modifier.size(23.dp)
                    )
                }

                Spacer(
                    modifier = Modifier.width(15.dp)
                )

                Column {

                    Text(
                        text = "Alarm Sound",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = black
                    )

                    Spacer(
                        modifier = Modifier.height(3.dp)
                    )

                    Text(
                        text = "Choose your alarm sound",
                        fontSize = 12.sp,
                        color = gray
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(28.dp)
            )

            // =====================================================
            // SOUND HEADER CARD
            // =====================================================

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(
                        RoundedCornerShape(24.dp)
                    )
                    .background(black)
                    .padding(22.dp)
            ) {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(green),
                        contentAlignment = Alignment.Center
                    ) {

                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Sound",
                            tint = black,
                            modifier = Modifier.size(29.dp)
                        )
                    }

                    Spacer(
                        modifier = Modifier.width(16.dp)
                    )

                    Column {

                        Text(
                            text = "Selected Sound",
                            fontSize = 13.sp,
                            color = Color.LightGray
                        )

                        Spacer(
                            modifier = Modifier.height(4.dp)
                        )

                        Text(
                            text = selectedSound,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = white
                        )
                    }
                }
            }

            Spacer(
                modifier = Modifier.height(25.dp)
            )

            Text(
                text = "Available Sounds",
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = black
            )

            Spacer(
                modifier = Modifier.height(13.dp)
            )

            // =====================================================
            // SOUND LIST
            // =====================================================

            sounds.forEach { sound ->

                SoundItem(
                    title = sound,
                    selected = selectedSound == sound,
                    green = green,
                    black = black,
                    gray = gray,
                    onSelect = {
                        selectedSound = sound
                    }
                )

                Spacer(
                    modifier = Modifier.height(11.dp)
                )
            }
        }
    }
}


// =============================================================
// SOUND ITEM
// =============================================================

@Composable
private fun SoundItem(
    title: String,
    selected: Boolean,
    green: Color,
    black: Color,
    gray: Color,
    onSelect: () -> Unit
) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(
                RoundedCornerShape(20.dp)
            )
            .background(
                if (selected) {
                    green
                } else {
                    Color.White
                }
            )
            .clickable {
                onSelect()
            }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        // Play button
        Box(
            modifier = Modifier
                .size(45.dp)
                .clip(CircleShape)
                .background(
                    if (selected) {
                        black
                    } else {
                        Color(0xFFE8E8E8)
                    }
                )
                .clickable {
                    // Actual audio preview → Phase 4
                },
            contentAlignment = Alignment.Center
        ) {

            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Preview $title",
                tint = if (selected) {
                    green
                } else {
                    black
                },
                modifier = Modifier.size(23.dp)
            )
        }

        Spacer(
            modifier = Modifier.width(14.dp)
        )

        Text(
            text = title,
            modifier = Modifier.weight(1f),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = black
        )

        if (selected) {

            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(black),
                contentAlignment = Alignment.Center
            ) {

                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = green,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}