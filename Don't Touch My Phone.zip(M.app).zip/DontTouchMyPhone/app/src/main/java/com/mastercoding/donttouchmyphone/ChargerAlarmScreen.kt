package com.mastercoding.donttouchmyphone

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ChargerAlarmScreen(
    onBack: () -> Unit
) {

    val context = androidx.compose.ui.platform.LocalContext.current

    val preferences = remember {
        context.getSharedPreferences(
            "alarm_preferences",
            Context.MODE_PRIVATE
        )
    }

    var enabled by remember {
        mutableStateOf(
            preferences.getBoolean(
                "charger_enabled",
                false
            )
        )
    }

    val green = Color(0xFF2AD490)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F7F7))
            .padding(20.dp)
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = "‹",
                fontSize = 36.sp,
                color = Color.Black,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(green)
                    .clickable {
                        onBack()
                    }
                    .padding(start = 10.dp)
            )

            Spacer(
                modifier = Modifier.size(15.dp)
            )

            Text(
                text = "Charger alarm",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        }

        Spacer(
            modifier = Modifier.height(35.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(310.dp)
                .clip(
                    RoundedCornerShape(28.dp)
                )
                .background(Color.White)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Image(
                painter = painterResource(
                    R.drawable.charger_alarm
                ),
                contentDescription = null,
                modifier = Modifier.size(180.dp)
            )

            Spacer(
                modifier = Modifier.height(15.dp)
            )

            Text(
                text = if (enabled) {
                    "Charger alarm is active"
                } else {
                    "Charger alarm is off"
                },
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )

            Spacer(
                modifier = Modifier.height(7.dp)
            )

            Text(
                text = "Alert when your charger is removed",
                fontSize = 13.sp,
                color = Color.Gray
            )
        }

        Spacer(
            modifier = Modifier.height(22.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(
                    RoundedCornerShape(20.dp)
                )
                .background(
                    if (enabled) green else Color.White
                )
                .clickable {

                    enabled = !enabled

                    preferences.edit()
                        .putBoolean(
                            "charger_enabled",
                            enabled
                        )
                        .apply()
                }
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = if (enabled) {
                    "Protection ON"
                } else {
                    "Protection OFF"
                },
                modifier = Modifier.weight(1f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )

            Text(
                text = if (enabled) {
                    "Tap to stop"
                } else {
                    "Tap to enable"
                },
                fontSize = 13.sp,
                color = Color.DarkGray
            )
        }
    }
}