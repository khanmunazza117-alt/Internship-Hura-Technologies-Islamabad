package com.mastercoding.donttouchmyphone

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.mastercoding.donttouchmyphone.ui.theme.DontTouchMyPhoneTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DontTouchMyPhoneTheme {
                AppNavigation()
            }
        }
    }
}