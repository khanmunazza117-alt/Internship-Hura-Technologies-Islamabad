package com.mastercoding.donttouchmyphone.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()