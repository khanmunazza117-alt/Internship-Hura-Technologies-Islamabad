package com.mastercoding.donttouchmyphone

class MotionDetector {
}