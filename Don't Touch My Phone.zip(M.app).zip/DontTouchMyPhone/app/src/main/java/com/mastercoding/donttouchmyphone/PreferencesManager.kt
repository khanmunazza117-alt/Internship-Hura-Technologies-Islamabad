package com.mastercoding.donttouchmyphone

class PreferencesManager {
}