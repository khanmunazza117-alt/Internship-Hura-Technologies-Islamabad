package com.mastercoding.donttouchmyphone

import android.content.Intent
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onNavigateToSound: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val appSettings = remember { AppSettings(context) }

    // Initial state load based on saved mode
    var isTouchAlarmSelected by remember { mutableStateOf(appSettings.activeMode == "TOUCH") }
    var isEnabled by remember { mutableStateOf(false) }
    var sliderPosition by remember { mutableFloatStateOf(0.5f) }

    val primaryGreen = Color(0xFF26D07C)
    val cardBg = Color.White
    val textDark = Color(0xFF111111)

    fun toggleProtectionService(enable: Boolean) {
        val serviceIntent = Intent(context, ProtectionService::class.java)
        if (enable) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } else {
            context.stopService(serviceIntent)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F7F7))
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // --- TOP BAR ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Don’t touch my phone",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = textDark
            )
            Image(
                painter = painterResource(id = R.drawable.shield_icon),
                contentDescription = "Shield",
                modifier = Modifier.size(34.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- MAIN CARD WITH OVERLAPPING FLOATING CIRCLE ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 70.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 95.dp, bottom = 24.dp, start = 20.dp, end = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isTouchAlarmSelected) "Don’t Touch alarm" else "Charger alarm",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = textDark
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = if (isEnabled) "Protection Active" else "Tap to enable",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = textDark
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Switch Button
                    Box(
                        modifier = Modifier
                            .width(72.dp)
                            .height(36.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isEnabled) primaryGreen else Color(0xFFE2E2E2))
                            .clickable {
                                isEnabled = !isEnabled
                                toggleProtectionService(isEnabled)
                            }
                            .padding(4.dp),
                        contentAlignment = if (isEnabled) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    // Volume Section
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Volume",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = textDark,
                            modifier = Modifier.padding(start = 4.dp, bottom = 2.dp)
                        )

                        Slider(
                            value = sliderPosition,
                            onValueChange = { sliderPosition = it },
                            modifier = Modifier.fillMaxWidth(),
                            colors = SliderDefaults.colors(
                                thumbColor = primaryGreen,
                                activeTrackColor = primaryGreen,
                                inactiveTrackColor = Color(0xFFEEEEEE)
                            ),
                            thumb = {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(primaryGreen)
                                )
                            },
                            track = { sliderState ->
                                SliderDefaults.Track(
                                    sliderState = sliderState,
                                    modifier = Modifier.height(6.dp),
                                    colors = SliderDefaults.colors(
                                        activeTrackColor = primaryGreen,
                                        inactiveTrackColor = Color(0xFFEBEBEB)
                                    )
                                )
                            }
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .offset(y = (-70).dp)
                    .size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(
                        id = if (isTouchAlarmSelected) R.drawable.touch_alarm else R.drawable.charger_alarm
                    ),
                    contentDescription = "Selected Alarm Icon",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- ROW 1: ALARM SELECTION CARDS ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OptionCard(
                modifier = Modifier.weight(1f),
                title = "Don’t Touch alarm",
                subtitle = "Detect motion & pocket",
                iconRes = R.drawable.touch_alarm_icon,
                isSelected = isTouchAlarmSelected,
                primaryColor = primaryGreen,
                onClick = {
                    isTouchAlarmSelected = true
                    appSettings.activeMode = "TOUCH"
                    if (isEnabled) toggleProtectionService(true)
                }
            )

            OptionCard(
                modifier = Modifier.weight(1f),
                title = "Charger alarm",
                subtitle = "Detect charger removal",
                iconRes = R.drawable.charger_alarm_icon,
                isSelected = !isTouchAlarmSelected,
                primaryColor = primaryGreen,
                onClick = {
                    isTouchAlarmSelected = false
                    appSettings.activeMode = "CHARGER"
                    if (isEnabled) toggleProtectionService(true)
                }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- ROW 2: SOUNDS & SETTINGS CARDS ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SimpleActionCard(
                modifier = Modifier.weight(1f),
                title = "Alarm sounds",
                subtitle = "Select alert sound",
                iconRes = R.drawable.alarm_sound_icon,
                onClick = onNavigateToSound
            )

            SimpleActionCard(
                modifier = Modifier.weight(1f),
                title = "Setting",
                subtitle = "Flash & vibration",
                iconRes = R.drawable.settings_icon,
                onClick = onNavigateToSettings
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun OptionCard(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    iconRes: Int,
    isSelected: Boolean,
    primaryColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(140.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, primaryColor) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .align(Alignment.TopEnd)
                    .border(
                        width = 1.5.dp,
                        color = if (isSelected) primaryColor else Color(0xFFCCCCCC),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(primaryColor)
                    )
                }
            }

            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(id = iconRes),
                    contentDescription = title,
                    modifier = Modifier.size(48.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111111)
                )

                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = Color(0xFF888888)
                )
            }
        }
    }
}

@Composable
fun SimpleActionCard(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    iconRes: Int,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(85.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = iconRes),
                contentDescription = title,
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111111)
                )
                Text(
                    text = subtitle,
                    fontSize = 9.sp,
                    color = Color(0xFF888888)
                )
            }
        }
    }
}