package com.mastercoding.donttouchmyphone

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val helper = remember { SettingsHelper(context) }

    var isFlashlightEnabled by remember { mutableStateOf(true) }
    var isVibrationEnabled by remember { mutableStateOf(true) }

    val textDark = Color(0xFF111111)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F7F7))
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        // --- TOP BAR (Centered Title & Left Back Arrow) ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.back_icon),
                contentDescription = "Back",
                modifier = Modifier
                    .size(24.dp)
                    .align(Alignment.CenterStart)
                    .clickable { onBackClick() }
            )

            Text(
                text = "Setting",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = textDark,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Blinking Flashlight Card
        FigmaSettingToggleCard(
            title = "Blinking flashlight on alarm",
            iconRes = R.drawable.flashlight_icon,
            isChecked = isFlashlightEnabled,
            onClick = {
                isFlashlightEnabled = !isFlashlightEnabled
                helper.setFlashlight(isFlashlightEnabled)
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 2. Vibrate on Alarm Card
        FigmaSettingToggleCard(
            title = "Vibrate on alarm",
            iconRes = R.drawable.vibration_icon,
            isChecked = isVibrationEnabled,
            onClick = {
                isVibrationEnabled = !isVibrationEnabled
                if (isVibrationEnabled) {
                    helper.triggerVibration()
                }
            }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Privacy Policy Card
        FigmaSettingActionCard(
            title = "Privacy policy",
            iconRes = R.drawable.privacy_icon,
            onClick = { helper.openPrivacyPolicy("https://www.google.com") }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 4. Rate Us Card
        FigmaSettingActionCard(
            title = "Rate us",
            iconRes = R.drawable.rate_icon,
            onClick = { helper.rateApp() }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 5. Share Card
        FigmaSettingActionCard(
            title = "Share",
            iconRes = R.drawable.share_icon,
            onClick = { helper.shareApp() }
        )
    }
}

@Composable
fun FigmaSettingToggleCard(
    title: String,
    iconRes: Int,
    isChecked: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = iconRes),
                    contentDescription = title,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF111111)
                )
            }

            if (isChecked) {
                Image(
                    painter = painterResource(id = R.drawable.check_icon),
                    contentDescription = "Selected",
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun FigmaSettingActionCard(
    title: String,
    iconRes: Int,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = iconRes),
                    contentDescription = title,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF111111)
                )
            }

            Image(
                painter = painterResource(id = R.drawable.arrow_right_icon),
                contentDescription = "Arrow",
                modifier = Modifier.size(18.dp)
            )
        }
    }
}