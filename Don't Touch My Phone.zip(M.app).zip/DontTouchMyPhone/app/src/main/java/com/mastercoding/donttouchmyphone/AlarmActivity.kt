package com.mastercoding.donttouchmyphone

import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class AlarmActivity : ComponentActivity() {

    companion object {

        const val EXTRA_ALARM_TYPE = "alarm_type"

        const val ALARM_TOUCH = "touch"

        const val ALARM_CHARGER = "charger"
    }

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    private var alarmType = ALARM_TOUCH

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Get alarm type
        alarmType =
            intent.getStringExtra(EXTRA_ALARM_TYPE)
                ?: ALARM_TOUCH

        // Start sound + vibration
        startAlarm()

        setContent {

            AlarmContent(
                alarmType = alarmType,
                onStop = {
                    stopAlarm()
                }
            )

            DisposableEffect(Unit) {

                onDispose {
                    stopAlarm()
                }
            }
        }
    }

    // =========================================================
    // START ALARM
    // =========================================================

    private fun startAlarm() {

        try {

            mediaPlayer = MediaPlayer.create(
                this,
                android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI
            )

            mediaPlayer?.isLooping = true

            mediaPlayer?.start()

        } catch (e: Exception) {

            e.printStackTrace()
        }

        startVibration()
    }

    // =========================================================
    // VIBRATION
    // =========================================================

    private fun startVibration() {

        vibrator =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

                val vibratorManager =
                    getSystemService(
                        VIBRATOR_MANAGER_SERVICE
                    ) as VibratorManager

                vibratorManager.defaultVibrator

            } else {

                @Suppress("DEPRECATION")
                getSystemService(
                    VIBRATOR_SERVICE
                ) as Vibrator
            }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val pattern = longArrayOf(
                0,
                500,
                300,
                500
            )

            vibrator?.vibrate(
                VibrationEffect.createWaveform(
                    pattern,
                    0
                )
            )

        } else {

            @Suppress("DEPRECATION")
            vibrator?.vibrate(
                longArrayOf(
                    0,
                    500,
                    300,
                    500
                ),
                0
            )
        }
    }

    // =========================================================
    // STOP ALARM
    // =========================================================

    private fun stopAlarm() {

        try {

            mediaPlayer?.stop()

        } catch (e: Exception) {

            e.printStackTrace()
        }

        mediaPlayer?.release()
        mediaPlayer = null

        vibrator?.cancel()
        vibrator = null

        finish()
    }

    // =========================================================
    // DESTROY
    // =========================================================

    override fun onDestroy() {

        mediaPlayer?.release()
        mediaPlayer = null

        vibrator?.cancel()
        vibrator = null

        super.onDestroy()
    }
}


// =============================================================
// ALARM SCREEN UI
// =============================================================

@Composable
private fun AlarmContent(
    alarmType: String,
    onStop: () -> Unit
) {

    val isTouch =
        alarmType == AlarmActivity.ALARM_TOUCH

    val green = Color(0xFF2AD490)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Color(0xFFF7F7F7)
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        // =====================================================
        // ALARM IMAGE
        // =====================================================

        Box(
            modifier = Modifier
                .size(190.dp)
                .clip(CircleShape)
                .background(
                    green.copy(alpha = 0.14f)
                ),
            contentAlignment = Alignment.Center
        ) {

            Image(
                painter = painterResource(
                    id = if (isTouch) {
                        R.drawable.touch_alarm
                    } else {
                        R.drawable.charger_alarm
                    }
                ),
                contentDescription = null,
                modifier = Modifier.size(155.dp)
            )
        }

        Spacer(
            modifier = Modifier.height(28.dp)
        )

        // =====================================================
        // TITLE
        // =====================================================

        Text(
            text = if (isTouch) {
                "Don’t touch my phone!"
            } else {
                "Charger removed!"
            },
            fontSize = 25.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        // =====================================================
        // DESCRIPTION
        // =====================================================

        Text(
            text = if (isTouch) {
                "Phone movement detected"
            } else {
                "Your charger has been disconnected"
            },
            fontSize = 14.sp,
            color = Color.Gray
        )

        Spacer(
            modifier = Modifier.height(35.dp)
        )

        // =====================================================
        // STOP BUTTON
        // =====================================================

        Box(
            modifier = Modifier
                .size(
                    width = 190.dp,
                    height = 55.dp
                )
                .clip(
                    RoundedCornerShape(28.dp)
                )
                .background(green)
                .clickable {
                    onStop()
                },
            contentAlignment = Alignment.Center
        ) {

            Text(
                text = "STOP ALARM",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        }
    }
}