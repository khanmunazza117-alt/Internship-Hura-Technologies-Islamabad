package com.mastercoding.donttouchmyphone.ui.theme

import androidx.compose.ui.graphics.Color

// Purane colors (Theme.kt aur SplashScreen.kt ke liye)
val Green = Color(0xFF26D07C)
val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)
val Background = Color(0xFFF7F7F7)
val Red = Color(0xFFFF4D4D)

// Figma Design New Colors
val AppBackground = Color(0xFFF7F7F7)
val CardBackground = Color(0xFFFFFFFF)
val PrimaryGreen = Color(0xFF26D07C)
val SoftGreenBg = Color(0xFFE8FAF2)
val TextDark = Color(0xFF111111)
val TextMuted = Color(0xFF888888)