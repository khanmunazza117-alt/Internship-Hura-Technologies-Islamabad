package com.mastercoding.donttouchmyphone

import android.content.Context
import android.content.SharedPreferences

class AppSettings(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_settings_prefs", Context.MODE_PRIVATE)

    var selectedSoundResId: Int
        get() = prefs.getInt("selected_sound", R.raw.alert_sound)
        set(value) = prefs.edit().putInt("selected_sound", value).apply()

    // Mode: "TOUCH" ya "CHARGER"
    var activeMode: String
        get() = prefs.getString("active_mode", "TOUCH") ?: "TOUCH"
        set(value) = prefs.edit().putString("active_mode", value).apply()

    var isFlashlightEnabled: Boolean
        get() = prefs.getBoolean("is_flashlight_enabled", true)
        set(value) = prefs.edit().putBoolean("is_flashlight_enabled", value).apply()

    var isVibrationEnabled: Boolean
        get() = prefs.getBoolean("is_vibration_enabled", true)
        set(value) = prefs.edit().putBoolean("is_vibration_enabled", value).apply()
}