package com.mastercoding.donttouchmyphone

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

sealed class Screen(val route: String) {
    object Splash : Screen("splash_screen")
    object Intro1 : Screen("intro1_screen")
    object Intro2 : Screen("intro2_screen")
    object Intro3 : Screen("intro3_screen")
    object Main : Screen("main_screen")
    object SelectSound : Screen("select_sound_screen")
    object Settings : Screen("settings_screen")
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        // Splash Screen
        composable(Screen.Splash.route) {
            SplashScreen(onFinished = {
                navController.navigate(Screen.Intro1.route) {
                    popUpTo(Screen.Splash.route) { inclusive = true }
                }
            })
        }

        // Onboarding Screens
        composable(Screen.Intro1.route) {
            Intro01Screen(onNext = {
                navController.navigate(Screen.Intro2.route)
            })
        }

        composable(Screen.Intro2.route) {
            Intro02Screen(onNext = {
                navController.navigate(Screen.Intro3.route)
            })
        }

        composable(Screen.Intro3.route) {
            Intro03Screen(onGetStarted = {
                navController.navigate(Screen.Main.route) {
                    popUpTo(Screen.Intro1.route) { inclusive = true }
                }
            })
        }

        // Main & Detail Screens
        composable(Screen.Main.route) {
            MainScreen(
                onNavigateToSound = { navController.navigate(Screen.SelectSound.route) },
                onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
            )
        }

        composable(Screen.SelectSound.route) {
            SelectSoundScreen(onBackClick = { navController.popBackStack() })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBackClick = { navController.popBackStack() })
        }
    }
}