package com.mastercoding.unitconvertercalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class CalculatorActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvExpression, tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        tvExpression = findViewById(R.id.tvExpression);
        tvResult = findViewById(R.id.tvResult);

        int[] buttonIds = {

                R.id.btn0,
                R.id.btn1,
                R.id.btn2,
                R.id.btn3,
                R.id.btn4,
                R.id.btn5,
                R.id.btn6,
                R.id.btn7,
                R.id.btn8,
                R.id.btn9,

                R.id.btnDot,

                R.id.btnPlus,
                R.id.btnMinus,
                R.id.btnMultiply,
                R.id.btnDivide,
                R.id.btnPercent,

                R.id.btnEqual,
                R.id.btnClear,
                R.id.btnDelete
        };

        for (int id : buttonIds) {
            MaterialButton button = findViewById(id);
            button.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {

        MaterialButton button = (MaterialButton) view;
        String text = button.getText().toString();

        String expression = tvExpression.getText().toString();

        switch (text) {

            case "AC":

                tvExpression.setText("");
                tvResult.setText("0");
                return;

            case "⌫":

                if (!expression.isEmpty()) {
                    expression = expression.substring(0, expression.length() - 1);
                    tvExpression.setText(expression);
                }

                return;

            case "=":

                if (expression.isEmpty())
                    return;

                double result = ExpressionEvaluator.evaluate(expression);

                if (result == (long) result) {
                    tvResult.setText(String.valueOf((long) result));
                } else {
                    tvResult.setText(String.valueOf(result));
                }

                return;

            default:

                expression += text;
                tvExpression.setText(expression);

                try {

                    double liveResult = ExpressionEvaluator.evaluate(expression);

                    if (liveResult == (long) liveResult) {
                        tvResult.setText(String.valueOf((long) liveResult));
                    } else {
                        tvResult.setText(String.valueOf(liveResult));
                    }

                } catch (Exception e) {

                    tvResult.setText("0");

                }

        }

    }

}
