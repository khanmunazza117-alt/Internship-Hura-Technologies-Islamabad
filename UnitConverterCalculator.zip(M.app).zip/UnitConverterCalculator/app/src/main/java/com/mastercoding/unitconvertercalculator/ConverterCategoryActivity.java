package com.mastercoding.unitconvertercalculator;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;

public class ConverterCategoryActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    MaterialToolbar toolbar;

    ArrayList<CategoryModel> categoryList;
    CategoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_converter_category);

        toolbar = findViewById(R.id.toolbar);
        recyclerView = findViewById(R.id.recyclerViewCategories);

        setSupportActionBar(toolbar);

        toolbar.setTitleTextColor(
                getResources().getColor(android.R.color.black)
        );

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Unit Converter");
        }

        recyclerView.setLayoutManager(
                new GridLayoutManager(this, 2)
        );

        categoryList = new ArrayList<>();

        loadCategories();

        adapter = new CategoryAdapter(this, categoryList);

        recyclerView.setAdapter(adapter);
    }

    private void loadCategories() {

        categoryList.add(new CategoryModel(
                "Length",
                android.R.drawable.ic_menu_compass));

        categoryList.add(new CategoryModel(
                "Weight",
                android.R.drawable.ic_menu_manage));

        categoryList.add(new CategoryModel(
                "Temperature",
                android.R.drawable.ic_menu_today));

        categoryList.add(new CategoryModel(
                "Area",
                android.R.drawable.ic_menu_crop));

        categoryList.add(new CategoryModel(
                "Volume",
                android.R.drawable.ic_menu_gallery));

        categoryList.add(new CategoryModel(
                "Speed",
                android.R.drawable.ic_media_play));

        categoryList.add(new CategoryModel(
                "Time",
                android.R.drawable.ic_lock_idle_alarm));

        categoryList.add(new CategoryModel(
                "Pressure",
                android.R.drawable.ic_menu_upload));

        categoryList.add(new CategoryModel(
                "Energy",
                android.R.drawable.ic_menu_rotate));

        categoryList.add(new CategoryModel(
                "Force",
                android.R.drawable.ic_menu_directions));

        categoryList.add(new CategoryModel(
                "Power",
                android.R.drawable.ic_menu_view));

        categoryList.add(new CategoryModel(
                "Angle",
                android.R.drawable.ic_menu_more));

        categoryList.add(new CategoryModel(
                "Currency",
                android.R.drawable.ic_menu_sort_by_size));

        categoryList.add(new CategoryModel(
                "Fuel",
                android.R.drawable.ic_menu_myplaces));
    }
}