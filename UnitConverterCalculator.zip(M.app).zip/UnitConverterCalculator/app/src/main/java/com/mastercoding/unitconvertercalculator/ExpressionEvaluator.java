package com.mastercoding.unitconvertercalculator;


public class ExpressionEvaluator {

    public static double evaluate(String expression) {

        expression = expression.replace("×", "*");
        expression = expression.replace("÷", "/");

        try {

            if (expression.contains("+")) {
                String[] arr = expression.split("\\+");
                return Double.parseDouble(arr[0]) + Double.parseDouble(arr[1]);
            }

            if (expression.contains("-")) {
                String[] arr = expression.split("-");
                return Double.parseDouble(arr[0]) - Double.parseDouble(arr[1]);
            }

            if (expression.contains("*")) {
                String[] arr = expression.split("\\*");
                return Double.parseDouble(arr[0]) * Double.parseDouble(arr[1]);
            }

            if (expression.contains("/")) {
                String[] arr = expression.split("/");
                return Double.parseDouble(arr[0]) / Double.parseDouble(arr[1]);
            }

            if (expression.contains("%")) {
                String[] arr = expression.split("%");
                return Double.parseDouble(arr[0]) % Double.parseDouble(arr[1]);
            }

            return Double.parseDouble(expression);

        } catch (Exception e) {
            return 0;
        }
    }
}