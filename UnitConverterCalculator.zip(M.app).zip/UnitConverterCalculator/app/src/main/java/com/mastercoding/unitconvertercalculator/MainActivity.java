package com.mastercoding.unitconvertercalculator;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnCalculator, btnConverter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCalculator = findViewById(R.id.btnCalculator);
        btnConverter = findViewById(R.id.btnConverter);

        btnCalculator.setOnClickListener(v -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    CalculatorActivity.class
            );

            startActivity(intent);

        });

        btnConverter.setOnClickListener(v -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    ConverterCategoryActivity.class
            );

            startActivity(intent);

        });

    }
}