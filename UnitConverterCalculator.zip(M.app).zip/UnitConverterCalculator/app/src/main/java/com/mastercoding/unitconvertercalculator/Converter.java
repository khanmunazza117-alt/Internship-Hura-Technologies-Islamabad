package com.mastercoding.unitconvertercalculator;

public class Converter {

    public static double convert(String category,
                                 String from,
                                 String to,
                                 double value) {

        switch (category) {

            case "Length":
                return convertLength(from, to, value);

            case "Weight":
                return convertWeight(from, to, value);

            case "Temperature":
                return convertTemperature(from, to, value);

            case "Time":
                return convertTime(from, to, value);

            case "Speed":
                return convertSpeed(from, to, value);

            default:
                return value;
        }
    }

    // LENGTH

    private static double convertLength(String from, String to, double value) {

        double meter = value;

        if (from.equals("Kilometer")) meter = value * 1000;
        else if (from.equals("Centimeter")) meter = value / 100;
        else if (from.equals("Millimeter")) meter = value / 1000;

        if (to.equals("Kilometer")) return meter / 1000;
        if (to.equals("Centimeter")) return meter * 100;
        if (to.equals("Millimeter")) return meter * 1000;

        return meter;
    }

    // WEIGHT

    private static double convertWeight(String from, String to, double value) {

        double kg = value;

        if (from.equals("Gram")) kg = value / 1000;
        else if (from.equals("Milligram")) kg = value / 1000000;
        else if (from.equals("Pound")) kg = value * 0.453592;

        if (to.equals("Gram")) return kg * 1000;
        if (to.equals("Milligram")) return kg * 1000000;
        if (to.equals("Pound")) return kg / 0.453592;

        return kg;
    }

    // TEMPERATURE

    private static double convertTemperature(String from,
                                             String to,
                                             double value) {

        if (from.equals(to))
            return value;

        if (from.equals("Celsius") && to.equals("Fahrenheit"))
            return (value * 9 / 5) + 32;

        if (from.equals("Fahrenheit") && to.equals("Celsius"))
            return (value - 32) * 5 / 9;

        if (from.equals("Celsius") && to.equals("Kelvin"))
            return value + 273.15;

        if (from.equals("Kelvin") && to.equals("Celsius"))
            return value - 273.15;

        return value;
    }

    // TIME

    private static double convertTime(String from,
                                      String to,
                                      double value) {

        double second = value;

        if (from.equals("Minute"))
            second = value * 60;
        else if (from.equals("Hour"))
            second = value * 3600;

        if (to.equals("Minute"))
            return second / 60;

        if (to.equals("Hour"))
            return second / 3600;

        return second;
    }

    // SPEED

    private static double convertSpeed(String from,
                                       String to,
                                       double value) {

        double ms = value;

        if (from.equals("km/h"))
            ms = value / 3.6;

        if (to.equals("km/h"))
            return ms * 3.6;

        return ms;
    }
}