package com.mastercoding.unitconvertercalculator;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;

import com.mastercoding.unitconvertercalculator.Converter;

public class ConverterActivity extends AppCompatActivity {

    MaterialToolbar toolbar;

    Spinner spinnerFrom, spinnerTo;
    EditText edtInput;
    TextView txtResult;

    ImageButton btnSwap;
    Button btnConvert, btnCopy, btnShare;

    String category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_converter);

        toolbar = findViewById(R.id.toolbar);

        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);

        edtInput = findViewById(R.id.edtInput);

        txtResult = findViewById(R.id.txtResult);

        btnSwap = findViewById(R.id.btnSwap);

        btnConvert = findViewById(R.id.btnConvert);
        btnCopy = findViewById(R.id.btnCopy);
        btnShare = findViewById(R.id.btnShare);

        category = getIntent().getStringExtra("category");

        if (category == null) {
            category = "Length";
        }

        toolbar.setTitle(category + " Converter");

        toolbar.setNavigationIcon(
                androidx.appcompat.R.drawable.abc_ic_ab_back_material
        );

        toolbar.setNavigationOnClickListener(v -> finish());

        loadUnits();

        btnConvert.setOnClickListener(v -> convert());

        edtInput.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s,
                                          int start,
                                          int count,
                                          int after) {

            }

            @Override
            public void onTextChanged(CharSequence s,
                                      int start,
                                      int before,
                                      int count) {

                convert();

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btnSwap.setOnClickListener(v -> {

            int from = spinnerFrom.getSelectedItemPosition();
            int to = spinnerTo.getSelectedItemPosition();

            spinnerFrom.setSelection(to);
            spinnerTo.setSelection(from);

            convert();

        });

        btnCopy.setOnClickListener(v -> {

            ClipboardManager clipboard =
                    (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);

            ClipData clip =
                    ClipData.newPlainText(
                            "Result",
                            txtResult.getText().toString()
                    );

            clipboard.setPrimaryClip(clip);

            Toast.makeText(
                    this,
                    "Copied Successfully",
                    Toast.LENGTH_SHORT
            ).show();

        });

        btnShare.setOnClickListener(v -> {

            Intent intent = new Intent(Intent.ACTION_SEND);

            intent.setType("text/plain");

            intent.putExtra(
                    Intent.EXTRA_TEXT,
                    txtResult.getText().toString()
            );

            startActivity(
                    Intent.createChooser(
                            intent,
                            "Share Result"
                    )
            );

        });

    }

    private void loadUnits() {

        String[] units;

        switch (category) {

            case "Length":
                units = new String[]{
                        "Meter",
                        "Kilometer",
                        "Centimeter",
                        "Millimeter",
                        "Foot",
                        "Inch"
                };
                break;

            case "Weight":
                units = new String[]{
                        "Kilogram",
                        "Gram",
                        "Milligram",
                        "Pound",
                        "Ounce"
                };
                break;

            case "Temperature":
                units = new String[]{
                        "Celsius",
                        "Fahrenheit",
                        "Kelvin"
                };
                break;

            case "Time":
                units = new String[]{
                        "Second",
                        "Minute",
                        "Hour",
                        "Day"
                };
                break;

            case "Speed":
                units = new String[]{
                        "m/s",
                        "km/h",
                        "mph"
                };
                break;

            case "Area":
                units = new String[]{
                        "Square Meter",
                        "Square Kilometer",
                        "Square Foot"
                };
                break;

            case "Volume":
                units = new String[]{
                        "Liter",
                        "Milliliter",
                        "Cubic Meter"
                };
                break;

            case "Pressure":
                units = new String[]{
                        "Pascal",
                        "Bar",
                        "PSI"
                };
                break;

            case "Energy":
                units = new String[]{
                        "Joule",
                        "Kilojoule",
                        "Calorie"
                };
                break;

            case "Force":
                units = new String[]{
                        "Newton",
                        "Kilonewton"
                };
                break;

            case "Power":
                units = new String[]{
                        "Watt",
                        "Kilowatt",
                        "Horsepower"
                };
                break;

            case "Angle":
                units = new String[]{
                        "Degree",
                        "Radian"
                };
                break;

            case "Data Storage":
                units = new String[]{
                        "Byte",
                        "KB",
                        "MB",
                        "GB"
                };
                break;

            case "Fuel":
                units = new String[]{
                        "km/L",
                        "L/100km"
                };
                break;

            case "Currency":
                units = new String[]{
                        "USD",
                        "EUR",
                        "GBP",
                        "PKR"
                };
                break;

            default:
                units = new String[]{
                        "Unit"
                };
                break;
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                units
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerFrom.setAdapter(adapter);
        spinnerTo.setAdapter(adapter);
    }

        private void convert() {

            try {

                String input = edtInput.getText().toString().trim();

                if (input.isEmpty()) {
                    txtResult.setText("0");
                    return;
                }

                double value = Double.parseDouble(input);

                String from = spinnerFrom.getSelectedItem().toString();
                String to = spinnerTo.getSelectedItem().toString();

                double result = Converter.convert(
                        category,
                        from,
                        to,
                        value
                );

                if (result == (long) result) {
                    txtResult.setText(String.valueOf((long) result));
                } else {
                    txtResult.setText(String.format("%.4f", result));
                }

            } catch (Exception e) {

                txtResult.setText("Error");

            }

        }

    }
