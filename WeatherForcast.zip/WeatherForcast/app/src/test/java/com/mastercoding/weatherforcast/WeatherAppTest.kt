package com.mastercoding.weatherforcast

import com.mastercoding.weatherforcast.data.local.TemperatureUnit
import com.mastercoding.weatherforcast.data.local.WindSpeedUnit
import com.mastercoding.weatherforcast.data.model.PakistanCitiesData
import com.mastercoding.weatherforcast.data.model.WeatherCondition
import com.mastercoding.weatherforcast.data.repository.WeatherRepository
import com.mastercoding.weatherforcast.ui.components.formatTemp
import com.mastercoding.weatherforcast.ui.components.formatWind
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WeatherAppTest {

    private val repository = WeatherRepository()

    @Test
    fun testPakistanMajorCitiesData() {
        val cities = PakistanCitiesData.majorCities
        assertTrue("Major cities list should contain at least 15 cities", cities.size >= 15)

        val islamabad = PakistanCitiesData.findCityByName("Islamabad")
        assertNotNull(islamabad)
        assertEquals("Islamabad", islamabad.name)
        assertTrue(islamabad.isCapital)

        val lahore = PakistanCitiesData.findCityByName("Lahore")
        assertNotNull(lahore)
        assertEquals("Punjab", lahore.province)

        val karachi = PakistanCitiesData.findCityByName("Karachi")
        assertNotNull(karachi)
        assertEquals("Sindh", karachi.province)
    }

    @Test
    fun testWeatherRepositoryForecastGeneration() = runBlocking {
        val result = repository.getCityWeather("Islamabad", null)
        assertTrue(result.isSuccess)

        val weather = result.getOrNull()
        assertNotNull(weather)
        assertEquals("Islamabad", weather!!.city.name)
        assertTrue(weather.currentTempC > 0)
        assertTrue(weather.hourlyForecast.size == 24)
        assertTrue(weather.dailyForecast.size == 7)
        assertTrue(weather.formattedDateTime.contains("PKT"))
    }

    @Test
    fun testAllPakistanCitiesWeather() = runBlocking {
        val allWeather = repository.getAllPakistanCitiesWeather(null)
        assertTrue(allWeather.isNotEmpty())
        assertTrue(allWeather.any { it.city.name == "Islamabad" })
        assertTrue(allWeather.any { it.city.name == "Lahore" })
        assertTrue(allWeather.any { it.city.name == "Karachi" })
        assertTrue(allWeather.any { it.city.name == "Quetta" })
        assertTrue(allWeather.any { it.city.name == "Peshawar" })
    }

    @Test
    fun testWeatherConditionParsing() {
        assertEquals(WeatherCondition.RAINY, WeatherCondition.fromOpenWeather("Rain", "light rain"))
        assertEquals(WeatherCondition.THUNDERSTORM, WeatherCondition.fromOpenWeather("Thunderstorm", "heavy storm"))
        assertEquals(WeatherCondition.CLOUDY, WeatherCondition.fromOpenWeather("Clouds", "scattered clouds"))
        assertEquals(WeatherCondition.SUNNY, WeatherCondition.fromOpenWeather("Clear", "clear sky"))
        assertEquals(WeatherCondition.SNOW, WeatherCondition.fromOpenWeather("Snow", "light snow"))
        assertEquals(WeatherCondition.MIST, WeatherCondition.fromOpenWeather("Mist", "misty haze"))
    }

    @Test
    fun testUnitFormatting() {
        val tempC = 25
        assertEquals("25°C", formatTemp(tempC, TemperatureUnit.CELSIUS))
        assertEquals("77°F", formatTemp(tempC, TemperatureUnit.FAHRENHEIT))

        val windKmh = 18.0
        assertEquals("18.0 km/h", formatWind(windKmh, WindSpeedUnit.KMH))
        assertEquals("5.0 m/s", formatWind(windKmh, WindSpeedUnit.MS))
        assertEquals("11.2 mph", formatWind(windKmh, WindSpeedUnit.MPH))
    }
}
