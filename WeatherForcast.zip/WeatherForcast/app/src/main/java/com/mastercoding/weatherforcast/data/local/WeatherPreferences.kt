package com.mastercoding.weatherforcast.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppThemeMode {
    SYSTEM, LIGHT, DARK
}

enum class TemperatureUnit {
    CELSIUS, FAHRENHEIT
}

enum class WindSpeedUnit {
    KMH, MS, MPH
}

class WeatherPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(getThemeMode())
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    private val _temperatureUnit = MutableStateFlow(getTemperatureUnit())
    val temperatureUnit: StateFlow<TemperatureUnit> = _temperatureUnit.asStateFlow()

    private val _selectedCity = MutableStateFlow(getSelectedCity())
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    fun isOnboardingCompleted(): Boolean {
        return prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false)
    }

    fun setOnboardingCompleted(completed: Boolean) {
        prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, completed).apply()
    }

    fun isTermsAccepted(): Boolean {
        return prefs.getBoolean(KEY_TERMS_ACCEPTED, false)
    }

    fun setTermsAccepted(accepted: Boolean) {
        prefs.edit().putBoolean(KEY_TERMS_ACCEPTED, accepted).apply()
    }

    fun getThemeMode(): AppThemeMode {
        val name = prefs.getString(KEY_THEME_MODE, AppThemeMode.SYSTEM.name) ?: AppThemeMode.SYSTEM.name
        return try {
            AppThemeMode.valueOf(name)
        } catch (e: Exception) {
            AppThemeMode.SYSTEM
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        _themeMode.value = mode
    }

    fun getTemperatureUnit(): TemperatureUnit {
        val name = prefs.getString(KEY_TEMP_UNIT, TemperatureUnit.CELSIUS.name) ?: TemperatureUnit.CELSIUS.name
        return try {
            TemperatureUnit.valueOf(name)
        } catch (e: Exception) {
            TemperatureUnit.CELSIUS
        }
    }

    fun setTemperatureUnit(unit: TemperatureUnit) {
        prefs.edit().putString(KEY_TEMP_UNIT, unit.name).apply()
        _temperatureUnit.value = unit
    }

    fun getWindSpeedUnit(): WindSpeedUnit {
        val name = prefs.getString(KEY_WIND_UNIT, WindSpeedUnit.KMH.name) ?: WindSpeedUnit.KMH.name
        return try {
            WindSpeedUnit.valueOf(name)
        } catch (e: Exception) {
            WindSpeedUnit.KMH
        }
    }

    fun setWindSpeedUnit(unit: WindSpeedUnit) {
        prefs.edit().putString(KEY_WIND_UNIT, unit.name).apply()
    }

    fun getSelectedCity(): String {
        return prefs.getString(KEY_SELECTED_CITY, DEFAULT_CITY) ?: DEFAULT_CITY
    }

    fun setSelectedCity(cityName: String) {
        prefs.edit().putString(KEY_SELECTED_CITY, cityName).apply()
        _selectedCity.value = cityName
    }

    fun getApiKey(): String {
        return prefs.getString(KEY_API_KEY, DEFAULT_API_KEY) ?: DEFAULT_API_KEY
    }

    fun setApiKey(apiKey: String) {
        prefs.edit().putString(KEY_API_KEY, apiKey).apply()
    }

    fun areNotificationsEnabled(): Boolean {
        return prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled).apply()
    }

    fun clearAllPreferences() {
        prefs.edit().clear().apply()
        _themeMode.value = AppThemeMode.SYSTEM
        _temperatureUnit.value = TemperatureUnit.CELSIUS
        _selectedCity.value = DEFAULT_CITY
    }

    companion object {
        private const val PREFS_NAME = "weather_forcast_preferences"
        private const val KEY_ONBOARDING_COMPLETED = "key_onboarding_completed"
        private const val KEY_TERMS_ACCEPTED = "key_terms_accepted"
        private const val KEY_THEME_MODE = "key_theme_mode"
        private const val KEY_TEMP_UNIT = "key_temp_unit"
        private const val KEY_WIND_UNIT = "key_wind_unit"
        private const val KEY_SELECTED_CITY = "key_selected_city"
        private const val KEY_API_KEY = "key_api_key"
        private const val KEY_NOTIFICATIONS_ENABLED = "key_notifications_enabled"

        const val DEFAULT_CITY = "Islamabad"
        const val DEFAULT_API_KEY = "b6907d289e10d714a6e88b30761fae22" // Sample / Demo key
    }
}
