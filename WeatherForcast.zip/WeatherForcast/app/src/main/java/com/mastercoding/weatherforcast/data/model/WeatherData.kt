package com.mastercoding.weatherforcast.data.model

import androidx.compose.ui.graphics.Color
import com.mastercoding.weatherforcast.ui.theme.CloudyGray
import com.mastercoding.weatherforcast.ui.theme.RainBlue
import com.mastercoding.weatherforcast.ui.theme.SunnyYellow
import com.mastercoding.weatherforcast.ui.theme.ThunderPurple

enum class WeatherCondition(val displayName: String, val color: Color) {
    SUNNY("Sunny", SunnyYellow),
    CLOUDY("Cloudy", CloudyGray),
    RAINY("Rainy", RainBlue),
    THUNDERSTORM("Thunderstorm", ThunderPurple),
    MIST("Misty", CloudyGray),
    SNOW("Snowy", RainBlue);

    companion object {
        fun fromOpenWeather(main: String, description: String = ""): WeatherCondition {
            val lower = (main + " " + description).lowercase()
            return when {
                lower.contains("rain") || lower.contains("drizzle") -> RAINY
                lower.contains("thunder") || lower.contains("storm") -> THUNDERSTORM
                lower.contains("cloud") || lower.contains("overcast") -> CLOUDY
                lower.contains("snow") || lower.contains("sleet") -> SNOW
                lower.contains("mist") || lower.contains("fog") || lower.contains("haze") || lower.contains("smoke") -> MIST
                lower.contains("clear") || lower.contains("sun") -> SUNNY
                else -> SUNNY
            }
        }
    }
}

data class PakistanCity(
    val name: String,
    val urduName: String,
    val province: String,
    val lat: Double,
    val lon: Double,
    val isCapital: Boolean = false,
    val isFavorite: Boolean = false
)

data class HourlyForecast(
    val time: String, // e.g., "12:00 PM", "01:00 PM"
    val timestamp: Long,
    val tempC: Int,
    val condition: WeatherCondition,
    val rainProbability: Int = 0,
    val isNow: Boolean = false
)

data class DailyForecast(
    val dayOfWeek: String, // "Today", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"
    val dateText: String, // "Sep 07"
    val maxTempC: Int,
    val minTempC: Int,
    val condition: WeatherCondition,
    val description: String,
    val rainProbability: Int = 10
)

data class WeatherMetrics(
    val humidity: Int, // %
    val windSpeedKmh: Double, // km/h
    val windDirection: String, // "NE", "SW", etc.
    val uvIndex: Int, // 1 - 11
    val pressureHpa: Int, // hPa
    val visibilityKm: Double, // km
    val airQualityIndex: Int, // 1 - 5 (Good to Hazardous)
    val sunriseTime: String, // "05:48 AM"
    val sunsetTime: String // "06:32 PM"
)

data class CityWeather(
    val city: PakistanCity,
    val currentTempC: Int,
    val feelsLikeC: Int,
    val minTempC: Int,
    val maxTempC: Int,
    val condition: WeatherCondition,
    val conditionDescription: String,
    val formattedDateTime: String, // e.g., "Monday, 7 Sep 2026 • 02:30 PM PKT"
    val metrics: WeatherMetrics,
    val hourlyForecast: List<HourlyForecast>,
    val dailyForecast: List<DailyForecast>
)

object PakistanCitiesData {
    val majorCities = listOf(
        PakistanCity(
            name = "Islamabad",
            urduName = "اسلام آباد",
            province = "Islamabad Capital Territory",
            lat = 33.6844,
            lon = 73.0479,
            isCapital = true
        ),
        PakistanCity(
            name = "Lahore",
            urduName = "لاہور",
            province = "Punjab",
            lat = 31.5204,
            lon = 74.3587
        ),
        PakistanCity(
            name = "Karachi",
            urduName = "کراچی",
            province = "Sindh",
            lat = 24.8607,
            lon = 67.0011
        ),
        PakistanCity(
            name = "Rawalpindi",
            urduName = "راولپنڈی",
            province = "Punjab",
            lat = 33.5651,
            lon = 73.0169
        ),
        PakistanCity(
            name = "Peshawar",
            urduName = "پشاور",
            province = "Khyber Pakhtunkhwa",
            lat = 34.0151,
            lon = 71.5249
        ),
        PakistanCity(
            name = "Quetta",
            urduName = "کوئٹہ",
            province = "Balochistan",
            lat = 30.1798,
            lon = 66.9750
        ),
        PakistanCity(
            name = "Multan",
            urduName = "ملتان",
            province = "Punjab",
            lat = 30.1575,
            lon = 71.5249
        ),
        PakistanCity(
            name = "Faisalabad",
            urduName = "فیصل آباد",
            province = "Punjab",
            lat = 31.4504,
            lon = 73.1350
        ),
        PakistanCity(
            name = "Sialkot",
            urduName = "سیالکوٹ",
            province = "Punjab",
            lat = 32.4945,
            lon = 74.5229
        ),
        PakistanCity(
            name = "Hyderabad",
            urduName = "حیدرآباد",
            province = "Sindh",
            lat = 25.3960,
            lon = 68.3578
        ),
        PakistanCity(
            name = "Gilgit",
            urduName = "گلگت",
            province = "Gilgit-Baltistan",
            lat = 35.9221,
            lon = 74.3087
        ),
        PakistanCity(
            name = "Skardu",
            urduName = "سکردو",
            province = "Gilgit-Baltistan",
            lat = 35.2971,
            lon = 75.6333
        ),
        PakistanCity(
            name = "Gwadar",
            urduName = "گوادر",
            province = "Balochistan",
            lat = 25.1216,
            lon = 62.3254
        ),
        PakistanCity(
            name = "Murree",
            urduName = "مری",
            province = "Punjab",
            lat = 33.9070,
            lon = 73.3943
        ),
        PakistanCity(
            name = "Abbottabad",
            urduName = "ایبٹ آباد",
            province = "Khyber Pakhtunkhwa",
            lat = 34.1688,
            lon = 73.2215
        ),
        PakistanCity(
            name = "Muzaffarabad",
            urduName = "مظفرآباد",
            province = "Azad Jammu & Kashmir",
            lat = 34.3700,
            lon = 73.4711
        ),
        PakistanCity(
            name = "Bahawalpur",
            urduName = "بہاولپور",
            province = "Punjab",
            lat = 29.3544,
            lon = 71.6911
        ),
        PakistanCity(
            name = "Gujranwala",
            urduName = "گوجرانوالہ",
            province = "Punjab",
            lat = 32.1877,
            lon = 74.1945
        )
    )

    fun findCityByName(name: String): PakistanCity {
        return majorCities.firstOrNull { it.name.equals(name, ignoreCase = true) }
            ?: majorCities.first()
    }
}
