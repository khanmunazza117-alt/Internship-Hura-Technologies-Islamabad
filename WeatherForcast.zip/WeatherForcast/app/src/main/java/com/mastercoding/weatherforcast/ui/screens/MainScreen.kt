package com.mastercoding.weatherforcast.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.weatherforcast.data.model.PakistanCitiesData
import com.mastercoding.weatherforcast.ui.components.DailyForecastSection
import com.mastercoding.weatherforcast.ui.components.HeroWeatherCard
import com.mastercoding.weatherforcast.ui.components.HourlyForecastSection
import com.mastercoding.weatherforcast.ui.components.PakistanCityChip
import com.mastercoding.weatherforcast.ui.components.RateAppDialog
import com.mastercoding.weatherforcast.ui.components.ShareHelper
import com.mastercoding.weatherforcast.ui.components.WeatherMetricsSection
import com.mastercoding.weatherforcast.ui.components.formatTemp
import com.mastercoding.weatherforcast.ui.theme.PakistanGold
import com.mastercoding.weatherforcast.ui.theme.PakistanGreen
import com.mastercoding.weatherforcast.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onOpenDrawer: () -> Unit,
    onNavigateToCities: () -> Unit
) {
    val context = LocalContext.current
    val currentWeather by viewModel.currentWeather.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()
    val selectedCityName by viewModel.selectedCity.collectAsState()
    val tempUnit by viewModel.temperatureUnit.collectAsState()
    val showRateDialog by viewModel.showRateDialog.collectAsState()

    var showCityDropdown by remember { mutableStateOf(false) }

    // Rate App Dialog
    if (showRateDialog) {
        RateAppDialog(
            onDismiss = { viewModel.setShowRateDialog(false) },
            onSubmitRating = { rating ->
                // Saved / logged
            }
        )
    }

    Scaffold(
        contentWindowInsets = WindowInsets.systemBars,
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets.statusBars,
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { showCityDropdown = true }
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = selectedCityName,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = PakistanGreen,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "PK",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Pakistan • Tap to switch city",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        // City Selector Dropdown
                        DropdownMenu(
                            expanded = showCityDropdown,
                            onDismissRequest = { showCityDropdown = false }
                        ) {
                            PakistanCitiesData.majorCities.forEach { city ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = city.name,
                                                fontWeight = if (city.name == selectedCityName) FontWeight.Bold else FontWeight.Normal
                                            )
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Text(
                                                text = city.urduName,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 12.sp
                                            )
                                        }
                                    },
                                    onClick = {
                                        showCityDropdown = false
                                        viewModel.loadCityWeather(city.name)
                                    }
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu Drawer",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                },
                actions = {
                    // Cities List button
                    IconButton(onClick = onNavigateToCities) {
                        Icon(
                            imageVector = Icons.Default.LocationCity,
                            contentDescription = "All Cities",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    // Share button
                    IconButton(onClick = {
                        currentWeather?.let { w ->
                            ShareHelper.shareWeatherApp(
                                context = context,
                                cityName = w.city.name,
                                tempText = formatTemp(w.currentTempC, tempUnit),
                                condition = w.condition.displayName
                            )
                        }
                    }) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    // Refresh Button
                    IconButton(onClick = { viewModel.refreshCurrentWeather() }) {
                        if (isRefreshing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (isLoading && currentWeather == null) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    // Quick City Chips Row
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(PakistanCitiesData.majorCities.take(8)) { city ->
                                PakistanCityChip(
                                    city = city,
                                    isSelected = city.name == selectedCityName,
                                    onClick = { viewModel.loadCityWeather(city.name) }
                                )
                            }
                        }
                    }

                    // Main Weather Content
                    currentWeather?.let { weather ->
                        // Hero Weather Card
                        item {
                            HeroWeatherCard(
                                cityWeather = weather,
                                unit = tempUnit,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        }

                        // 24-Hour Forecast
                        item {
                            HourlyForecastSection(
                                hourlyList = weather.hourlyForecast,
                                unit = tempUnit,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }

                        // Weather Highlights Metrics Grid
                        item {
                            WeatherMetricsSection(
                                metrics = weather.metrics,
                                windUnit = viewModel.getWindSpeedUnit(),
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }

                        // 7-Day Forecast Section
                        item {
                            DailyForecastSection(
                                dailyList = weather.dailyForecast,
                                unit = tempUnit,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
