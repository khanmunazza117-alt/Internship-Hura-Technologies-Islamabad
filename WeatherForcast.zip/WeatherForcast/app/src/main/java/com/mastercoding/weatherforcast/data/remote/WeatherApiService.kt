package com.mastercoding.weatherforcast.data.remote

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface WeatherApiService {

    /**
     * History API Endpoint as requested:
     * https://history.openweathermap.org/data/2.5/history/city?q=Islamabad&type=hour&start=1609459200&end=1609545600&appid=YOUR_API_KEY
     */
    @GET("data/2.5/history/city")
    suspend fun getCityHistoryWeather(
        @Query("q") cityName: String = "Islamabad",
        @Query("type") type: String = "hour",
        @Query("start") startTimestamp: Long,
        @Query("end") endTimestamp: Long,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): Response<HistoryWeatherResponse>

    /**
     * Current Weather API Endpoint
     */
    @GET("data/2.5/weather")
    suspend fun getCurrentWeather(
        @Query("q") cityName: String,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): Response<CurrentWeatherResponse>

    /**
     * 5 Day / 3 Hour Forecast API Endpoint
     */
    @GET("data/2.5/forecast")
    suspend fun getFiveDayForecast(
        @Query("q") cityName: String,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): Response<ForecastResponse>
}

object ApiClient {
    private const val BASE_URL = "https://api.openweathermap.org/"
    private const val HISTORY_BASE_URL = "https://history.openweathermap.org/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    val apiService: WeatherApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(WeatherApiService::class.java)
    }

    val historyApiService: WeatherApiService by lazy {
        Retrofit.Builder()
            .baseUrl(HISTORY_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(WeatherApiService::class.java)
    }
}
