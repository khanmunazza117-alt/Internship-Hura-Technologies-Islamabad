package com.mastercoding.weatherforcast.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val PrimaryLight = Color(0xFF0288D1)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFE1F5FE)
val OnPrimaryContainerLight = Color(0xFF01579B)

val SecondaryLight = Color(0xFF00897B)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFE0F2F1)
val OnSecondaryContainerLight = Color(0xFF004D40)

val TertiaryLight = Color(0xFFF57C00)
val BackgroundLight = Color(0xFFF4F7FB)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEBF2FA)
val OnSurfaceLight = Color(0xFF1E293B)
val OnSurfaceVariantLight = Color(0xFF64748B)

// Dark Theme Palette (Sleek Glassmorphism & Midnight Skies)
val PrimaryDark = Color(0xFF38BDF8)
val OnPrimaryDark = Color(0xFF082F49)
val PrimaryContainerDark = Color(0xFF075985)
val OnPrimaryContainerDark = Color(0xFFE0F2FE)

val SecondaryDark = Color(0xFF2DD4BF)
val OnSecondaryDark = Color(0xFF134E4A)
val SecondaryContainerDark = Color(0xFF115E59)
val OnSecondaryContainerDark = Color(0xFFCCFBF1)

val TertiaryDark = Color(0xFFFBBF24)
val BackgroundDark = Color(0xFF0B132B)
val SurfaceDark = Color(0xFF1C2541)
val SurfaceVariantDark = Color(0xFF2A3756)
val OnSurfaceDark = Color(0xFFF1F5F9)
val OnSurfaceVariantDark = Color(0xFF94A3B8)

// Weather Accent Colors
val SunnyYellow = Color(0xFFFFB300)
val SunnyOrange = Color(0xFFFF7043)
val SunnyGold = Color(0xFFFFD54F)

val CloudyGray = Color(0xFF90A4AE)
val CloudDark = Color(0xFF546E7A)
val CloudLight = Color(0xFFECEFF1)

val RainBlue = Color(0xFF0288D1)
val RainCyan = Color(0xFF00E5FF)
val RainDark = Color(0xFF1565C0)

val ThunderPurple = Color(0xFF7E57C2)
val SnowWhite = Color(0xFFE0F7FA)

val PakistanGreen = Color(0xFF006633)
val PakistanGold = Color(0xFFF5A623)
val GlassCardDark = Color(0xD91C2541)
val GlassCardLight = Color(0xF2FFFFFF)
val GlassBorderDark = Color(0x3338BDF8)
val GlassBorderLight = Color(0x330288D1)