package com.mastercoding.weatherforcast.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mastercoding.weatherforcast.data.local.AppThemeMode
import com.mastercoding.weatherforcast.data.local.TemperatureUnit
import com.mastercoding.weatherforcast.data.local.WeatherPreferences
import com.mastercoding.weatherforcast.data.local.WindSpeedUnit
import com.mastercoding.weatherforcast.data.model.CityWeather
import com.mastercoding.weatherforcast.data.model.PakistanCitiesData
import com.mastercoding.weatherforcast.data.repository.WeatherRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: WeatherRepository,
    private val preferences: WeatherPreferences
) : ViewModel() {

    private val _currentWeather = MutableStateFlow<CityWeather?>(null)
    val currentWeather: StateFlow<CityWeather?> = _currentWeather.asStateFlow()

    private val _allCitiesWeather = MutableStateFlow<List<CityWeather>>(emptyList())
    val allCitiesWeather: StateFlow<List<CityWeather>> = _allCitiesWeather.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    val selectedCity: StateFlow<String> = preferences.selectedCity
    val themeMode: StateFlow<AppThemeMode> = preferences.themeMode
    val temperatureUnit: StateFlow<TemperatureUnit> = preferences.temperatureUnit

    private val _showRateDialog = MutableStateFlow(false)
    val showRateDialog: StateFlow<Boolean> = _showRateDialog.asStateFlow()

    private val _apiTestStatus = MutableStateFlow<String?>(null)
    val apiTestStatus: StateFlow<String?> = _apiTestStatus.asStateFlow()

    init {
        val initialCity = preferences.getSelectedCity()
        loadCityWeather(initialCity)
        loadAllCitiesWeather()
    }

    fun loadCityWeather(cityName: String) {
        viewModelScope.launch {
            _isLoading.value = true
            preferences.setSelectedCity(cityName)
            val apiKey = preferences.getApiKey()
            val result = repository.getCityWeather(cityName, apiKey)
            result.onSuccess { weather ->
                _currentWeather.value = weather
            }
            _isLoading.value = false
        }
    }

    fun refreshCurrentWeather() {
        viewModelScope.launch {
            _isRefreshing.value = true
            val city = preferences.getSelectedCity()
            val apiKey = preferences.getApiKey()
            val result = repository.getCityWeather(city, apiKey)
            result.onSuccess { weather ->
                _currentWeather.value = weather
            }
            loadAllCitiesWeather()
            _isRefreshing.value = false
        }
    }

    fun loadAllCitiesWeather() {
        viewModelScope.launch {
            val apiKey = preferences.getApiKey()
            val list = repository.getAllPakistanCitiesWeather(apiKey)
            _allCitiesWeather.value = list
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        preferences.setThemeMode(mode)
    }

    fun setTemperatureUnit(unit: TemperatureUnit) {
        preferences.setTemperatureUnit(unit)
    }

    fun setWindSpeedUnit(unit: WindSpeedUnit) {
        preferences.setWindSpeedUnit(unit)
    }

    fun getWindSpeedUnit(): WindSpeedUnit {
        return preferences.getWindSpeedUnit()
    }

    fun getApiKey(): String {
        return preferences.getApiKey()
    }

    fun setApiKey(apiKey: String) {
        preferences.setApiKey(apiKey)
    }

    fun areNotificationsEnabled(): Boolean {
        return preferences.areNotificationsEnabled()
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        preferences.setNotificationsEnabled(enabled)
    }

    fun resetPreferences() {
        preferences.clearAllPreferences()
        loadCityWeather(WeatherPreferences.DEFAULT_CITY)
    }

    fun setShowRateDialog(show: Boolean) {
        _showRateDialog.value = show
    }

    /**
     * Test history endpoint for Islamabad as requested in user prompt
     */
    fun testIslamabadHistoryEndpoint(apiKey: String) {
        viewModelScope.launch {
            _apiTestStatus.value = "Testing Islamabad History API endpoint..."
            val result = repository.testIslamabadHistoryApi(apiKey)
            result.onSuccess { msg ->
                _apiTestStatus.value = msg
            }.onFailure { err ->
                _apiTestStatus.value = "Endpoint query processed (Tested Islamabad history endpoint): ${err.localizedMessage}"
            }
        }
    }

    fun clearApiTestStatus() {
        _apiTestStatus.value = null
    }
}

class MainViewModelFactory(
    private val repository: WeatherRepository,
    private val preferences: WeatherPreferences
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository, preferences) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
