package com.mastercoding.weatherforcast.data.remote

import com.google.gson.annotations.SerializedName

// OpenWeather History Models
data class HistoryWeatherResponse(
    @SerializedName("message") val message: String?,
    @SerializedName("cod") val cod: String?,
    @SerializedName("city_id") val cityId: Long?,
    @SerializedName("calctime") val calcTime: Double?,
    @SerializedName("cnt") val count: Int?,
    @SerializedName("list") val list: List<HistoryItem>?
)

data class HistoryItem(
    @SerializedName("dt") val dt: Long,
    @SerializedName("main") val main: MainWeatherData?,
    @SerializedName("wind") val wind: WindData?,
    @SerializedName("clouds") val clouds: CloudData?,
    @SerializedName("weather") val weather: List<WeatherDescription>?
)

// Current Weather Models
data class CurrentWeatherResponse(
    @SerializedName("coord") val coord: CoordData?,
    @SerializedName("weather") val weather: List<WeatherDescription>?,
    @SerializedName("main") val main: MainWeatherData?,
    @SerializedName("visibility") val visibility: Int?,
    @SerializedName("wind") val wind: WindData?,
    @SerializedName("clouds") val clouds: CloudData?,
    @SerializedName("dt") val dt: Long?,
    @SerializedName("sys") val sys: SysData?,
    @SerializedName("timezone") val timezone: Int?,
    @SerializedName("id") val id: Long?,
    @SerializedName("name") val name: String?,
    @SerializedName("cod") val cod: Int?
)

// Forecast Models
data class ForecastResponse(
    @SerializedName("cod") val cod: String?,
    @SerializedName("message") val message: Int?,
    @SerializedName("cnt") val count: Int?,
    @SerializedName("list") val list: List<ForecastItem>?,
    @SerializedName("city") val city: ForecastCity?
)

data class ForecastItem(
    @SerializedName("dt") val dt: Long,
    @SerializedName("main") val main: MainWeatherData?,
    @SerializedName("weather") val weather: List<WeatherDescription>?,
    @SerializedName("clouds") val clouds: CloudData?,
    @SerializedName("wind") val wind: WindData?,
    @SerializedName("visibility") val visibility: Int?,
    @SerializedName("pop") val pop: Double?, // Probability of precipitation
    @SerializedName("dt_txt") val dtTxt: String?
)

data class ForecastCity(
    @SerializedName("id") val id: Long?,
    @SerializedName("name") val name: String?,
    @SerializedName("coord") val coord: CoordData?,
    @SerializedName("country") val country: String?,
    @SerializedName("sunrise") val sunrise: Long?,
    @SerializedName("sunset") val sunset: Long?
)

data class CoordData(
    @SerializedName("lon") val lon: Double?,
    @SerializedName("lat") val lat: Double?
)

data class MainWeatherData(
    @SerializedName("temp") val temp: Double?,
    @SerializedName("feels_like") val feelsLike: Double?,
    @SerializedName("temp_min") val tempMin: Double?,
    @SerializedName("temp_max") val tempMax: Double?,
    @SerializedName("pressure") val pressure: Int?,
    @SerializedName("humidity") val humidity: Int?
)

data class WeatherDescription(
    @SerializedName("id") val id: Int?,
    @SerializedName("main") val main: String?,
    @SerializedName("description") val description: String?,
    @SerializedName("icon") val icon: String?
)

data class WindData(
    @SerializedName("speed") val speed: Double?,
    @SerializedName("deg") val deg: Int?
)

data class CloudData(
    @SerializedName("all") val all: Int?
)

data class SysData(
    @SerializedName("country") val country: String?,
    @SerializedName("sunrise") val sunrise: Long?,
    @SerializedName("sunset") val sunset: Long?
)
