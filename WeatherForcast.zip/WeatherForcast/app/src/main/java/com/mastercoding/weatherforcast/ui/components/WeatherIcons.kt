package com.mastercoding.weatherforcast.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mastercoding.weatherforcast.data.model.WeatherCondition
import com.mastercoding.weatherforcast.ui.theme.CloudDark
import com.mastercoding.weatherforcast.ui.theme.CloudLight
import com.mastercoding.weatherforcast.ui.theme.CloudyGray
import com.mastercoding.weatherforcast.ui.theme.RainBlue
import com.mastercoding.weatherforcast.ui.theme.RainCyan
import com.mastercoding.weatherforcast.ui.theme.RainDark
import com.mastercoding.weatherforcast.ui.theme.SnowWhite
import com.mastercoding.weatherforcast.ui.theme.SunnyGold
import com.mastercoding.weatherforcast.ui.theme.SunnyOrange
import com.mastercoding.weatherforcast.ui.theme.SunnyYellow
import com.mastercoding.weatherforcast.ui.theme.ThunderPurple
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun WeatherConditionIcon(
    condition: WeatherCondition,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp,
    animate: Boolean = true
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        when (condition) {
            WeatherCondition.SUNNY -> SunnyIcon(size = size, animate = animate)
            WeatherCondition.CLOUDY -> CloudyIcon(size = size, animate = animate)
            WeatherCondition.RAINY -> RainyIcon(size = size, animate = animate)
            WeatherCondition.THUNDERSTORM -> ThunderstormIcon(size = size, animate = animate)
            WeatherCondition.MIST -> MistIcon(size = size, animate = animate)
            WeatherCondition.SNOW -> SnowIcon(size = size, animate = animate)
        }
    }
}

@Composable
fun SunnyIcon(size: Dp, animate: Boolean = true) {
    val infiniteTransition = rememberInfiniteTransition(label = "SunAnimation")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "SunRotation"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "SunPulse"
    )

    Canvas(modifier = Modifier.size(size)) {
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val radius = (this.size.minDimension / 3.4f) * (if (animate) pulse else 1f)

        // Outer Glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(SunnyGold.copy(alpha = 0.45f), Color.Transparent),
                center = center,
                radius = radius * 1.7f
            ),
            radius = radius * 1.7f,
            center = center
        )

        // Sun Rays
        val rayCount = 8
        val effectiveRotation = if (animate) rotation else 0f
        for (i in 0 until rayCount) {
            val angle = Math.toRadians((i * (360.0 / rayCount) + effectiveRotation))
            val startDist = radius * 1.25f
            val endDist = radius * 1.6f
            val startX = (center.x + cos(angle) * startDist).toFloat()
            val startY = (center.y + sin(angle) * startDist).toFloat()
            val endX = (center.x + cos(angle) * endDist).toFloat()
            val endY = (center.y + sin(angle) * endDist).toFloat()

            drawLine(
                brush = Brush.linearGradient(listOf(SunnyYellow, SunnyOrange)),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = (size.toPx() / 14f).coerceAtLeast(3f),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }

        // Sun Core
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(SunnyGold, SunnyYellow, SunnyOrange),
                center = center - Offset(radius * 0.2f, radius * 0.2f),
                radius = radius * 1.2f
            ),
            radius = radius,
            center = center
        )
    }
}

@Composable
fun CloudyIcon(size: Dp, animate: Boolean = true) {
    val infiniteTransition = rememberInfiniteTransition(label = "CloudAnimation")
    val drift by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "CloudDrift"
    )

    Canvas(modifier = Modifier.size(size)) {
        val dx = if (animate) drift else 0f

        // Back cloud (darker)
        drawCloud(
            offset = Offset(size.toPx() * 0.15f - dx, size.toPx() * 0.2f),
            scale = 0.75f,
            brush = Brush.linearGradient(listOf(CloudDark.copy(alpha = 0.5f), CloudyGray.copy(alpha = 0.6f)))
        )

        // Front cloud (lighter)
        drawCloud(
            offset = Offset(size.toPx() * 0.05f + dx, size.toPx() * 0.35f),
            scale = 0.9f,
            brush = Brush.linearGradient(listOf(CloudLight, CloudyGray))
        )
    }
}

@Composable
fun RainyIcon(size: Dp, animate: Boolean = true) {
    val infiniteTransition = rememberInfiniteTransition(label = "RainAnimation")
    val rainDropShift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RainShift"
    )

    Canvas(modifier = Modifier.size(size)) {
        // Stormy cloud
        drawCloud(
            offset = Offset(size.toPx() * 0.08f, size.toPx() * 0.2f),
            scale = 0.85f,
            brush = Brush.linearGradient(listOf(CloudDark, RainDark))
        )

        // Raindrops falling
        val dropCount = 4
        val w = this.size.width
        val h = this.size.height
        val startY = h * 0.65f
        val dropLength = h * 0.18f

        for (i in 0 until dropCount) {
            val dropX = w * (0.22f + i * 0.18f)
            val animatedOffset = if (animate) (rainDropShift * (h * 0.25f)) else 0f
            val curY = startY + ((i * 7 + animatedOffset) % (h * 0.25f))

            drawLine(
                brush = Brush.verticalGradient(listOf(RainCyan, RainBlue)),
                start = Offset(dropX, curY),
                end = Offset(dropX - w * 0.04f, curY + dropLength),
                strokeWidth = (w / 24f).coerceAtLeast(3f),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}

@Composable
fun ThunderstormIcon(size: Dp, animate: Boolean = true) {
    val infiniteTransition = rememberInfiniteTransition(label = "ThunderAnimation")
    val flash by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Flash"
    )

    Canvas(modifier = Modifier.size(size)) {
        // Deep storm cloud
        drawCloud(
            offset = Offset(size.toPx() * 0.08f, size.toPx() * 0.18f),
            scale = 0.85f,
            brush = Brush.linearGradient(listOf(ThunderPurple, CloudDark))
        )

        // Lightning bolt
        val w = this.size.width
        val h = this.size.height
        val lightningPath = Path().apply {
            moveTo(w * 0.52f, h * 0.55f)
            lineTo(w * 0.42f, h * 0.72f)
            lineTo(w * 0.50f, h * 0.72f)
            lineTo(w * 0.38f, h * 0.95f)
            lineTo(w * 0.58f, h * 0.68f)
            lineTo(w * 0.48f, h * 0.68f)
            close()
        }

        drawPath(
            path = lightningPath,
            brush = Brush.verticalGradient(
                listOf(
                    SunnyGold.copy(alpha = if (animate) flash else 1f),
                    SunnyYellow.copy(alpha = if (animate) flash else 1f)
                )
            ),
            style = Fill
        )
    }
}

@Composable
fun MistIcon(size: Dp, animate: Boolean = true) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val lineY = listOf(0.35f, 0.50f, 0.65f, 0.80f)
        val lineWidths = listOf(0.7f, 0.85f, 0.65f, 0.8f)

        lineY.forEachIndexed { index, yRatio ->
            val lw = lineWidths[index] * w
            val startX = (w - lw) / 2f
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, CloudyGray.copy(alpha = 0.8f), Color.Transparent)
                ),
                start = Offset(startX, h * yRatio),
                end = Offset(startX + lw, h * yRatio),
                strokeWidth = (h / 16f).coerceAtLeast(3f),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}

@Composable
fun SnowIcon(size: Dp, animate: Boolean = true) {
    Canvas(modifier = Modifier.size(size)) {
        // Cloud
        drawCloud(
            offset = Offset(size.toPx() * 0.08f, size.toPx() * 0.18f),
            scale = 0.85f,
            brush = Brush.linearGradient(listOf(CloudLight, CloudyGray))
        )

        // Snowflakes (small circles/stars)
        val w = this.size.width
        val h = this.size.height
        val dots = listOf(
            Offset(w * 0.28f, h * 0.72f),
            Offset(w * 0.50f, h * 0.80f),
            Offset(w * 0.72f, h * 0.70f),
            Offset(w * 0.40f, h * 0.90f),
            Offset(w * 0.62f, h * 0.92f)
        )

        dots.forEach { dot ->
            drawCircle(
                color = SnowWhite,
                radius = (w / 28f).coerceAtLeast(2.5f),
                center = dot
            )
        }
    }
}

private fun DrawScope.drawCloud(
    offset: Offset,
    scale: Float,
    brush: Brush
) {
    val cloudWidth = this.size.width * 0.75f * scale
    val cloudHeight = this.size.height * 0.45f * scale
    val x = offset.x
    val y = offset.y

    // Base pill
    drawRoundRect(
        brush = brush,
        topLeft = Offset(x, y + cloudHeight * 0.35f),
        size = Size(cloudWidth, cloudHeight * 0.65f),
        cornerRadius = CornerRadius(cloudHeight * 0.35f, cloudHeight * 0.35f)
    )

    // Left puff
    drawCircle(
        brush = brush,
        radius = cloudHeight * 0.42f,
        center = Offset(x + cloudWidth * 0.32f, y + cloudHeight * 0.45f)
    )

    // Main top puff
    drawCircle(
        brush = brush,
        radius = cloudHeight * 0.55f,
        center = Offset(x + cloudWidth * 0.58f, y + cloudHeight * 0.38f)
    )
}
