package com.mastercoding.weatherforcast

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mastercoding.weatherforcast.data.local.AppThemeMode
import com.mastercoding.weatherforcast.data.local.WeatherPreferences
import com.mastercoding.weatherforcast.data.repository.WeatherRepository
import com.mastercoding.weatherforcast.ui.components.AppDrawerContent
import com.mastercoding.weatherforcast.ui.components.ShareHelper
import com.mastercoding.weatherforcast.ui.components.formatTemp
import com.mastercoding.weatherforcast.ui.screens.CitiesScreen
import com.mastercoding.weatherforcast.ui.screens.MainScreen
import com.mastercoding.weatherforcast.ui.screens.MapScreen
import com.mastercoding.weatherforcast.ui.screens.OnboardingScreen
import com.mastercoding.weatherforcast.ui.screens.PrivacyPolicyScreen
import com.mastercoding.weatherforcast.ui.screens.SplashScreen
import com.mastercoding.weatherforcast.ui.screens.TermsScreen
import com.mastercoding.weatherforcast.ui.theme.WeatherForcastTheme
import com.mastercoding.weatherforcast.ui.viewmodel.MainViewModel
import com.mastercoding.weatherforcast.ui.viewmodel.MainViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val preferences = WeatherPreferences(applicationContext)
        val repository = WeatherRepository()

        setContent {
            WeatherAppRoot(
                preferences = preferences,
                repository = repository
            )
        }
    }
}

@Composable
fun WeatherAppRoot(
    preferences: WeatherPreferences,
    repository: WeatherRepository
) {
    val context = LocalContext.current
    val viewModel: MainViewModel = viewModel(
        factory = MainViewModelFactory(repository, preferences)
    )

    val currentThemeMode by viewModel.themeMode.collectAsState()
    val isDarkTheme = when (currentThemeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    WeatherForcastTheme(darkTheme = isDarkTheme) {
        val navController = rememberNavController()
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val coroutineScope = rememberCoroutineScope()

        val currentCity by viewModel.selectedCity.collectAsState()
        val currentWeather by viewModel.currentWeather.collectAsState()
        val tempUnit by viewModel.temperatureUnit.collectAsState()

        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route ?: "splash"

        // Debug hook: `adb shell am start -n .../.MainActivity --ez open_map true`
        // opens the map screen without any UI interaction.
        val openMap = (context as? android.app.Activity)?.intent?.getBooleanExtra("open_map", false) == true
        LaunchedEffect(currentRoute, openMap) {
            if (openMap && currentRoute == "main") {
                navController.navigate("map") { launchSingleTop = true }
            }
        }

        // Smart Back Navigation Handling:
        // 1. If drawer is open -> Close drawer
        // 2. If user is in a sub-screen (cities, settings, privacy, terms_view) -> Back goes to main screen instead of exiting app
        BackHandler(enabled = drawerState.isOpen) {
            coroutineScope.launch {
                drawerState.close()
            }
        }

        BackHandler(
            enabled = !drawerState.isOpen && currentRoute in listOf("cities", "settings", "privacy", "terms_view", "map")
        ) {
            navController.navigate("main") {
                popUpTo("main") { inclusive = false }
                launchSingleTop = true
            }
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = false,
            drawerContent = {
                AppDrawerContent(
                    currentRoute = currentRoute,
                    selectedCity = currentCity,
                    onNavigate = { route ->
                        coroutineScope.launch {
                            drawerState.close()
                        }
                        if (route != currentRoute) {
                            navController.navigate(route) {
                                popUpTo("main") { inclusive = (route == "main") }
                                launchSingleTop = true
                            }
                        }
                    },
                    onRateClick = {
                        coroutineScope.launch {
                            drawerState.close()
                        }
                        viewModel.setShowRateDialog(true)
                    },
                    onShareClick = {
                        coroutineScope.launch {
                            drawerState.close()
                        }
                        currentWeather?.let { w ->
                            ShareHelper.shareWeatherApp(
                                context = context,
                                cityName = w.city.name,
                                tempText = formatTemp(w.currentTempC, tempUnit),
                                condition = w.condition.displayName
                            )
                        } ?: run {
                            ShareHelper.shareWeatherApp(context = context)
                        }
                    }
                )
            }
        ) {
            NavHost(
                navController = navController,
                startDestination = "splash",
                modifier = Modifier.fillMaxSize()
            ) {
                // Splash Screen
                composable("splash") {
                    SplashScreen(
                        preferences = preferences,
                        onNavigateToOnboarding = {
                            navController.navigate("onboarding") {
                                popUpTo("splash") { inclusive = true }
                            }
                        },
                        onNavigateToTerms = {
                            navController.navigate("terms") {
                                popUpTo("splash") { inclusive = true }
                            }
                        },
                        onNavigateToMain = {
                            navController.navigate("main") {
                                popUpTo("splash") { inclusive = true }
                            }
                        }
                    )
                }

                // Onboarding Screen (3 slides)
                composable("onboarding") {
                    OnboardingScreen(
                        preferences = preferences,
                        onFinishOnboarding = {
                            navController.navigate("terms") {
                                popUpTo("onboarding") { inclusive = true }
                            }
                        }
                    )
                }

                // Terms Acceptance Screen (First launch)
                composable("terms") {
                    TermsScreen(
                        preferences = preferences,
                        isViewOnly = false,
                        onAcceptAndContinue = {
                            navController.navigate("main") {
                                popUpTo("terms") { inclusive = true }
                            }
                        }
                    )
                }

                // Terms Screen (View-only from drawer/settings)
                composable("terms_view") {
                    TermsScreen(
                        preferences = preferences,
                        isViewOnly = true,
                        onAcceptAndContinue = {},
                        onBack = {
                            navController.navigate("main") {
                                popUpTo("main") { inclusive = false }
                            }
                        }
                    )
                }

                // Main Weather Dashboard
                composable("main") {
                    MainScreen(
                        viewModel = viewModel,
                        onOpenDrawer = {
                            coroutineScope.launch {
                                drawerState.open()
                            }
                        },
                        onNavigateToCities = {
                            navController.navigate("cities")
                        }
                    )
                }

                // Pakistani Cities Screen
                composable("cities") {
                    CitiesScreen(
                        viewModel = viewModel,
                        onCitySelected = { _ ->
                            navController.navigate("main") {
                                popUpTo("main") { inclusive = false }
                                launchSingleTop = true
                            }
                        },
                        onBack = {
                            navController.navigate("main") {
                                popUpTo("main") { inclusive = false }
                            }
                        }
                    )
                }

                // Weather Map Screen
                composable("map") {
                    MapScreen(
                        viewModel = viewModel,
                        onCitySelected = { cityName ->
                            viewModel.loadCityWeather(cityName)
                        },
                        onBack = {
                            navController.navigate("main") {
                                popUpTo("main") { inclusive = false }
                            }
                        }
                    )
                }

                // Settings Screen
                composable("settings") {
                    com.mastercoding.weatherforcast.ui.screens.SettingsScreen(
                        viewModel = viewModel,
                        onBack = {
                            navController.navigate("main") {
                                popUpTo("main") { inclusive = false }
                            }
                        }
                    )
                }

                // Privacy Policy Screen
                composable("privacy") {
                    PrivacyPolicyScreen(
                        onBack = {
                            navController.navigate("main") {
                                popUpTo("main") { inclusive = false }
                            }
                        }
                    )
                }
            }
        }
    }
}
