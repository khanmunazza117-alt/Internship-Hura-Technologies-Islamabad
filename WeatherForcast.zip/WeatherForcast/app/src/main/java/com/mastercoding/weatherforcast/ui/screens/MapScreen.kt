package com.mastercoding.weatherforcast.ui.screens

import android.graphics.Color as AndroidColor
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point
import com.mastercoding.weatherforcast.data.local.TemperatureUnit
import com.mastercoding.weatherforcast.data.model.CityWeather
import com.mastercoding.weatherforcast.data.model.WeatherCondition
import com.mastercoding.weatherforcast.ui.components.formatTemp
import com.mastercoding.weatherforcast.ui.theme.CloudyGray
import com.mastercoding.weatherforcast.ui.theme.RainBlue
import com.mastercoding.weatherforcast.ui.theme.SunnyYellow
import com.mastercoding.weatherforcast.ui.theme.ThunderPurple
import com.mastercoding.weatherforcast.ui.viewmodel.MainViewModel
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "WeatherMap"
private const val MAX_STYLE_ATTEMPTS = 4
private const val STYLE_LOAD_TIMEOUT_MS = 15000L
private const val MAP_STYLE_URL = "https://tiles.openfreemap.org/styles/liberty"
private const val FALLBACK_STYLE_URL = "https://basemaps.cartocdn.com/gl/positron-gl-style/style.json"

private const val CITIES_SOURCE_ID = "pakistan-cities-source"
private const val SELECTED_SOURCE_ID = "selected-city-source"
private const val SELECTED_CIRCLE_ID = "selected-city-circle"
private const val CITIES_LABEL_ID = "pakistan-cities-label"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    viewModel: MainViewModel,
    onCitySelected: (String) -> Unit,
    onBack: () -> Unit
) {
    val allCitiesWeather by viewModel.allCitiesWeather.collectAsState()
    val tempUnit by viewModel.temperatureUnit.collectAsState()
    val selectedCityName by viewModel.selectedCity.collectAsState()

    val lifeCycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current

    var mapView by remember { mutableStateOf<MapView?>(null) }
    var style by remember { mutableStateOf<Style?>(null) }
    var mapStatus by remember { mutableStateOf("0: creating map view...") }
    // Single-shot guard: only the first getMapAsync callback may proceed.
    val initReady = remember { AtomicBoolean(false) }

    // Initialize MapLibre once with the application context
    remember {
        MapLibre.getInstance(context.applicationContext)
    }

    // Reactive re-apply of markers when data/unit/selection change. The initial
    // load is applied directly in the style callback. This effect mainly covers
    // later updates (temp unit toggle, refresh, selection changes).
    LaunchedEffect(style, allCitiesWeather, selectedCityName, tempUnit) {
        val loadedStyle = style ?: return@LaunchedEffect
        mapStatus = "4.5: starting apply"
        applyCityData(loadedStyle, allCitiesWeather, selectedCityName, tempUnit) { s -> mapStatus = s }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Map fills the entire screen (edge-to-edge, behind system bars)
        AndroidView(
            factory = { ctx ->
                // textureMode(true): use the TextureView renderer (app-managed GL
                // thread) instead of the default SurfaceView renderer. The
                // SurfaceView path stalls/fails map creation on some PowerVR ROMs.
                MapView(ctx, MapLibreMapOptions.createFromAttributes(ctx).textureMode(true)).apply {
                    mapView = this
                    mapStatus = "1: map view created (texture)"
                    onCreate(null)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Map lifecycle: observe future events AND sync the current state, then
        // start the map after the view is attached and drawn.
        //
        // Without the sync, a MapScreen reached via navigation never receives
        // ON_START/ON_RESUME (the activity is already resumed), so the native
        // map never starts and getMapAsync never fires.
        DisposableEffect(lifeCycleOwner, mapView) {
            val lifecycle = lifeCycleOwner.lifecycle
            val observer = LifecycleEventObserver { _, event ->
                val mv = mapView ?: return@LifecycleEventObserver
                when (event) {
                    Lifecycle.Event.ON_START -> mv.onStart()
                    Lifecycle.Event.ON_RESUME -> mv.onResume()
                    Lifecycle.Event.ON_PAUSE -> mv.onPause()
                    Lifecycle.Event.ON_STOP -> mv.onStop()
                    Lifecycle.Event.ON_DESTROY -> mv.onDestroy()
                    else -> {}
                }
            }
            lifecycle.addObserver(observer)

            val mv = mapView
            if (mv != null) {
                var started = false
                var resumed = false
                fun syncState() {
                    when (lifecycle.currentState) {
                        Lifecycle.State.RESUMED -> {
                            if (!started) { started = true; mv.onStart() }
                            if (!resumed) { resumed = true; mv.onResume() }
                        }
                        Lifecycle.State.STARTED -> {
                            if (!started) { started = true; mv.onStart() }
                        }
                        else -> {}
                    }
                }
                syncState()
                if (mv.isAttachedToWindow) {
                    // The view is attached. Note: a pre-attach onStart() is
                    // DEFERRED by MapLibre (map creation only happens while
                    // attached) and is never re-run on its own, so onStart must
                    // be called again now together with onResume. Both calls are
                    // idempotent. Then fetch the map; retry at increasing delays
                    // in case the native map is not ready yet.
                    val v = mv
                    fun startAndFetch() {
                        val attached = v.isAttachedToWindow
                        val state = lifeCycleOwner.lifecycle.currentState
                        Log.w(TAG, "startAndFetch attached=$attached state=$state w=${v.width}h=${v.height}")
                        mapStatus = "1.95: resume after attach + getMapAsync attached=$attached"
                        // Do NOT re-run onStart: a second onStart destabilizes the
                        // native engine. The initial onStart ran during the state
                        // sync; MapLibre completes map creation once the view is
                        // attached. Only resume again now that the surface exists.
                        v.onResume()
                        setupMap(v, onCitySelected, initReady, { s -> mapStatus = s }) { loadedStyle ->
                            style = loadedStyle
                            applyLoadedStyle(loadedStyle, allCitiesWeather, selectedCityName, tempUnit, { s -> mapStatus = s })
                        }
                    }
                    v.postDelayed({
                        startAndFetch()
                        val retryDelays = longArrayOf(3000, 5000, 8000, 12000, 18000)
                        retryDelays.forEach { delay ->
                            v.postDelayed({
                                if (!initReady.get()) {
                                    val attached = v.isAttachedToWindow
                                    val state = lifeCycleOwner.lifecycle.currentState
                                    mapStatus = "2.5: retry($delay) attached=$attached st=$state"
                                    startAndFetch()
                                }
                            }, delay)
                        }
                    }, 800)
                }
            }

            onDispose {
                lifecycle.removeObserver(observer)
                mapView?.onDestroy()
                mapView = null
            }
        }

        // Overlay UI (inset-aware over the edge-to-edge map)
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
                windowInsets = WindowInsets.statusBars,
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Map,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Weather Map",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Main"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )

            // Map overlay area: legend on top; temporary debug status
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                WeatherLegend(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                )
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "DBG: $mapStatus",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Bottom info bar (padded above the navigation bar)
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "Tap a marker to make it your active city",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                    Text(
                        text = "Selected: $selectedCityName • ${allCitiesWeather.size} Pakistani cities",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    }
}

/**
 * Registers the map-ready callback. Because this SDK version drops callbacks
 * registered before the native map is ready instead of queueing them, callers
 * poll this method until the [initReady] flag flips; the winning callback then
 * proceeds exactly once.
 */
private fun setupMap(
    mapView: MapView,
    onCitySelected: (String) -> Unit,
    initReady: AtomicBoolean,
    status: (String) -> Unit,
    onStyle: (Style?) -> Unit
) {
    status("2: getMapAsync about to be called")
    try {
        mapView.getMapAsync { map ->
            if (!initReady.compareAndSet(false, true)) return@getMapAsync
            status("3: getMapAsync fired - loading style")
            try {
                map.addOnMapClickListener { latLng ->
                    val screenPoint = map.projection.toScreenLocation(latLng)
                    val allLayerIds = WeatherCondition.entries.map { conditionLayerId(it) } + SELECTED_CIRCLE_ID
                    val tapped = map.queryRenderedFeatures(
                        screenPoint,
                        *allLayerIds.toTypedArray()
                    )
                    if (tapped.isNotEmpty()) {
                        val name = tapped.first().getStringProperty("name")
                        if (!name.isNullOrEmpty()) {
                            onCitySelected(name)
                            true
                        } else false
                    } else false
                }
            } catch (t: Throwable) {
                status("3C: click listener failed " + t.javaClass.simpleName)
            }
            loadMapStyle(map, onStyle)
        }
    } catch (t: Throwable) {
        status("2X: getMapAsync threw " + t.javaClass.simpleName)
    }
}

private fun applyLoadedStyle(
    loadedStyle: Style?,
    cities: List<CityWeather>,
    selectedCityName: String,
    tempUnit: TemperatureUnit,
    status: (String) -> Unit
) {
    if (loadedStyle == null) {
        status("4: style load FAILED")
        return
    }
    status("4: style loaded - applying markers")
    try {
        applyCityData(loadedStyle, cities, selectedCityName, tempUnit, status)
    } catch (t: Throwable) {
        status("5X: apply failed " + t.javaClass.simpleName)
    }
}

/**
 * Loads a base style, retrying with a fallback URL if the load never completes.
 * This SDK version has no style-error callback, so a watchdog timer drives retries.
 */
private fun loadMapStyle(map: MapLibreMap, styleHolder: (Style?) -> Unit) {
    val accepted = AtomicBoolean(false)
    val handler = Handler(Looper.getMainLooper())

    fun tryLoad(attempt: Int) {
        val uri = if (attempt % 2 == 0) MAP_STYLE_URL else FALLBACK_STYLE_URL
        Log.d(TAG, "Attempting style load (attempt $attempt): $uri")
        val watchdog = Runnable {
            if (accepted.get()) return@Runnable
            Log.d(TAG, "Style load timed out (attempt $attempt): $uri")
            if (attempt < MAX_STYLE_ATTEMPTS - 1) {
                tryLoad(attempt + 1)
            } else {
                Log.e(TAG, "All style attempts timed out.")
                styleHolder(null)
            }
        }
        handler.postDelayed(watchdog, STYLE_LOAD_TIMEOUT_MS)
        map.setStyle(Style.Builder().fromUri(uri)) { loadedStyle ->
            if (accepted.compareAndSet(false, true)) {
                handler.removeCallbacks(watchdog)
                Log.d(TAG, "Style loaded: $uri")
                centerOnPakistan(map)
                styleHolder(loadedStyle)
            }
        }
    }

    tryLoad(0)
}

private fun centerOnPakistan(map: MapLibreMap) {
    map.animateCamera(
        CameraUpdateFactory.newLatLngZoom(
            LatLng(30.3753, 69.3451),
            5.5
        )
    )
}

@Composable
private fun WeatherLegend(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            LegendDot(SunnyYellow, "Sunny")
            Spacer(modifier = Modifier.height(4.dp))
            LegendDot(CloudyGray, "Cloudy / Mist")
            Spacer(modifier = Modifier.height(4.dp))
            LegendDot(RainBlue, "Rain / Snow")
            Spacer(modifier = Modifier.height(4.dp))
            LegendDot(ThunderPurple, "Thunderstorm")
            Spacer(modifier = Modifier.height(4.dp))
            LegendDot(Color(0xFF0288D1), "Selected City")
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(11.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = label, fontSize = 11.sp)
    }
}

/**
 * Adds the marker sources/layers if they are missing, then pushes the current
 * city data into the sources. Each layer/source is guarded independently so a
 * single failure can never permanently block markers.
 */
private fun applyCityData(
    style: Style,
    cities: List<CityWeather>,
    selectedCityName: String,
    tempUnit: TemperatureUnit,
    status: (String) -> Unit
) {
    ensureCityLayers(style)
    status("5: applying ${cities.size} markers (style loaded)")
    Log.d(TAG, "Applying ${cities.size} city markers; selected=$selectedCityName; unit=$tempUnit")

    val features = cities.map { cityFeature(it, tempUnit) }
    (style.getSource(CITIES_SOURCE_ID) as? GeoJsonSource)?.setGeoJson(
        FeatureCollection.fromFeatures(features)
    )

    val selected = cities.firstOrNull { it.city.name == selectedCityName }
    val selectedFeatures = if (selected != null) listOf(cityFeature(selected, tempUnit)) else emptyList()
    (style.getSource(SELECTED_SOURCE_ID) as? GeoJsonSource)?.setGeoJson(
        FeatureCollection.fromFeatures(selectedFeatures)
    )
}

private fun ensureCityLayers(style: Style) {
    if (style.getSource(CITIES_SOURCE_ID) == null) {
        style.addSource(GeoJsonSource(CITIES_SOURCE_ID, FeatureCollection.fromFeatures(emptyList())))
    }
    if (style.getSource(SELECTED_SOURCE_ID) == null) {
        style.addSource(GeoJsonSource(SELECTED_SOURCE_ID, FeatureCollection.fromFeatures(emptyList())))
    }

    WeatherCondition.entries.forEach { condition ->
        val layerId = conditionLayerId(condition)
        if (style.getLayer(layerId) == null) {
            val layer = CircleLayer(layerId, CITIES_SOURCE_ID)
                .withProperties(
                    PropertyFactory.circleRadius(10f),
                    PropertyFactory.circleColor(Expression.color(conditionColor(condition))),
                    PropertyFactory.circleStrokeColor(AndroidColor.WHITE),
                    PropertyFactory.circleStrokeWidth(2f)
                )
                .withFilter(Expression.eq(Expression.get("condition"), Expression.literal(condition.name)))
            style.addLayer(layer)
        }
    }

    if (style.getLayer(SELECTED_CIRCLE_ID) == null) {
        style.addLayer(
            CircleLayer(SELECTED_CIRCLE_ID, SELECTED_SOURCE_ID).withProperties(
                PropertyFactory.circleRadius(17f),
                PropertyFactory.circleColor(Expression.color(0xFF0288D1.toInt())),
                PropertyFactory.circleStrokeColor(AndroidColor.WHITE),
                PropertyFactory.circleStrokeWidth(3f)
            )
        )
    }

    if (style.getLayer(CITIES_LABEL_ID) == null) {
        style.addLayer(
            SymbolLayer(CITIES_LABEL_ID, CITIES_SOURCE_ID).withProperties(
                PropertyFactory.textField(Expression.get("label")),
                PropertyFactory.textSize(12f),
                PropertyFactory.textColor(0xFF1E293B.toInt()),
                PropertyFactory.textHaloColor(AndroidColor.WHITE),
                PropertyFactory.textHaloWidth(1.5f),
                PropertyFactory.textAnchor(Property.TEXT_ANCHOR_TOP),
                PropertyFactory.textOffset(arrayOf(0f, 1.2f)),
                PropertyFactory.textAllowOverlap(true),
                PropertyFactory.textIgnorePlacement(true)
            )
        )
    }
}

private fun conditionLayerId(condition: WeatherCondition): String = "city-circle-${condition.name}"

private fun conditionColor(condition: WeatherCondition): Int = when (condition) {
    WeatherCondition.SUNNY -> SunnyYellow.toArgb()
    WeatherCondition.CLOUDY -> CloudyGray.toArgb()
    WeatherCondition.MIST -> CloudyGray.toArgb()
    WeatherCondition.RAINY -> RainBlue.toArgb()
    WeatherCondition.SNOW -> RainBlue.toArgb()
    WeatherCondition.THUNDERSTORM -> ThunderPurple.toArgb()
}

private fun cityFeature(cw: CityWeather, tempUnit: TemperatureUnit): Feature {
    return Feature.fromGeometry(Point.fromLngLat(cw.city.lon, cw.city.lat)).apply {
        addStringProperty("name", cw.city.name)
        addStringProperty("condition", cw.condition.name)
        addStringProperty("label", "${cw.city.name}\n${formatTemp(cw.currentTempC, tempUnit)}")
    }
}