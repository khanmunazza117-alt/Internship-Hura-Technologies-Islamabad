package com.mastercoding.weatherforcast.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.weatherforcast.data.local.TemperatureUnit
import com.mastercoding.weatherforcast.data.local.WindSpeedUnit
import com.mastercoding.weatherforcast.data.model.CityWeather
import com.mastercoding.weatherforcast.data.model.DailyForecast
import com.mastercoding.weatherforcast.data.model.HourlyForecast
import com.mastercoding.weatherforcast.data.model.PakistanCity
import com.mastercoding.weatherforcast.data.model.WeatherCondition
import com.mastercoding.weatherforcast.data.model.WeatherMetrics
import com.mastercoding.weatherforcast.ui.theme.PakistanGreen

fun formatTemp(celsius: Int, unit: TemperatureUnit): String {
    return when (unit) {
        TemperatureUnit.CELSIUS -> "$celsius°C"
        TemperatureUnit.FAHRENHEIT -> "${(celsius * 9 / 5) + 32}°F"
    }
}

fun formatWind(kmh: Double, unit: WindSpeedUnit): String {
    return when (unit) {
        WindSpeedUnit.KMH -> "${String.format("%.1f", kmh)} km/h"
        WindSpeedUnit.MS -> "${String.format("%.1f", kmh / 3.6)} m/s"
        WindSpeedUnit.MPH -> "${String.format("%.1f", kmh * 0.621371)} mph"
    }
}

@Composable
fun HeroWeatherCard(
    cityWeather: CityWeather,
    unit: TemperatureUnit,
    modifier: Modifier = Modifier
) {
    val gradientBrush = when (cityWeather.condition) {
        WeatherCondition.SUNNY -> Brush.verticalGradient(
            listOf(Color(0xFF0288D1), Color(0xFF03A9F4), Color(0xFFFFB300).copy(alpha = 0.8f))
        )
        WeatherCondition.CLOUDY -> Brush.verticalGradient(
            listOf(Color(0xFF37474F), Color(0xFF546E7A), Color(0xFF78909C))
        )
        WeatherCondition.RAINY -> Brush.verticalGradient(
            listOf(Color(0xFF1565C0), Color(0xFF0277BD), Color(0xFF00838F))
        )
        WeatherCondition.THUNDERSTORM -> Brush.verticalGradient(
            listOf(Color(0xFF311B92), Color(0xFF4527A0), Color(0xFF283593))
        )
        WeatherCondition.SNOW -> Brush.verticalGradient(
            listOf(Color(0xFF006064), Color(0xFF00838F), Color(0xFF0097A7))
        )
        WeatherCondition.MIST -> Brush.verticalGradient(
            listOf(Color(0xFF455A64), Color(0xFF607D8B), Color(0xFF90A4AE))
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(28.dp)),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(gradientBrush)
                .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(28.dp))
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // City & Province Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = cityWeather.city.name,
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            if (cityWeather.city.isCapital) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = PakistanGreen,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.padding(2.dp)
                                ) {
                                    Text(
                                        text = "Capital",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "${cityWeather.city.urduName} • ${cityWeather.city.province}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White.copy(alpha = 0.85f)
                            ),
                            modifier = Modifier.padding(start = 28.dp)
                        )
                    }

                    // Condition Badge
                    Surface(
                        color = Color.White.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    ) {
                        Text(
                            text = cityWeather.condition.displayName,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Center Main Weather Temp & Visual
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = formatTemp(cityWeather.currentTempC, unit),
                            fontSize = 64.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            lineHeight = 64.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = cityWeather.conditionDescription,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Feels like ${formatTemp(cityWeather.feelsLikeC, unit)}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "H: ${formatTemp(cityWeather.maxTempC, unit)}  L: ${formatTemp(cityWeather.minTempC, unit)}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }

                    // Animated Weather Icon
                    WeatherConditionIcon(
                        condition = cityWeather.condition,
                        size = 96.dp,
                        animate = true
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Date & Time Footer
                Surface(
                    color = Color.Black.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = cityWeather.formattedDateTime,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HourlyForecastSection(
    hourlyList: List<HourlyForecast>,
    unit: TemperatureUnit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "24-Hour Forecast",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            ),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(hourlyList) { item ->
                HourlyItemCard(item = item, unit = unit)
            }
        }
    }
}

@Composable
fun HourlyItemCard(
    item: HourlyForecast,
    unit: TemperatureUnit
) {
    val isHighlighted = item.isNow
    val cardBackground = if (isHighlighted) {
        Brush.verticalGradient(
            listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primaryContainer)
        )
    } else {
        Brush.verticalGradient(
            listOf(
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
        )
    }

    val contentColor = if (isHighlighted) Color.White else MaterialTheme.colorScheme.onSurfaceVariant

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier
            .width(86.dp)
            .border(
                width = if (isHighlighted) 1.5.dp else 1.dp,
                color = if (isHighlighted) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.1f),
                shape = RoundedCornerShape(20.dp)
            )
    ) {
        Box(
            modifier = Modifier
                .background(cardBackground)
                .padding(vertical = 14.dp, horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = item.time,
                    fontSize = 12.sp,
                    fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Medium,
                    color = contentColor
                )

                Spacer(modifier = Modifier.height(10.dp))

                WeatherConditionIcon(
                    condition = item.condition,
                    size = 36.dp,
                    animate = false
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = formatTemp(item.tempC, unit),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = contentColor
                )

                if (item.rainProbability > 20) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = null,
                            tint = if (isHighlighted) Color.White.copy(alpha = 0.9f) else Color(0xFF0288D1),
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = "${item.rainProbability}%",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isHighlighted) Color.White.copy(alpha = 0.9f) else Color(0xFF0288D1)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DailyForecastSection(
    dailyList: List<DailyForecast>,
    unit: TemperatureUnit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "7-Day Forecast",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = "High / Low",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            dailyList.forEachIndexed { index, daily ->
                DailyForecastRow(daily = daily, unit = unit)
                if (index < dailyList.size - 1) {
                    Spacer(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            .padding(vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DailyForecastRow(
    daily: DailyForecast,
    unit: TemperatureUnit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Day name & date
        Column(modifier = Modifier.width(80.dp)) {
            Text(
                text = daily.dayOfWeek,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = daily.dateText,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Icon & Condition
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.width(110.dp)
        ) {
            WeatherConditionIcon(
                condition = daily.condition,
                size = 28.dp,
                animate = false
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = daily.condition.displayName,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // Temp Span Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End
        ) {
            Text(
                text = formatTemp(daily.minTempC, unit),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .width(60.dp)
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF4FC3F7), Color(0xFFFFB300), Color(0xFFFF7043))
                        )
                    )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = formatTemp(daily.maxTempC, unit),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun WeatherMetricsSection(
    metrics: WeatherMetrics,
    windUnit: WindSpeedUnit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Weather Highlights",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            ),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "Humidity",
                value = "${metrics.humidity}%",
                subtitle = if (metrics.humidity > 70) "Humid & sticky" else "Comfortable",
                icon = Icons.Default.WaterDrop,
                iconTint = Color(0xFF0288D1),
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "Wind",
                value = formatWind(metrics.windSpeedKmh, windUnit),
                subtitle = "Direction ${metrics.windDirection}",
                icon = Icons.Default.Air,
                iconTint = Color(0xFF26A69A),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "UV Index",
                value = "${metrics.uvIndex}",
                subtitle = when {
                    metrics.uvIndex >= 8 -> "Very High - Protect"
                    metrics.uvIndex >= 6 -> "High - Wear sunscreen"
                    else -> "Moderate / Safe"
                },
                icon = Icons.Default.WbSunny,
                iconTint = Color(0xFFFFB300),
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "Pressure",
                value = "${metrics.pressureHpa} hPa",
                subtitle = "Normal atmospheric",
                icon = Icons.Default.Compress,
                iconTint = Color(0xFF7E57C2),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "Visibility",
                value = "${String.format("%.1f", metrics.visibilityKm)} km",
                subtitle = if (metrics.visibilityKm >= 9) "Clear visibility" else "Hazy / Foggy",
                icon = Icons.Default.Visibility,
                iconTint = Color(0xFF00BCD4),
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "Sun Cycle",
                value = metrics.sunriseTime,
                subtitle = "Sunset: ${metrics.sunsetTime}",
                icon = Icons.Default.WbTwilight,
                iconTint = Color(0xFFFF7043),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(iconTint.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun PakistanCityChip(
    city: PakistanCity,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = Modifier
            .border(
                1.dp,
                if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                RoundedCornerShape(16.dp)
            )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(
                text = city.name,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 13.sp,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
            )
            if (city.isCapital) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) Color.White else PakistanGreen)
                )
            }
        }
    }
}
