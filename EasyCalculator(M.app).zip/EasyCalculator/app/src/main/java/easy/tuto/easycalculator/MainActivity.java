package easy.tuto.easycalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView solutionTv, resultTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        solutionTv = findViewById(R.id.solution_tv);
        resultTv = findViewById(R.id.result_tv);

        int[] ids = {
                R.id.button_c,
                R.id.button_open_bracket,
                R.id.button_close_bracket,
                R.id.button_divide,
                R.id.button_7,
                R.id.button_8,
                R.id.button_9,
                R.id.button_multiply,
                R.id.button_4,
                R.id.button_5,
                R.id.button_6,
                R.id.button_minus,
                R.id.button_1,
                R.id.button_2,
                R.id.button_3,
                R.id.button_plus,
                R.id.button_dot,
                R.id.button_0,
                R.id.button_equal
        };

        for (int id : ids) {
            MaterialButton btn = findViewById(id);
            btn.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {

        MaterialButton button = (MaterialButton) view;
        String buttonText = button.getText().toString();

        String data = solutionTv.getText().toString();

        if (buttonText.equals("C")) {
            solutionTv.setText("");
            resultTv.setText("0");
            return;
        }

        if (buttonText.equals("=")) {

            try {

                String expression = data;

                expression = expression.replace("×", "*");
                expression = expression.replace("/", "/");

                double result = simpleCalculate(expression);

                if (result == (long) result) {
                    resultTv.setText(String.valueOf((long) result));
                } else {
                    resultTv.setText(String.valueOf(result));
                }

            } catch (Exception e) {
                resultTv.setText("Error");
            }

            return;
        }

        data = data + buttonText;
        solutionTv.setText(data);
    }

    private double simpleCalculate(String expression) {

        if (expression.contains("+")) {
            String[] arr = expression.split("\\+");
            return Double.parseDouble(arr[0]) + Double.parseDouble(arr[1]);
        }

        if (expression.contains("-")) {
            String[] arr = expression.split("-");
            return Double.parseDouble(arr[0]) - Double.parseDouble(arr[1]);
        }

        if (expression.contains("*")) {
            String[] arr = expression.split("\\*");
            return Double.parseDouble(arr[0]) * Double.parseDouble(arr[1]);
        }

        if (expression.contains("/")) {
            String[] arr = expression.split("/");
            return Double.parseDouble(arr[0]) / Double.parseDouble(arr[1]);
        }

        return Double.parseDouble(expression);
    }
}