package com.mastercoding.reversevideoresearch.ui.screens

import android.net.Uri
import android.view.LayoutInflater
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.data.HistoryItem
import com.mastercoding.reversevideoresearch.data.HistoryRepository
import com.mastercoding.reversevideoresearch.data.MediaUtils
import com.mastercoding.reversevideoresearch.data.SearchHelper
import com.mastercoding.reversevideoresearch.ui.components.BottomBarSpacer
import com.mastercoding.reversevideoresearch.ui.components.CropOverlay
import com.mastercoding.reversevideoresearch.ui.components.PrimaryButton
import com.mastercoding.reversevideoresearch.ui.components.ScreenHeader
import com.mastercoding.reversevideoresearch.ui.components.WhiteCard
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLight
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(UnstableApi::class)
@Composable
fun MediaEditScreen(
    path: String,
    isVideo: Boolean,
    title: String,
    history: HistoryRepository,
    onSearchReady: (query: String, imagePath: String, type: String) -> Unit,
    onBack: () -> Unit
) {
    ReverseVideoResearchTheme {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        var rotation by remember { mutableFloatStateOf(0f) }
        var flipH by remember { mutableStateOf(false) }
        var cropping by remember { mutableStateOf(false) }
        var crop by remember { mutableStateOf(Rect(0.12f, 0.12f, 0.88f, 0.88f)) }
        var busy by remember { mutableStateOf(false) }
        val uri = remember(path) { Uri.fromFile(File(path)) }

        val player = remember(path, isVideo) {
            if (!isVideo) null else ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = false
            }
        }
        DisposableEffect(player) {
            onDispose { player?.release() }
        }

        var playing by remember { mutableStateOf(false) }
        var position by remember { mutableLongStateOf(0L) }
        var duration by remember { mutableLongStateOf(0L) }
        var playerView by remember { mutableStateOf<PlayerView?>(null) }

        LaunchedEffect(player) {
            val p = player ?: return@LaunchedEffect
            p.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playing = isPlaying
                }
            })
            while (true) {
                duration = p.duration.coerceAtLeast(0)
                position = p.currentPosition.coerceAtLeast(0)
                delay(200)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
        ) {
              ScreenHeader(title = title, onBack = onBack)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(0.85f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color.Black)
                        .graphicsLayer {
                            rotationZ = rotation
                            scaleX = if (flipH) -1f else 1f
                        }
                ) {
                    if (isVideo && player != null) {
                        AndroidView(
                            factory = { ctx ->
                                (LayoutInflater.from(ctx)
                                    .inflate(R.layout.player_texture, null) as PlayerView).apply {
                                    this.player = player
                                    useController = false
                                    playerView = this
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        AsyncImage(
                            model = uri,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    if (isVideo && !playing) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .clickable { player?.play() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = stringResource(R.string.play), tint = Color.Black, modifier = Modifier.size(36.dp))
                        }
                    }
                    if (isVideo) {
                        Slider(
                            value = if (duration > 0) position / duration.toFloat() else 0f,
                            onValueChange = { player?.seekTo((it * duration).toLong()) },
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Color.White,
                                inactiveTrackColor = Color.White.copy(alpha = 0.4f)
                            )
                        )
                    }
                    if (cropping) {
                        CropOverlay(
                            crop = crop,
                            onCropChange = { crop = it },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    if (busy) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(0.35f)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    }
                }
            }

            WhiteCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EditAction(
                        modifier = Modifier.weight(1f),
                        icon = R.drawable.ic_crop,
                        label = stringResource(R.string.crop)
                    ) { cropping = !cropping }
                    EditAction(
                        modifier = Modifier.weight(1f),
                        icon = R.drawable.ic_rotate,
                        label = stringResource(R.string.rotate)
                    ) {
                        rotation = (rotation + 90f) % 360f
                    }
                    EditAction(
                        modifier = Modifier.weight(1f),
                        icon = R.drawable.ic_flip,
                        label = stringResource(R.string.flip)
                    ) { flipH = !flipH }
                    EditAction(
                        modifier = Modifier.weight(1f),
                        icon = R.drawable.ic_reset,
                        label = stringResource(R.string.reset)
                    ) {
                        rotation = 0f
                        flipH = false
                        cropping = false
                        crop = Rect(0.12f, 0.12f, 0.88f, 0.88f)
                        player?.seekTo(0)
                        player?.pause()
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            BottomBarSpacer {
                PrimaryButton(
                    text = stringResource(R.string.search),
                    enabled = !busy,
                    onClick = {
                        scope.launch {
                            busy = true
                            try {
                                if (isVideo) {
                                    player?.pause()
                                    playing = false
                                }
                                val timeMs = player?.currentPosition ?: position
                                val view = playerView
                                val frame = if (isVideo) {
                                    val live = view?.let { MediaUtils.capturePlayerView(it) }
                                    live ?: withContext(Dispatchers.IO) {
                                        MediaUtils.extractVideoFrame(context, uri, timeMs)
                                    }
                                } else {
                                    withContext(Dispatchers.IO) {
                                        MediaUtils.decodeBitmap(path)
                                    }
                                }
                                if (frame == null) {
                                    Toast.makeText(context, "Unable to process media", Toast.LENGTH_SHORT).show()
                                    return@launch
                                }
                                val edited = withContext(Dispatchers.IO) {
                                    val transformed = MediaUtils.applyTransforms(
                                        frame,
                                        rotation,
                                        flipH,
                                        if (cropping) crop else null
                                    )
                                    val searchFile = MediaUtils.saveJpeg(
                                        context,
                                        transformed,
                                        if (isVideo) "video_frame" else "image"
                                    )
                                    SearchHelper.pendingImageFile = searchFile
                                    val thumb = MediaUtils.saveThumbnail(context, transformed)
                                    Triple(searchFile, thumb, transformed)
                                }
                                val (searchFile, thumb, _) = edited
                                val type = if (isVideo) HistoryItem.TYPE_VIDEO else HistoryItem.TYPE_IMAGE
                                history.add(
                                    HistoryItem(
                                        type = type,
                                        query = if (isVideo) "Video search" else "Image search",
                                        thumbnailPath = thumb.absolutePath,
                                        mediaPath = path
                                    )
                                )
                                onSearchReady(
                                    if (isVideo) "reverse video search" else "reverse image search",
                                    searchFile.absolutePath,
                                    type
                                )
                            } finally {
                                busy = false
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun EditAction(
    modifier: Modifier = Modifier,
    icon: Int,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.clickable(onClick = onClick)
    ) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(icon),
            contentDescription = label,
            modifier = Modifier.size(26.dp),
            contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            fontSize = 12.sp,
            color = PrimaryBlue,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
        )
    }
}
