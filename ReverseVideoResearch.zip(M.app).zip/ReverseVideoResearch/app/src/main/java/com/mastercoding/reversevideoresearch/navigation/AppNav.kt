package com.mastercoding.reversevideoresearch.navigation

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.data.HistoryItem
import com.mastercoding.reversevideoresearch.data.HistoryRepository
import com.mastercoding.reversevideoresearch.data.MediaUtils
import com.mastercoding.reversevideoresearch.data.PrefsManager
import com.mastercoding.reversevideoresearch.ui.components.ExitConfirmDialog
import com.mastercoding.reversevideoresearch.ui.screens.CameraScreen
import com.mastercoding.reversevideoresearch.ui.screens.HistoryScreen
import com.mastercoding.reversevideoresearch.ui.screens.HomeScreen
import com.mastercoding.reversevideoresearch.ui.screens.LanguageScreen
import com.mastercoding.reversevideoresearch.ui.screens.MediaEditScreen
import com.mastercoding.reversevideoresearch.ui.screens.OnboardingScreen
import com.mastercoding.reversevideoresearch.ui.screens.PrivacyScreen
import com.mastercoding.reversevideoresearch.ui.screens.SearchResultScreen
import com.mastercoding.reversevideoresearch.ui.screens.SplashScreen
import com.mastercoding.reversevideoresearch.ui.screens.TermsScreen
import com.mastercoding.reversevideoresearch.ui.screens.TextSearchScreen
import com.mastercoding.reversevideoresearch.ui.screens.VoiceSearchScreen
import kotlinx.coroutines.launch

object Routes {
    const val SPLASH = "splash"
    const val LANGUAGE = "language"
    const val ONBOARDING = "onboarding"
    const val TERMS = "terms"
    const val HOME = "home"
    const val CAMERA = "camera/{mode}"
    const val EDIT = "edit?path={path}&isVideo={isVideo}&title={title}"
    const val SEARCH = "search?query={query}&imagePath={imagePath}&type={type}"
    const val VOICE = "voice"
    const val TEXT = "text"
    const val HISTORY = "history"
    const val PRIVACY = "privacy"

    fun camera(video: Boolean) = "camera/${if (video) "video" else "photo"}"

    fun edit(path: String, isVideo: Boolean, title: String) =
        "edit?path=${Uri.encode(path)}&isVideo=$isVideo&title=${Uri.encode(title)}"

    fun search(query: String, imagePath: String = "", type: String) =
        "search?query=${Uri.encode(query)}&imagePath=${Uri.encode(imagePath)}&type=$type"
}

@Composable
fun AppNav(
    prefs: PrefsManager,
    history: HistoryRepository,
    onLanguagePicked: (String) -> Unit,
    onDeclineTerms: () -> Unit
) {
    val context = LocalContext.current
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    val start = remember { prefs.consumeStartRoute() }
    var showExit by remember { mutableStateOf(false) }
    val currentEntry by nav.currentBackStackEntryAsState()
    val isAtRoot = currentEntry != null && nav.previousBackStackEntry == null

    BackHandler(enabled = isAtRoot) {
        showExit = true
    }

    if (showExit) {
        ExitConfirmDialog(
            onConfirm = {
                showExit = false
                (context as? Activity)?.finishAffinity()
            },
            onDismiss = { showExit = false }
        )
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching {
            val file = MediaUtils.copyToAppStorage(
                context, uri, "IMG", MediaUtils.extensionFor(uri, "image")
            )
            nav.navigate(
                Routes.edit(file.absolutePath, false, context.getString(R.string.reverse_image_search))
            )
        }.onFailure {
            Toast.makeText(context, it.message, Toast.LENGTH_SHORT).show()
        }
    }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching {
            val file = MediaUtils.copyToAppStorage(
                context, uri, "VID", MediaUtils.extensionFor(uri, "video")
            )
            nav.navigate(
                Routes.edit(file.absolutePath, true, context.getString(R.string.reverse_video_search))
            )
        }.onFailure {
            Toast.makeText(context, it.message, Toast.LENGTH_SHORT).show()
        }
    }

    fun goHomeClearing() {
        nav.navigate(Routes.HOME) {
            popUpTo(nav.graph.id) { inclusive = true }
        }
    }

    fun goSearch(query: String, type: String, imagePath: String = "") {
        scope.launch {
            if (type == HistoryItem.TYPE_TEXT || type == HistoryItem.TYPE_VOICE || type == HistoryItem.TYPE_URL) {
                history.add(HistoryItem(type = type, query = query))
            }
            nav.navigate(Routes.search(query, imagePath, type))
        }
    }

    NavHost(navController = nav, startDestination = start) {
        composable(Routes.SPLASH) {
            SplashScreen(isReturningUser = prefs.isSetupComplete) {
                when {
                    prefs.isSetupComplete -> goHomeClearing()
                    prefs.isLanguageChosen -> {
                        nav.navigate(Routes.ONBOARDING) {
                            popUpTo(Routes.SPLASH) { inclusive = true }
                        }
                    }
                    else -> {
                        nav.navigate(Routes.LANGUAGE) {
                            popUpTo(Routes.SPLASH) { inclusive = true }
                        }
                    }
                }
            }
        }
        composable(Routes.LANGUAGE) {
            LanguageScreen(currentCode = prefs.languageCode) { code ->
                onLanguagePicked(code)
            }
        }
        composable(Routes.ONBOARDING) {
            OnboardingScreen {
                nav.navigate(Routes.TERMS)
            }
        }
        composable(Routes.TERMS) {
            TermsScreen(
                onAccept = {
                    prefs.isSetupComplete = true
                    goHomeClearing()
                },
                onDecline = { showExit = true }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                onCaptureVideo = { nav.navigate(Routes.camera(true)) },
                onUploadVideo = {
                    pickVideo.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                },
                onCaptureImage = { nav.navigate(Routes.camera(false)) },
                onUploadImage = {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onTextSearch = { nav.navigate(Routes.TEXT) },
                onVoiceSearch = { nav.navigate(Routes.VOICE) },
                onUrlSearch = { url -> goSearch(url, HistoryItem.TYPE_URL) },
                onHistory = { nav.navigate(Routes.HISTORY) },
                onPrivacy = { nav.navigate(Routes.PRIVACY) }
            )
        }
        composable(
            route = Routes.CAMERA,
            arguments = listOf(navArgument("mode") { type = NavType.StringType })
        ) { entry ->
            val video = entry.arguments?.getString("mode") == "video"
            CameraScreen(
                isVideo = video,
                onCaptured = { path ->
                    val title = if (video) {
                        context.getString(R.string.reverse_video_search)
                    } else {
                        context.getString(R.string.reverse_image_search)
                    }
                    nav.navigate(Routes.edit(path, video, title)) {
                        popUpTo(Routes.HOME)
                    }
                },
                onBack = { nav.popBackStack() }
            )
        }
        composable(
            route = Routes.EDIT,
            arguments = listOf(
                navArgument("path") { type = NavType.StringType },
                navArgument("isVideo") { type = NavType.BoolType; defaultValue = false },
                navArgument("title") { type = NavType.StringType; defaultValue = "Search" }
            )
        ) { entry ->
            val path = entry.arguments?.getString("path").orEmpty()
            val isVideo = entry.arguments?.getBoolean("isVideo") == true
            val title = entry.arguments?.getString("title").orEmpty()
            MediaEditScreen(
                path = path,
                isVideo = isVideo,
                title = title,
                history = history,
                onSearchReady = { query, imagePath, type ->
                    nav.navigate(Routes.search(query, imagePath, type))
                },
                onBack = { nav.popBackStack() }
            )
        }
        composable(
            route = Routes.SEARCH,
            arguments = listOf(
                navArgument("query") { type = NavType.StringType; defaultValue = "" },
                navArgument("imagePath") { type = NavType.StringType; defaultValue = "" },
                navArgument("type") { type = NavType.StringType; defaultValue = "text" }
            )
        ) { entry ->
            SearchResultScreen(
                query = entry.arguments?.getString("query").orEmpty(),
                imagePath = entry.arguments?.getString("imagePath").orEmpty(),
                type = entry.arguments?.getString("type").orEmpty(),
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.VOICE) {
            VoiceSearchScreen(
                onSearch = { goSearch(it, HistoryItem.TYPE_VOICE) },
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.TEXT) {
            TextSearchScreen(
                onSearch = { goSearch(it, HistoryItem.TYPE_TEXT) },
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(
                history = history,
                onOpen = { item ->
                    nav.navigate(Routes.search(item.query, item.thumbnailPath, item.type))
                },
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.PRIVACY) {
            PrivacyScreen(onBack = { nav.popBackStack() })
        }
    }
}
