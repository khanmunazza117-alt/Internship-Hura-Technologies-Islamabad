package com.mastercoding.reversevideoresearch.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

class HistoryRepository(context: Context) {

    private val file = File(context.applicationContext.filesDir, "search_history.json")
    private val mutex = Mutex()

    suspend fun getAll(): List<HistoryItem> = mutex.withLock {
        withContext(Dispatchers.IO) { readUnlocked() }
    }

    suspend fun add(item: HistoryItem) {
        mutex.withLock {
            withContext(Dispatchers.IO) {
                val items = readUnlocked().toMutableList()
                items.add(0, item)
                writeUnlocked(items)
            }
        }
    }

    suspend fun delete(ids: Set<String>) {
        mutex.withLock {
            withContext(Dispatchers.IO) {
                val all = readUnlocked()
                val remaining = all.filterNot { it.id in ids }
                all.filter { it.id in ids }.forEach { item ->
                    item.thumbnailPath.takeIf { it.isNotBlank() }?.let { File(it).delete() }
                    item.mediaPath.takeIf { it.isNotBlank() && it != item.thumbnailPath }?.let { File(it).delete() }
                }
                writeUnlocked(remaining)
            }
        }
    }

    private fun readUnlocked(): List<HistoryItem> {
        if (!file.exists()) return emptyList()
        return try {
            val array = JSONArray(file.readText())
            buildList {
                for (i in 0 until array.length()) {
                    add(HistoryItem.fromJson(array.getJSONObject(i)))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeUnlocked(items: List<HistoryItem>) {
        val array = JSONArray()
        items.forEach { array.put(it.toJson()) }
        file.writeText(array.toString())
    }
}
