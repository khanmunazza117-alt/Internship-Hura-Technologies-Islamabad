package com.mastercoding.reversevideoresearch.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.components.ScreenHeader
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLavender
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    ReverseVideoResearchTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLavender)
        ) {
            ScreenHeader(title = stringResource(R.string.privacy_policy), onBack = onBack)
            Text(
                text = stringResource(R.string.privacy_body),
                fontSize = 15.sp,
                color = TextPrimary,
                lineHeight = 22.sp,
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .navigationBarsPadding()
                    .padding(20.dp)
            )
        }
    }
}
