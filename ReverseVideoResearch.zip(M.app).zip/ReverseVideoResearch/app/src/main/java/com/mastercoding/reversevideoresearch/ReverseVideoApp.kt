package com.mastercoding.reversevideoresearch

import android.app.Application
import com.mastercoding.reversevideoresearch.data.HistoryRepository
import com.mastercoding.reversevideoresearch.data.PrefsManager

class ReverseVideoApp : Application() {
    lateinit var prefs: PrefsManager
        private set
    lateinit var history: HistoryRepository
        private set

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsManager(this)
        history = HistoryRepository(this)
    }
}
