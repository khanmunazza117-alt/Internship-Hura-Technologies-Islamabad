package com.mastercoding.reversevideoresearch.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.components.PrimaryButton
import com.mastercoding.reversevideoresearch.ui.components.WhiteCard
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLavender
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary
import com.mastercoding.reversevideoresearch.ui.theme.TextSecondary

enum class HomeSheet { None, Image, Url }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onCaptureVideo: () -> Unit,
    onUploadVideo: () -> Unit,
    onCaptureImage: () -> Unit,
    onUploadImage: () -> Unit,
    onTextSearch: () -> Unit,
    onVoiceSearch: () -> Unit,
    onUrlSearch: (String) -> Unit,
    onHistory: () -> Unit,
    onPrivacy: () -> Unit
) {
    ReverseVideoResearchTheme {
        var sheet by remember { mutableStateOf(HomeSheet.None) }
        var urlText by remember { mutableStateOf("") }
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLavender)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            val hPad = 16.dp
            val fullW = maxWidth - hPad * 2
            val videoH = fullW * (425f / 656f)
            val compactH = fullW * (174f / 656f)
            val tallH = fullW * (305f / 656f)
            val gap = fullW * (14f / 656f)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = hPad, vertical = 12.dp)
            ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.reverse_video_search),
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.home_description),
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                }
                Spacer(Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFD8DCE8), RoundedCornerShape(20.dp))
                        .clickable(onClick = onPrivacy)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = stringResource(R.string.privacy_policy),
                        fontSize = 11.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            WhiteCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(videoH)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = stringResource(R.string.video_search),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextPrimary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.video_search_desc),
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        VideoAction(
                            label = stringResource(R.string.capture_video),
                            icon = R.drawable.ic_camera,
                            onClick = onCaptureVideo
                        )
                        Text(
                            text = stringResource(R.string.or),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        VideoAction(
                            label = stringResource(R.string.upload_video),
                            icon = R.drawable.ic_upload,
                            onClick = onUploadVideo
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                FeatureCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(compactH),
                    label = stringResource(R.string.image_search),
                    icon = R.drawable.ic_search_img,
                    vertical = false,
                    onClick = { sheet = HomeSheet.Image }
                )
                FeatureCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(compactH),
                    label = stringResource(R.string.text_search),
                    icon = R.drawable.ic_search_text,
                    vertical = false,
                    onClick = onTextSearch
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                FeatureCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(tallH),
                    label = stringResource(R.string.voice_search),
                    icon = R.drawable.ic_search_voice,
                    vertical = true,
                    onClick = onVoiceSearch
                )
                FeatureCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(tallH),
                    label = stringResource(R.string.url),
                    icon = R.drawable.ic_url,
                    vertical = true,
                    onClick = { sheet = HomeSheet.Url }
                )
            }

            Spacer(Modifier.height(14.dp))

            WhiteCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(compactH),
                onClick = onHistory
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(R.drawable.ic_history_clock),
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.width(14.dp))
                    Text(
                        text = stringResource(R.string.history),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                        color = TextPrimary
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            }

        }

        if (sheet != HomeSheet.None) {
            ModalBottomSheet(
                onDismissRequest = { sheet = HomeSheet.None },
                sheetState = sheetState,
                containerColor = Color.White,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                when (sheet) {
                    HomeSheet.Image -> {
                        Column(modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
                            SheetRow(stringResource(R.string.capture_image), R.drawable.ic_camera) {
                                sheet = HomeSheet.None
                                onCaptureImage()
                            }
                            Spacer(Modifier.height(8.dp))
                            SheetRow(stringResource(R.string.upload_image), R.drawable.ic_search_img) {
                                sheet = HomeSheet.None
                                onUploadImage()
                            }
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                    HomeSheet.Url -> {
                        Column(modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)) {
                            OutlinedTextField(
                                value = urlText,
                                onValueChange = { urlText = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text(stringResource(R.string.url_hint), color = TextSecondary) },
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = Color(0xFFF3F4F8),
                                    unfocusedContainerColor = Color(0xFFF3F4F8),
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent
                                ),
                                singleLine = true
                            )
                            Spacer(Modifier.height(16.dp))
                            PrimaryButton(
                                text = stringResource(R.string.search),
                                onClick = {
                                    if (urlText.isNotBlank()) {
                                        val q = urlText.trim()
                                        sheet = HomeSheet.None
                                        onUrlSearch(q)
                                    }
                                }
                            )
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}

@Composable
private fun VideoAction(label: String, icon: Int, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Image(
            painter = painterResource(icon),
            contentDescription = label,
            modifier = Modifier.size(72.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun FeatureCard(
    modifier: Modifier,
    label: String,
    icon: Int,
    vertical: Boolean,
    onClick: () -> Unit
) {
    WhiteCard(modifier = modifier, onClick = onClick) {
        if (vertical) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(icon),
                    contentDescription = label,
                    modifier = Modifier.size(64.dp),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.height(10.dp))
                Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(icon),
                    contentDescription = label,
                    modifier = Modifier.size(48.dp),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.width(10.dp))
                Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
            }
        }
    }
}

@Composable
private fun SheetRow(label: String, icon: Int, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(icon),
            contentDescription = label,
            modifier = Modifier.size(44.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.width(14.dp))
        Text(label, fontWeight = FontWeight.Medium, fontSize = 15.sp, color = TextPrimary)
    }
}
