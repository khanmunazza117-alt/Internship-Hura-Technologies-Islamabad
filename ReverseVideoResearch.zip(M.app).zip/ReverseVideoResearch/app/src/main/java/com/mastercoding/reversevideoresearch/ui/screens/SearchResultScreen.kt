package com.mastercoding.reversevideoresearch.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.data.HistoryItem
import com.mastercoding.reversevideoresearch.data.MediaUtils
import com.mastercoding.reversevideoresearch.data.SearchHelper
import com.mastercoding.reversevideoresearch.ui.components.ScreenHeader
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLavender
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextSecondary
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SearchResultScreen(
    query: String,
    imagePath: String,
    type: String,
    onBack: () -> Unit
) {
    ReverseVideoResearchTheme {
        val context = LocalContext.current
        var textUrl by remember { mutableStateOf<String?>(null) }
        var upload by remember { mutableStateOf<SearchHelper.PreparedUpload?>(null) }
        var hostedLensUrl by remember { mutableStateOf<String?>(null) }
        var stage by remember { mutableIntStateOf(0) }
        var progress by remember { mutableIntStateOf(0) }
        var loadedKey by remember { mutableStateOf<String?>(null) }
        var labelSearchUrl by remember { mutableStateOf<String?>(null) }
        val isMedia = type == HistoryItem.TYPE_IMAGE || type == HistoryItem.TYPE_VIDEO

        LaunchedEffect(query, imagePath, type) {
            try {
                if (isMedia) {
                    val pending = SearchHelper.pendingImageFile
                    val file = when {
                        pending != null && pending.exists() -> pending
                        imagePath.isNotBlank() -> File(imagePath)
                        else -> null
                    }
                    if (file != null && file.exists()) {
                        val prepared = SearchHelper.prepareUpload(file)
                        val bmp = android.graphics.BitmapFactory.decodeFile(prepared.file.absolutePath)
                        if (bmp != null) {
                            val labels = SearchHelper.labelsQuery(bmp)
                            labelSearchUrl = SearchHelper.googleTextUrl(
                                labels.ifBlank { query.ifBlank { "similar images" } }
                            )
                        }
                        hostedLensUrl = SearchHelper.lensUrlFromHostedFile(prepared.file)
                        upload = prepared
                    } else {
                        textUrl = SearchHelper.googleTextUrl(query.ifBlank { "similar images" })
                    }
                } else {
                    textUrl = SearchHelper.googleTextUrl(query)
                }
            } catch (e: Exception) {
                Toast.makeText(context, e.message ?: "Search failed", Toast.LENGTH_SHORT).show()
                textUrl = SearchHelper.googleTextUrl(query.ifBlank { "search" })
            }
        }

        val uploadRef = remember { AtomicReference<File?>(null) }
        uploadRef.set(upload?.file)
        val stageRef = remember { AtomicInteger(0) }
        stageRef.set(stage)
        val fallbackHandler = remember { Handler(Looper.getMainLooper()) }
        val goToTextSearch: () -> Unit = {
            upload = null
            textUrl = labelSearchUrl ?: SearchHelper.googleTextUrl(query.ifBlank { "similar images" })
        }
        val nextStage = remember { AtomicReference<() -> Unit>({}) }
        nextStage.set {
            when (stageRef.get()) {
                0 -> if (!hostedLensUrl.isNullOrBlank()) stage = 1 else goToTextSearch()
                else -> goToTextSearch()
            }
        }

        DisposableEffect(Unit) {
            onDispose { fallbackHandler.removeCallbacksAndMessages(null) }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLavender)
                .navigationBarsPadding()
        ) {
            ScreenHeader(title = stringResource(R.string.search_result), onBack = onBack)
            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = PrimaryBlue
                )
            }
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                val mediaUpload = upload
                val ready = mediaUpload != null || textUrl != null
                if (!ready) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PrimaryBlue)
                        Text(
                            text = stringResource(R.string.searching),
                            color = TextSecondary,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                } else {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.loadsImagesAutomatically = true
                                settings.allowFileAccess = true
                                settings.allowContentAccess = true
                                settings.useWideViewPort = true
                                settings.loadWithOverviewMode = true
                                settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                settings.userAgentString = SearchHelper.USER_AGENT
                                CookieManager.getInstance().setAcceptCookie(true)
                                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                                webChromeClient = object : WebChromeClient() {
                                    private var fileCallback: ValueCallback<Array<Uri>>? = null

                                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                        progress = newProgress
                                    }

                                    override fun onShowFileChooser(
                                        webView: WebView?,
                                        filePathCallback: ValueCallback<Array<Uri>>?,
                                        fileChooserParams: FileChooserParams?
                                    ): Boolean {
                                        fileCallback?.onReceiveValue(null)
                                        val file = uploadRef.get()
                                        if (file == null || !file.exists()) {
                                            filePathCallback?.onReceiveValue(null)
                                            return true
                                        }
                                        val uri = try {
                                            MediaUtils.fileProviderUri(ctx, file)
                                        } catch (_: Exception) {
                                            Uri.fromFile(file)
                                        }
                                        fileCallback = filePathCallback
                                        filePathCallback?.onReceiveValue(arrayOf(uri))
                                        fileCallback = null
                                        return true
                                    }
                                }
                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(
                                        view: WebView?,
                                        request: WebResourceRequest?
                                    ): Boolean = false

                                    @Deprecated("Deprecated in Java")
                                    override fun shouldOverrideUrlLoading(
                                        view: WebView?,
                                        url: String?
                                    ): Boolean = false

                                    override fun onReceivedHttpError(
                                        view: WebView,
                                        request: WebResourceRequest,
                                        errorResponse: WebResourceResponse
                                    ) {
                                        if (request.isForMainFrame && errorResponse.statusCode == 404) {
                                            nextStage.get().invoke()
                                        }
                                    }

                                    override fun onPageFinished(view: WebView, url: String) {
                                        val lower = url.lowercase()
                                        if (lower.contains("/v3/")) {
                                            nextStage.get().invoke()
                                            return
                                        }
                                        val current = stageRef.get()
                                        fallbackHandler.removeCallbacksAndMessages(null)
                                        val onForm = url.trimEnd('/') == "https://www.google.com" ||
                                            url.startsWith("data:") ||
                                            url.startsWith("about:")
                                        if (current == 0 && onForm) {
                                            fallbackHandler.postDelayed({
                                                if (stageRef.get() == 0) nextStage.get().invoke()
                                            }, 10000)
                                            return
                                        }
                                        if (url.contains("lens.google.com") || url.contains("/search")) {
                                            fallbackHandler.postDelayed({
                                                view.evaluateJavascript(SearchHelper.RESULT_IMAGE_COUNT_JS) { raw ->
                                                    val count = raw?.filter { it.isDigit() }?.toIntOrNull() ?: 0
                                                    if (count < 3) nextStage.get().invoke()
                                                }
                                            }, 8000)
                                        }
                                    }
                                }
                            }
                        },
                        update = { view ->
                            if (mediaUpload != null) {
                                val key = "$stage-${mediaUpload.file.absolutePath}"
                                if (loadedKey != key) {
                                    loadedKey = key
                                    fallbackHandler.removeCallbacksAndMessages(null)
                                    if (stage == 0) {
                                        view.loadDataWithBaseURL(
                                            "https://www.google.com/",
                                            SearchHelper.googleSearchByImageHtml(mediaUpload.base64),
                                            "text/html",
                                            "UTF-8",
                                            null
                                        )
                                    } else {
                                        val hosted = hostedLensUrl
                                        if (hosted != null) {
                                            view.loadUrl(hosted)
                                        } else {
                                            nextStage.get().invoke()
                                        }
                                    }
                                }
                            } else {
                                val target = textUrl
                                if (target != null && loadedKey != target) {
                                    loadedKey = target
                                    view.loadUrl(target)
                                }
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
