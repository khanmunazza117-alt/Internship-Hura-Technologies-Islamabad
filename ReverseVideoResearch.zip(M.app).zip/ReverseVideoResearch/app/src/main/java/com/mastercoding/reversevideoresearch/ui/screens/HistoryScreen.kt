package com.mastercoding.reversevideoresearch.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.data.HistoryItem
import com.mastercoding.reversevideoresearch.data.HistoryRepository
import com.mastercoding.reversevideoresearch.ui.components.BottomBarSpacer
import com.mastercoding.reversevideoresearch.ui.components.PrimaryButton
import com.mastercoding.reversevideoresearch.ui.components.ScreenHeader
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLight
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary
import com.mastercoding.reversevideoresearch.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    history: HistoryRepository,
    onOpen: (HistoryItem) -> Unit,
    onBack: () -> Unit
) {
    ReverseVideoResearchTheme {
        var items by remember { mutableStateOf<List<HistoryItem>>(emptyList()) }
        var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
        val scope = rememberCoroutineScope()
        val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

        LaunchedEffect(Unit) {
            items = history.getAll()
        }

        val allSelected = items.isNotEmpty() && selected.size == items.size

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLight)
        ) {
            ScreenHeader(
                title = stringResource(R.string.history),
                onBack = onBack,
                trailing = {
                    Row(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clickable {
                                selected = if (allSelected) emptySet() else items.map { it.id }.toSet()
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.select_all),
                            fontSize = 13.sp,
                            color = TextPrimary,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Image(
                            painter = painterResource(
                                if (allSelected) R.drawable.checkcircle_img else R.drawable.emptycircle_img
                            ),
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            )

            if (items.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.empty_history), color = TextSecondary)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(items, key = { it.id }) { item ->
                        val isSelected = item.id in selected
                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFFE8EAF2))
                                .clickable {
                                    if (selected.isNotEmpty()) {
                                        selected = if (isSelected) selected - item.id else selected + item.id
                                    } else {
                                        onOpen(item)
                                    }
                                }
                        ) {
                            val thumb = item.thumbnailPath
                            if (thumb.isNotBlank() && File(thumb).exists()) {
                                AsyncImage(
                                    model = File(thumb),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(item.query.take(18), color = TextSecondary, fontSize = 12.sp)
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.BottomCenter)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))
                                        )
                                    )
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = dateFormat.format(Date(item.createdAt)),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            if (item.type == HistoryItem.TYPE_VIDEO) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.9f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                                }
                            }
                            Image(
                                painter = painterResource(
                                    if (isSelected) R.drawable.checkcircle_img else R.drawable.emptycircle_img
                                ),
                                contentDescription = null,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .size(22.dp)
                                    .clickable {
                                        selected = if (isSelected) selected - item.id else selected + item.id
                                    }
                            )
                        }
                    }
                }
                BottomBarSpacer {
                    PrimaryButton(
                        text = stringResource(R.string.delete),
                        enabled = selected.isNotEmpty(),
                        onClick = {
                            scope.launch {
                                history.delete(selected)
                                selected = emptySet()
                                items = history.getAll()
                            }
                        }
                    )
                }
            }
        }
    }
}
