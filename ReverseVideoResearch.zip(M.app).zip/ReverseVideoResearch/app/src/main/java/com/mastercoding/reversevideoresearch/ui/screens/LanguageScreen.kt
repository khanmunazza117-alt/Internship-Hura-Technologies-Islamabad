package com.mastercoding.reversevideoresearch.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.components.ScreenHeader
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLavender
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary

data class LanguageOption(
    val code: String,
    val nameRes: Int,
    val flagRes: Int
)

val AppLanguages = listOf(
    LanguageOption("en", R.string.lang_english, R.drawable.flag_uk),
    LanguageOption("ur", R.string.lang_pakistan, R.drawable.flag_pakistan),
    LanguageOption("tr", R.string.lang_turkish, R.drawable.flag_turkey),
    LanguageOption("ar", R.string.lang_arabic, R.drawable.flag_arabic),
    LanguageOption("zh", R.string.lang_chinese, R.drawable.flag_china),
    LanguageOption("ja", R.string.lang_japanese, R.drawable.flag_japan)
)

@Composable
fun LanguageScreen(
    currentCode: String,
    onConfirm: (String) -> Unit
) {
    ReverseVideoResearchTheme {
        var selected by rememberSaveable { mutableStateOf(currentCode.ifBlank { "en" }) }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLavender)
                .navigationBarsPadding()
        ) {
            ScreenHeader(
                title = stringResource(R.string.select_language),
                trailing = {
                    Box(
                        modifier = Modifier
                            .padding(end = 16.dp)
                            .width(52.dp)
                            .height(32.dp)
                            .clip(RoundedCornerShape(50))
                            .background(PrimaryBlue)
                            .clickable { onConfirm(selected) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = stringResource(R.string.cd_confirm),
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(20.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(AppLanguages, key = { it.code }) { lang ->
                    LanguageCard(
                        option = lang,
                        selected = selected == lang.code,
                        onClick = { selected = lang.code }
                    )
                }
            }
        }
    }
}

@Composable
private fun LanguageCard(
    option: LanguageOption,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .aspectRatio(0.85f)
            .then(
                if (selected) {
                    Modifier.shadow(
                        elevation = 12.dp,
                        shape = RoundedCornerShape(18.dp),
                        ambientColor = Color(0x336C7EE1),
                        spotColor = Color(0x3D6C7EE1)
                    )
                } else Modifier
            )
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(option.flagRes),
                contentDescription = null,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color(0x14000000), CircleShape),
                contentScale = ContentScale.Crop
            )
            Text(
                text = stringResource(option.nameRes),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
        if (selected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(PrimaryBlue),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(11.dp)
                )
            }
        }
    }
}
