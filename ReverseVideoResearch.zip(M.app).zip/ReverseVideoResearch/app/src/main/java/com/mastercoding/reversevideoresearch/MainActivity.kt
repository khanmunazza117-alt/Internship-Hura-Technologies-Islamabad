package com.mastercoding.reversevideoresearch

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.mastercoding.reversevideoresearch.data.LocaleHelper
import com.mastercoding.reversevideoresearch.data.PrefsManager
import com.mastercoding.reversevideoresearch.navigation.AppNav
import com.mastercoding.reversevideoresearch.navigation.Routes

class MainActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableEdgeToEdge()
        val app = application as ReverseVideoApp
        setContent {
            AppNav(
                prefs = app.prefs,
                history = app.history,
                onLanguagePicked = { code ->
                    app.prefs.languageCode = code
                    app.prefs.isLanguageChosen = true
                    app.prefs.pendingRoute = Routes.ONBOARDING
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                },
                onDeclineTerms = { finishAffinity() }
            )
        }
    }
}
