package com.mastercoding.reversevideoresearch.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mastercoding.reversevideoresearch.ui.theme.AccentYellow
import com.mastercoding.reversevideoresearch.ui.theme.IconBlue

@Composable
fun CaptureCameraGlyph(modifier: Modifier = Modifier, size: Dp = 36.dp) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val stroke = s * 0.08f
        drawRoundRect(
            color = IconBlue,
            topLeft = Offset(s * 0.12f, s * 0.22f),
            size = Size(s * 0.76f, s * 0.58f),
            cornerRadius = CornerRadius(s * 0.1f),
            style = Stroke(stroke)
        )
        drawCircle(AccentYellow, radius = s * 0.16f, center = Offset(s * 0.5f, s * 0.5f))
        drawCircle(IconBlue, radius = s * 0.08f, center = Offset(s * 0.5f, s * 0.5f))
        drawRoundRect(
            color = IconBlue,
            topLeft = Offset(s * 0.38f, s * 0.1f),
            size = Size(s * 0.24f, s * 0.14f),
            cornerRadius = CornerRadius(s * 0.04f)
        )
    }
}

@Composable
fun UploadVideoGlyph(modifier: Modifier = Modifier, size: Dp = 36.dp) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val stroke = s * 0.08f
        drawRoundRect(
            color = IconBlue,
            topLeft = Offset(s * 0.1f, s * 0.28f),
            size = Size(s * 0.52f, s * 0.42f),
            cornerRadius = CornerRadius(s * 0.08f),
            style = Stroke(stroke)
        )
        val tri = Path().apply {
            moveTo(s * 0.62f, s * 0.36f)
            lineTo(s * 0.88f, s * 0.5f)
            lineTo(s * 0.62f, s * 0.64f)
            close()
        }
        drawPath(tri, AccentYellow)
    }
}

@Composable
fun ImageSearchGlyph(modifier: Modifier = Modifier, size: Dp = 32.dp) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val stroke = s * 0.08f
        drawRoundRect(
            color = IconBlue,
            topLeft = Offset(s * 0.12f, s * 0.2f),
            size = Size(s * 0.76f, s * 0.6f),
            cornerRadius = CornerRadius(s * 0.1f),
            style = Stroke(stroke)
        )
        drawCircle(AccentYellow, radius = s * 0.08f, center = Offset(s * 0.32f, s * 0.38f))
        val mountain = Path().apply {
            moveTo(s * 0.18f, s * 0.72f)
            lineTo(s * 0.42f, s * 0.48f)
            lineTo(s * 0.58f, s * 0.62f)
            lineTo(s * 0.74f, s * 0.42f)
            lineTo(s * 0.88f, s * 0.72f)
            close()
        }
        drawPath(mountain, IconBlue.copy(alpha = 0.85f))
    }
}

@Composable
fun TextSearchGlyph(modifier: Modifier = Modifier, size: Dp = 32.dp) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val stroke = s * 0.09f
        drawCircle(IconBlue, radius = s * 0.28f, center = Offset(s * 0.42f, s * 0.42f), style = Stroke(stroke))
        drawLine(IconBlue, Offset(s * 0.62f, s * 0.62f), Offset(s * 0.84f, s * 0.84f), stroke, StrokeCap.Round)
        drawLine(AccentYellow, Offset(s * 0.36f, s * 0.3f), Offset(s * 0.36f, s * 0.54f), stroke, StrokeCap.Round)
        drawLine(AccentYellow, Offset(s * 0.28f, s * 0.3f), Offset(s * 0.44f, s * 0.3f), stroke, StrokeCap.Round)
    }
}

@Composable
fun VoiceSearchGlyph(modifier: Modifier = Modifier, size: Dp = 32.dp) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val stroke = s * 0.08f
        drawRoundRect(
            color = IconBlue,
            topLeft = Offset(s * 0.38f, s * 0.16f),
            size = Size(s * 0.24f, s * 0.42f),
            cornerRadius = CornerRadius(s * 0.12f)
        )
        drawArc(
            color = IconBlue,
            startAngle = 20f,
            sweepAngle = 140f,
            useCenter = false,
            topLeft = Offset(s * 0.26f, s * 0.28f),
            size = Size(s * 0.48f, s * 0.48f),
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
        drawLine(IconBlue, Offset(s * 0.5f, s * 0.7f), Offset(s * 0.5f, s * 0.82f), stroke, StrokeCap.Round)
        drawLine(IconBlue, Offset(s * 0.36f, s * 0.82f), Offset(s * 0.64f, s * 0.82f), stroke, StrokeCap.Round)
        drawLine(AccentYellow, Offset(s * 0.16f, s * 0.4f), Offset(s * 0.16f, s * 0.58f), stroke, StrokeCap.Round)
        drawLine(AccentYellow, Offset(s * 0.84f, s * 0.4f), Offset(s * 0.84f, s * 0.58f), stroke, StrokeCap.Round)
    }
}

@Composable
fun UrlSearchGlyph(modifier: Modifier = Modifier, size: Dp = 32.dp) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val stroke = s * 0.08f
        drawCircle(IconBlue, radius = s * 0.26f, center = Offset(s * 0.4f, s * 0.4f), style = Stroke(stroke))
        drawLine(IconBlue, Offset(s * 0.58f, s * 0.58f), Offset(s * 0.8f, s * 0.8f), stroke, StrokeCap.Round)
        drawArc(
            color = AccentYellow,
            startAngle = 200f,
            sweepAngle = 140f,
            useCenter = false,
            topLeft = Offset(s * 0.18f, s * 0.58f),
            size = Size(s * 0.28f, s * 0.22f),
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
        drawArc(
            color = AccentYellow,
            startAngle = 20f,
            sweepAngle = 140f,
            useCenter = false,
            topLeft = Offset(s * 0.32f, s * 0.7f),
            size = Size(s * 0.28f, s * 0.22f),
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun HistoryGlyph(modifier: Modifier = Modifier, size: Dp = 32.dp) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val stroke = s * 0.08f
        drawCircle(IconBlue, radius = s * 0.34f, center = Offset(s * 0.5f, s * 0.52f), style = Stroke(stroke))
        drawLine(IconBlue, Offset(s * 0.5f, s * 0.52f), Offset(s * 0.5f, s * 0.34f), stroke, StrokeCap.Round)
        drawLine(IconBlue, Offset(s * 0.5f, s * 0.52f), Offset(s * 0.66f, s * 0.58f), stroke, StrokeCap.Round)
        drawArc(
            color = AccentYellow,
            startAngle = 200f,
            sweepAngle = 80f,
            useCenter = false,
            topLeft = Offset(s * 0.18f, s * 0.08f),
            size = Size(s * 0.28f, s * 0.28f),
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
    }
}
