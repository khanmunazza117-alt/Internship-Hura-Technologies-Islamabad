package com.mastercoding.reversevideoresearch.data

import android.content.Context
import android.content.SharedPreferences

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** True only after Terms are accepted. Second launch uses this to skip intro. */
    var isSetupComplete: Boolean
        get() = prefs.getBoolean(KEY_SETUP_COMPLETE, false)
        set(value) = prefs.edit().putBoolean(KEY_SETUP_COMPLETE, value).apply()

    var isLanguageChosen: Boolean
        get() = prefs.getBoolean(KEY_LANGUAGE_CHOSEN, false)
        set(value) = prefs.edit().putBoolean(KEY_LANGUAGE_CHOSEN, value).apply()

    var languageCode: String
        get() = prefs.getString(KEY_LANGUAGE, "en") ?: "en"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var pendingRoute: String?
        get() = prefs.getString(KEY_PENDING, null)
        set(value) = prefs.edit().putString(KEY_PENDING, value).apply()

    fun consumeStartRoute(): String {
        val pending = pendingRoute
        pendingRoute = null
        return pending ?: "splash"
    }

    companion object {
        private const val PREFS_NAME = "rvr_prefs"
        private const val KEY_SETUP_COMPLETE = "setup_complete"
        private const val KEY_LANGUAGE_CHOSEN = "language_chosen"
        private const val KEY_LANGUAGE = "language_code"
        private const val KEY_PENDING = "pending_route"
    }
}
