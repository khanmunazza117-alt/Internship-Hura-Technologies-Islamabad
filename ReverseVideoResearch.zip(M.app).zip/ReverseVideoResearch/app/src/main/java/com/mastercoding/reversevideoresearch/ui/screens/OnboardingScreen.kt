package com.mastercoding.reversevideoresearch.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary
import kotlinx.coroutines.launch

private val OnboardBg = Color(0xFFF5F7FF)
private val OnboardBlob = Color(0xFFE0E7FF)

@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    ReverseVideoResearchTheme {
        val pagerState = rememberPagerState(pageCount = { 4 })
        val scope = rememberCoroutineScope()
        val interaction = remember { MutableInteractionSource() }
        val page = pagerState.currentPage
        val titles = listOf(
            R.string.intro_title_1,
            R.string.intro_title_2,
            R.string.intro_title_3,
            R.string.intro_title_4
        )
        val descs = listOf(
            R.string.intro_desc_1,
            R.string.intro_desc_2,
            R.string.intro_desc_3,
            R.string.intro_desc_4
        )
        val images = listOf(
            R.drawable.intro1_img,
            R.drawable.intro2_img,
            R.drawable.intro3_img,
            R.drawable.intro4_img
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(OnboardBg)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.62f)
                    .align(Alignment.TopCenter)
            ) {
                val blob = Path().apply {
                    val cx = size.width * 0.50f
                    val cy = size.height * 0.48f
                    moveTo(cx - size.width * 0.52f, cy)
                    cubicTo(
                        cx - size.width * 0.50f, cy - size.height * 0.55f,
                        cx + size.width * 0.48f, cy - size.height * 0.52f,
                        cx + size.width * 0.50f, cy
                    )
                    cubicTo(
                        cx + size.width * 0.48f, cy + size.height * 0.42f,
                        cx - size.width * 0.46f, cy + size.height * 0.38f,
                        cx - size.width * 0.52f, cy
                    )
                    close()
                }
                drawPath(blob, OnboardBlob)
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.60f)
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
            ) { index ->
                Image(
                    painter = painterResource(images[index]),
                    contentDescription = stringResource(titles[index]),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    contentScale = ContentScale.Fit
                )
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    val wave = Path().apply {
                        moveTo(0f, h * 0.68f)
                        cubicTo(
                            w * 0.22f, h * 0.08f,
                            w * 0.52f, h * 1.05f,
                            w, h * 0.18f
                        )
                        lineTo(w, h)
                        lineTo(0f, h)
                        close()
                    }
                    drawPath(wave, Color.White)
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .navigationBarsPadding()
                        .padding(start = 32.dp, end = 28.dp, bottom = 22.dp)
                ) {
                    Text(
                        text = stringResource(titles[page]),
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = TextPrimary,
                        textAlign = TextAlign.Start
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = stringResource(descs[page]),
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF2C2C2C),
                        textAlign = TextAlign.Start
                    )
                    Spacer(Modifier.height(36.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(4) { i ->
                                val selected = i == page
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .then(
                                            if (selected) Modifier.background(PrimaryBlue)
                                            else Modifier.border(1.5.dp, PrimaryBlue, CircleShape)
                                        )
                                )
                            }
                        }
                        if (page < 3) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryBlue)
                                    .clickable(
                                        interactionSource = interaction,
                                        indication = null
                                    ) {
                                        scope.launch {
                                            pagerState.animateScrollToPage(page + 1)
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .width(128.dp)
                                    .height(46.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(PrimaryBlue)
                                    .clickable(
                                        interactionSource = interaction,
                                        indication = null,
                                        onClick = onFinished
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = stringResource(R.string.lets_start),
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
