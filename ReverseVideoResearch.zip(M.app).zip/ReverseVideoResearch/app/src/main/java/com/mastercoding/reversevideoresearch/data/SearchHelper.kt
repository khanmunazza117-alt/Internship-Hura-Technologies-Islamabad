package com.mastercoding.reversevideoresearch.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

object SearchHelper {

    const val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    @Volatile
    var pendingImageFile: File? = null

    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun googleTextUrl(query: String): String {
        val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name())
        return "https://www.google.com/search?q=$encoded&hl=en"
    }

    fun lensUploadByUrl(publicUrl: String): String {
        val encoded = URLEncoder.encode(publicUrl, StandardCharsets.UTF_8.name())
        return "https://lens.google.com/uploadbyurl?url=$encoded&hl=en"
    }

    fun googleSearchByImageHtml(jpegBase64: String): String {
        return """
            <!DOCTYPE html>
            <html>
            <head>
              <meta charset="utf-8"/>
              <meta name="viewport" content="width=device-width, initial-scale=1"/>
              <title>Searching</title>
              <style>
                body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;
                     height:100vh;margin:0;background:#F5F7FF;color:#6577E3}
              </style>
            </head>
            <body>
              <p>Uploading to Google Lens…</p>
              <form id="f" action="https://www.google.com/searchbyimage/upload" method="POST" enctype="multipart/form-data">
                <input id="file" type="file" name="encoded_image" accept="image/*"/>
                <input type="hidden" name="image_content" value=""/>
                <input type="hidden" name="filename" value="search.jpg"/>
                <input type="hidden" name="sbisrc" value="Google Chrome 131"/>
              </form>
              <script>
                var b64 = "$jpegBase64";
                function blobFromB64() {
                  var bin = atob(b64);
                  var arr = new Uint8Array(bin.length);
                  for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
                  return new Blob([arr], {type: "image/jpeg"});
                }
                function submitNow() {
                  var input = document.getElementById("file");
                  var form = document.getElementById("f");
                  try {
                    var file = new File([blobFromB64()], "search.jpg", {type: "image/jpeg"});
                    var dt = new DataTransfer();
                    dt.items.add(file);
                    input.files = dt.files;
                    if (input.files && input.files.length) {
                      form.submit();
                      return;
                    }
                  } catch (e) {}
                  input.addEventListener("change", function() {
                    if (input.files && input.files.length) form.submit();
                  });
                  input.click();
                }
                setTimeout(submitNow, 200);
              </script>
            </body>
            </html>
        """.trimIndent()
    }

    const val RESULT_IMAGE_COUNT_JS = """
(function(){
  var imgs = document.querySelectorAll('img');
  var real = 0;
  for (var i = 0; i < imgs.length; i++) {
    if (imgs[i].naturalWidth > 80) real++;
  }
  var t = (document.body && document.body.innerText) || '';
  if ((t.indexOf('Thinking') >= 0 || t.indexOf('Visually searched') >= 0) && real < 4) return 0;
  return real;
})();
"""

    suspend fun prepareUpload(source: File): PreparedUpload = withContext(Dispatchers.IO) {
        val bytes = compressJpeg(source)
        PreparedUpload(
            file = writeTemp(source, bytes),
            base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        )
    }

    suspend fun lensUrlFromHostedFile(file: File): String? = withContext(Dispatchers.IO) {
        val publicUrl = upload0x0(file) ?: uploadCatbox(file) ?: uploadTmpFiles(file)
        publicUrl?.let { lensUploadByUrl(it) }
    }

    suspend fun labelsQuery(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
        val image = InputImage.fromBitmap(bitmap, 0)
        labeler.process(image)
            .addOnSuccessListener { labels ->
                val query = labels.take(6).joinToString(" ") { it.text }
                labeler.close()
                if (cont.isActive) cont.resume(query)
            }
            .addOnFailureListener {
                labeler.close()
                if (cont.isActive) cont.resume("")
            }
    }

    fun uriFromPath(path: String): Uri = Uri.fromFile(File(path))

    private fun upload0x0(file: File): String? {
        return try {
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, file.asRequestBody("image/jpeg".toMediaType()))
                .build()
            val request = Request.Builder()
                .url("https://0x0.st")
                .header("User-Agent", "curl/8.4.0")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val url = response.body?.string()?.trim().orEmpty()
                if (response.isSuccessful && url.startsWith("http")) url else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun uploadCatbox(file: File): String? {
        return try {
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("reqtype", "fileupload")
                .addFormDataPart("fileToUpload", file.name, file.asRequestBody("image/jpeg".toMediaType()))
                .build()
            val request = Request.Builder()
                .url("https://catbox.moe/user/api.php")
                .header("User-Agent", USER_AGENT)
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val url = response.body?.string()?.trim().orEmpty()
                if (response.isSuccessful && url.startsWith("http")) url else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun uploadTmpFiles(file: File): String? {
        return try {
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, file.asRequestBody("image/jpeg".toMediaType()))
                .build()
            val request = Request.Builder()
                .url("https://tmpfiles.org/api/v1/upload")
                .header("User-Agent", USER_AGENT)
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val json = JSONObject(response.body?.string().orEmpty())
                val url = json.optJSONObject("data")?.optString("url").orEmpty()
                if (url.isBlank()) null else url.replace("tmpfiles.org/", "tmpfiles.org/dl/")
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun compressJpeg(source: File): ByteArray {
        val decoded = BitmapFactory.decodeFile(source.absolutePath)
            ?: return source.readBytes()
        val max = 1024
        val bitmap = if (decoded.width > max || decoded.height > max) {
            val scale = minOf(max.toFloat() / decoded.width, max.toFloat() / decoded.height)
            Bitmap.createScaledBitmap(
                decoded,
                (decoded.width * scale).toInt().coerceAtLeast(1),
                (decoded.height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else {
            decoded
        }
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return out.toByteArray()
    }

    private fun writeTemp(source: File, bytes: ByteArray): File {
        val dir = source.parentFile ?: File(source.absolutePath).parentFile ?: source
        val file = File(dir, "upload_${System.currentTimeMillis()}.jpg")
        file.writeBytes(bytes)
        return file
    }

    data class PreparedUpload(
        val file: File,
        val base64: String
    )
}
