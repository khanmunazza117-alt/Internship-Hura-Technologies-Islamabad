package com.mastercoding.reversevideoresearch.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme

/** Exact fill color of splash_img.png so the asset rectangle disappears into the screen. */
private val SplashBlue = Color(0xFF6577E3)
private val SplashPink = Color(0xFFFF4FA0)

@Composable
fun SplashScreen(
    isReturningUser: Boolean,
    onFinished: () -> Unit
) {
    ReverseVideoResearchTheme(lightStatusBars = false) {
        val progress = remember { Animatable(0.12f) }
        var showGetStarted by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            progress.animateTo(1f, tween(1800, easing = LinearEasing))
            if (isReturningUser) onFinished()
            else showGetStarted = true
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SplashBlue)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.weight(0.20f))
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.72f)
                        .aspectRatio(1588f / 1404f),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(R.drawable.splash_img),
                        contentDescription = stringResource(R.string.app_name),
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.FillBounds
                    )
                    Canvas(Modifier.fillMaxSize()) {
                        val y = size.height * 0.543f
                        drawLine(
                            color = SplashPink,
                            start = Offset(size.width * 0.12f, y),
                            end = Offset(size.width * 0.86f, y),
                            strokeWidth = size.height * 0.028f,
                            cap = StrokeCap.Round
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text(
                    text = stringResource(R.string.splash_title),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 28.sp,
                    lineHeight = 34.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))
                Canvas(
                    modifier = Modifier
                        .width(176.dp)
                        .height(4.dp)
                ) {
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.30f),
                        cornerRadius = CornerRadius(size.height / 2)
                    )
                    drawRoundRect(
                        color = Color.White,
                        size = Size(size.width * progress.value, size.height),
                        cornerRadius = CornerRadius(size.height / 2)
                    )
                }
                Spacer(Modifier.weight(0.42f))
                Box(
                    modifier = Modifier
                        .padding(horizontal = 32.dp)
                        .fillMaxWidth()
                        .height(52.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (!isReturningUser && showGetStarted) {
                        val interaction = remember { MutableInteractionSource() }
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(26.dp))
                                .background(Color.White)
                                .clickable(
                                    interactionSource = interaction,
                                    indication = null,
                                    onClick = onFinished
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stringResource(R.string.get_started),
                                color = Color(0xFF111111),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
                Spacer(Modifier.height(28.dp))
            }

            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height * 0.36f
                for (i in 1..9) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.055f),
                        radius = size.minDimension * (0.08f + i * 0.078f),
                        center = Offset(cx, cy),
                        style = Stroke(width = 2.4f)
                    )
                }
            }
        }
    }
}
