package com.mastercoding.reversevideoresearch.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.components.BottomBarSpacer
import com.mastercoding.reversevideoresearch.ui.components.PrimaryButton
import com.mastercoding.reversevideoresearch.ui.components.ScreenHeader
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLavender
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary
import com.mastercoding.reversevideoresearch.ui.theme.TextSecondary

@Composable
fun TextSearchScreen(
    onSearch: (String) -> Unit,
    onBack: () -> Unit
) {
    ReverseVideoResearchTheme {
        val context = LocalContext.current
        var text by rememberSaveable { mutableStateOf("") }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLavender)
        ) {
            ScreenHeader(title = stringResource(R.string.text_search), onBack = onBack)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                TextSearchHero(modifier = Modifier.fillMaxWidth())
            }
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .height(148.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .padding(16.dp)
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(end = 8.dp, bottom = 28.dp),
                    textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp, lineHeight = 20.sp),
                    cursorBrush = SolidColor(PrimaryBlue),
                    decorationBox = { inner ->
                        if (text.isEmpty()) {
                            Text(stringResource(R.string.text_hint), color = TextSecondary, fontSize = 14.sp)
                        }
                        inner()
                    }
                )
                Image(
                    painter = painterResource(R.drawable.ic_trash),
                    contentDescription = null,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(36.dp)
                        .clickable { text = "" },
                    contentScale = ContentScale.Fit
                )
            }
            BottomBarSpacer {
                PrimaryButton(
                    text = stringResource(R.string.search),
                    onClick = {
                        if (text.isBlank()) {
                            Toast.makeText(context, context.getString(R.string.enter_text), Toast.LENGTH_SHORT).show()
                        } else onSearch(text.trim())
                    }
                )
            }
        }
    }
}

@Composable
private fun TextSearchHero(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.aspectRatio(2240f / 1408f),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.ic_girl_voice_search),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
        )
        Canvas(Modifier.fillMaxSize()) {
            val lens = Offset(size.width * 0.805f, size.height * 0.625f)
            val r = size.minDimension * 0.105f
            drawCircle(color = PrimaryBlue, radius = r * 0.72f, center = lens)
            val tStroke = r * 0.28f
            drawLine(
                color = Color.White,
                start = Offset(lens.x - r * 0.42f, lens.y - r * 0.38f),
                end = Offset(lens.x + r * 0.42f, lens.y - r * 0.38f),
                strokeWidth = tStroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color.White,
                start = Offset(lens.x, lens.y - r * 0.38f),
                end = Offset(lens.x, lens.y + r * 0.48f),
                strokeWidth = tStroke,
                cap = StrokeCap.Round
            )
        }
    }
}
