package com.mastercoding.reversevideoresearch.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.theme.CropHandle
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary
import kotlin.math.roundToInt

@Composable
fun ScreenHeader(
    title: String,
    onBack: (() -> Unit)? = null,
    trailing: @Composable (BoxScope.() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(horizontal = 4.dp)
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart)) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(R.drawable.backbtn_img),
                    contentDescription = stringResource(R.string.cd_back),
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = TextPrimary,
            modifier = Modifier.align(Alignment.Center)
        )
        if (trailing != null) {
            Box(modifier = Modifier.align(Alignment.CenterEnd), content = trailing)
        }
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = PrimaryBlue,
            disabledContainerColor = PrimaryBlue.copy(alpha = 0.4f)
        ),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) {
        Text(text = text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun BottomBarSpacer(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        content()
    }
}

@Composable
fun WhiteCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(
                6.dp,
                RoundedCornerShape(24.dp),
                ambientColor = Color(0x14000000),
                spotColor = Color(0x1A000000)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        content()
    }
}

@Composable
fun CropOverlay(
    crop: Rect,
    onCropChange: (Rect) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val density = LocalDensity.current

        Canvas(modifier = Modifier.fillMaxSize()) {
            val cropPx = Rect(
                crop.left * size.width,
                crop.top * size.height,
                crop.right * size.width,
                crop.bottom * size.height
            )
            val dim = Path().apply {
                fillType = PathFillType.EvenOdd
                addRect(Rect(Offset.Zero, Size(size.width, size.height)))
                addRect(cropPx)
            }
            drawPath(dim, Color.Black.copy(alpha = 0.4f))
            drawRect(
                color = Color.White,
                topLeft = cropPx.topLeft,
                size = cropPx.size,
                style = Stroke(width = 3f)
            )
        }

        val handlePx = with(density) { 18.dp.toPx() }
        CornerHandle(crop.left * widthPx, crop.top * heightPx, handlePx) { dx, dy ->
            onCropChange(
                clampCrop(
                    Rect(
                        crop.left + dx / widthPx,
                        crop.top + dy / heightPx,
                        crop.right,
                        crop.bottom
                    )
                )
            )
        }
        CornerHandle(crop.right * widthPx, crop.top * heightPx, handlePx) { dx, dy ->
            onCropChange(
                clampCrop(
                    Rect(
                        crop.left,
                        crop.top + dy / heightPx,
                        crop.right + dx / widthPx,
                        crop.bottom
                    )
                )
            )
        }
        CornerHandle(crop.left * widthPx, crop.bottom * heightPx, handlePx) { dx, dy ->
            onCropChange(
                clampCrop(
                    Rect(
                        crop.left + dx / widthPx,
                        crop.top,
                        crop.right,
                        crop.bottom + dy / heightPx
                    )
                )
            )
        }
        CornerHandle(crop.right * widthPx, crop.bottom * heightPx, handlePx) { dx, dy ->
            onCropChange(
                clampCrop(
                    Rect(
                        crop.left,
                        crop.top,
                        crop.right + dx / widthPx,
                        crop.bottom + dy / heightPx
                    )
                )
            )
        }
    }
}

@Composable
private fun CornerHandle(x: Float, y: Float, handlePx: Float, onDrag: (Float, Float) -> Unit) {
    Box(
        modifier = Modifier
            .offset { IntOffset((x - handlePx).roundToInt(), (y - handlePx).roundToInt()) }
            .size(36.dp)
            .pointerInput(x, y) {
                detectDragGestures { change, drag ->
                    change.consume()
                    onDrag(drag.x, drag.y)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(CircleShape)
                .background(CropHandle)
                .border(2.dp, Color.White, CircleShape)
        )
    }
}

private fun clampCrop(rect: Rect): Rect {
    val min = 0.12f
    var left = rect.left.coerceIn(0f, 1f - min)
    var top = rect.top.coerceIn(0f, 1f - min)
    var right = rect.right.coerceIn(min, 1f)
    var bottom = rect.bottom.coerceIn(min, 1f)
    if (right - left < min) right = (left + min).coerceAtMost(1f)
    if (bottom - top < min) bottom = (top + min).coerceAtMost(1f)
    return Rect(left, top, right, bottom)
}

@Composable
fun ExitConfirmDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .padding(horizontal = 22.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.exit_title),
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 22.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF1F2F6))
                        .clickable(onClick = onDismiss),
                    contentAlignment = Alignment.Center
                ) {
                    Text(stringResource(R.string.no), fontWeight = FontWeight.SemiBold, color = TextPrimary)
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PrimaryBlue)
                        .clickable(onClick = onConfirm),
                    contentAlignment = Alignment.Center
                ) {
                    Text(stringResource(R.string.yes), fontWeight = FontWeight.SemiBold, color = Color.White)
                }
            }
        }
    }
}
