package com.mastercoding.reversevideoresearch.data

import org.json.JSONObject
import java.util.UUID

data class HistoryItem(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val query: String,
    val thumbnailPath: String = "",
    val mediaPath: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type)
        put("query", query)
        put("thumbnailPath", thumbnailPath)
        put("mediaPath", mediaPath)
        put("createdAt", createdAt)
    }

    companion object {
        const val TYPE_VIDEO = "video"
        const val TYPE_IMAGE = "image"
        const val TYPE_TEXT = "text"
        const val TYPE_VOICE = "voice"
        const val TYPE_URL = "url"

        fun fromJson(obj: JSONObject) = HistoryItem(
            id = obj.optString("id"),
            type = obj.optString("type"),
            query = obj.optString("query"),
            thumbnailPath = obj.optString("thumbnailPath"),
            mediaPath = obj.optString("mediaPath"),
            createdAt = obj.optLong("createdAt")
        )
    }
}
