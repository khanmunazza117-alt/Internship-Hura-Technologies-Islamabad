package com.mastercoding.reversevideoresearch.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLavender
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TermsScrim
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary

@Composable
fun TermsScreen(
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    ReverseVideoResearchTheme(lightStatusBars = false) {
        var agreed by rememberSaveable { mutableStateOf(false) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(TermsScrim)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(18.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(18.dp))
                    .background(BackgroundLavender)
                    .padding(horizontal = 22.dp, vertical = 24.dp)
            ) {
                Text(
                    text = stringResource(R.string.terms_title),
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(18.dp))
                Text(
                    text = stringResource(R.string.terms_body),
                    fontSize = 14.sp,
                    color = TextPrimary,
                    lineHeight = 22.sp,
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                )
                Spacer(Modifier.height(16.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { agreed = !agreed }
                        .padding(vertical = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .border(2.dp, if (agreed) PrimaryBlue else Color(0xFF9AA0B4), CircleShape)
                            .background(if (agreed) PrimaryBlue else Color.Transparent),
                        contentAlignment = Alignment.Center
                    ) {
                        if (agreed) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Text(
                        text = stringResource(R.string.i_agree),
                        fontSize = 13.sp,
                        color = TextPrimary,
                        modifier = Modifier.padding(start = 10.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .clickable(onClick = onDecline),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(stringResource(R.string.decline), fontWeight = FontWeight.SemiBold, color = Color.Black)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (agreed) PrimaryBlue else PrimaryBlue.copy(alpha = 0.4f))
                            .clickable(enabled = agreed, onClick = onAccept),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(stringResource(R.string.accept), fontWeight = FontWeight.SemiBold, color = Color.White)
                    }
                }
            }
        }
    }
}
