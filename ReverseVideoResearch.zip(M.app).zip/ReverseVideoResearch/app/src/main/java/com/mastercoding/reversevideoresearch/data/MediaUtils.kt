package com.mastercoding.reversevideoresearch.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.view.TextureView
import androidx.core.content.FileProvider
import androidx.media3.ui.PlayerView
import java.io.File
import java.io.FileOutputStream

object MediaUtils {

    fun copyToAppStorage(context: Context, uri: Uri, prefix: String, extension: String): File {
        val dir = File(context.filesDir, "media").apply { mkdirs() }
        val dest = File(dir, "${prefix}_${System.currentTimeMillis()}.$extension")
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Unable to read selected media")
        return dest
    }

    fun moveToAppStorage(context: Context, file: File, prefix: String): File {
        val dir = File(context.filesDir, "media").apply { mkdirs() }
        val ext = file.extension.ifBlank { "jpg" }
        val dest = File(dir, "${prefix}_${System.currentTimeMillis()}.$ext")
        file.copyTo(dest, overwrite = true)
        return dest
    }

    fun createCaptureFile(context: Context, prefix: String, extension: String): File {
        val dir = File(context.cacheDir, "capture").apply { mkdirs() }
        return File(dir, "${prefix}_${System.currentTimeMillis()}.$extension")
    }

    fun fileProviderUri(context: Context, file: File): Uri {
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun capturePlayerView(playerView: PlayerView): Bitmap? {
        val surface = playerView.videoSurfaceView
        if (surface is TextureView && surface.isAvailable) {
            val frame = surface.bitmap
            if (frame != null && frame.width > 2 && frame.height > 2) return frame
        }
        return null
    }

    fun extractVideoFrame(context: Context, uri: Uri, timeMs: Long = 0L): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val micros = (timeMs.coerceAtLeast(0L) * 1000L)
            val scaled = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                retriever.getScaledFrameAtTime(
                    micros,
                    MediaMetadataRetriever.OPTION_CLOSEST,
                    1280,
                    1280
                )
            } else {
                null
            }
            scaled
                ?: retriever.getFrameAtTime(micros, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: retriever.getFrameAtTime(micros, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.frameAtTime
        } catch (_: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    fun decodeBitmap(path: String, maxSize: Int = 1600): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        val sample = sampleSize(bounds.outWidth, bounds.outHeight, maxSize)
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(path, opts)
    }

    fun applyTransforms(
        source: Bitmap,
        rotationDeg: Float,
        flipHorizontal: Boolean,
        cropNorm: androidx.compose.ui.geometry.Rect?
    ): Bitmap {
        val matrix = Matrix().apply {
            postRotate(rotationDeg)
            if (flipHorizontal) {
                postScale(-1f, 1f)
            }
        }
        var result = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        if (cropNorm != null) {
            val left = (cropNorm.left * result.width).toInt().coerceIn(0, result.width - 1)
            val top = (cropNorm.top * result.height).toInt().coerceIn(0, result.height - 1)
            val right = (cropNorm.right * result.width).toInt().coerceIn(left + 1, result.width)
            val bottom = (cropNorm.bottom * result.height).toInt().coerceIn(top + 1, result.height)
            result = Bitmap.createBitmap(result, left, top, right - left, bottom - top)
        }
        return result
    }

    fun saveJpeg(context: Context, bitmap: Bitmap, prefix: String = "search"): File {
        val dir = File(context.filesDir, "media").apply { mkdirs() }
        val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        return file
    }

    fun saveThumbnail(context: Context, bitmap: Bitmap): File {
        val dir = File(context.filesDir, "thumbs").apply { mkdirs() }
        val file = File(dir, "thumb_${System.currentTimeMillis()}.jpg")
        val scaled = scaleDown(bitmap, 400)
        FileOutputStream(file).use { out ->
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
        }
        return file
    }

    private fun scaleDown(bitmap: Bitmap, max: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= max && h <= max) return bitmap
        val scale = minOf(max.toFloat() / w, max.toFloat() / h)
        return Bitmap.createScaledBitmap(bitmap, (w * scale).toInt(), (h * scale).toInt(), true)
    }

    private fun sampleSize(width: Int, height: Int, maxSize: Int): Int {
        var sample = 1
        var w = width
        var h = height
        while (w / sample > maxSize || h / sample > maxSize) {
            sample *= 2
        }
        return sample
    }

    fun extensionFor(uri: Uri, fallback: String): String {
        val last = uri.lastPathSegment.orEmpty().lowercase()
        return when {
            last.endsWith(".png") -> "png"
            last.endsWith(".webp") -> "webp"
            last.endsWith(".mp4") -> "mp4"
            last.endsWith(".mov") -> "mp4"
            last.endsWith(".3gp") -> "3gp"
            last.endsWith(".jpg") || last.endsWith(".jpeg") -> "jpg"
            fallback == "video" -> "mp4"
            else -> "jpg"
        }
    }
}
