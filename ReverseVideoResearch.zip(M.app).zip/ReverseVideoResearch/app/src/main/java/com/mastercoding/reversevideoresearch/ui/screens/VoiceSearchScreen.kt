package com.mastercoding.reversevideoresearch.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.ui.components.BottomBarSpacer
import com.mastercoding.reversevideoresearch.ui.components.PrimaryButton
import com.mastercoding.reversevideoresearch.ui.components.ScreenHeader
import com.mastercoding.reversevideoresearch.ui.theme.AccentYellow
import com.mastercoding.reversevideoresearch.ui.theme.BackgroundLavender
import com.mastercoding.reversevideoresearch.ui.theme.IconBlue
import com.mastercoding.reversevideoresearch.ui.theme.MicRing
import com.mastercoding.reversevideoresearch.ui.theme.PrimaryBlue
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.TextPrimary
import com.mastercoding.reversevideoresearch.ui.theme.WaveFill
import java.util.Locale

@Composable
fun VoiceSearchScreen(
    onSearch: (String) -> Unit,
    onBack: () -> Unit
) {
    ReverseVideoResearchTheme {
        val context = LocalContext.current
        var transcript by remember { mutableStateOf("") }
        var listening by remember { mutableStateOf(false) }
        val recognizer = remember {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                SpeechRecognizer.createSpeechRecognizer(context)
            } else null
        }

        DisposableEffect(recognizer) {
            onDispose { recognizer?.destroy() }
        }

        fun startListening() {
            val r = recognizer ?: run {
                Toast.makeText(context, context.getString(R.string.no_speech), Toast.LENGTH_SHORT).show()
                return
            }
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    listening = false
                    Toast.makeText(context, context.getString(R.string.no_speech), Toast.LENGTH_SHORT).show()
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    transcript = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!partial.isNullOrBlank()) transcript = partial
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            listening = true
            r.startListening(intent)
        }

        val micLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { ok ->
            if (ok) startListening()
            else Toast.makeText(context, context.getString(R.string.mic_permission_required), Toast.LENGTH_SHORT).show()
        }

        fun requestAndListen() {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            ) startListening()
            else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundLavender)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                ScreenHeader(title = stringResource(R.string.voice_search), onBack = onBack)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(R.drawable.ic_girl_voice_search),
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit
                    )
                }
                if (transcript.isBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                            .background(Color.White)
                            .navigationBarsPadding()
                            .padding(top = 36.dp, bottom = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        androidx.compose.foundation.Image(
                            painter = androidx.compose.ui.res.painterResource(R.drawable.ic_tap_to_record),
                            contentDescription = stringResource(R.string.tap_to_record),
                            modifier = Modifier
                                .size(96.dp)
                                .clickable { requestAndListen() },
                            contentScale = androidx.compose.ui.layout.ContentScale.Fit
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(
                            text = stringResource(R.string.tap_to_record),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary
                        )
                        Spacer(Modifier.height(24.dp))
                    }
                } else {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 20.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color.White)
                                .padding(16.dp)
                        ) {
                            Text(transcript, color = TextPrimary, fontSize = 14.sp, lineHeight = 20.sp)
                            androidx.compose.foundation.Image(
                                painter = androidx.compose.ui.res.painterResource(R.drawable.ic_trash),
                                contentDescription = null,
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(36.dp)
                                    .clickable { transcript = "" },
                                contentScale = androidx.compose.ui.layout.ContentScale.Fit
                            )
                        }
                        BottomBarSpacer {
                            PrimaryButton(
                                text = stringResource(R.string.search),
                                onClick = { onSearch(transcript) }
                            )
                        }
                    }
                }
            }

            if (listening) {
                Dialog(onDismissRequest = { }) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White)
                            .padding(horizontal = 36.dp, vertical = 28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        androidx.compose.foundation.Image(
                            painter = androidx.compose.ui.res.painterResource(R.drawable.ic_tap_to_record),
                            contentDescription = stringResource(R.string.listening),
                            modifier = Modifier.size(84.dp),
                            contentScale = androidx.compose.ui.layout.ContentScale.Fit
                        )
                    }
                }
            }
        }
    }
}

