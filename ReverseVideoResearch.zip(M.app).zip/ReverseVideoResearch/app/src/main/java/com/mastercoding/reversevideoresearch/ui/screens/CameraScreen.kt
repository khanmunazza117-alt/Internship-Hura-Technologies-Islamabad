package com.mastercoding.reversevideoresearch.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.mastercoding.reversevideoresearch.R
import com.mastercoding.reversevideoresearch.data.MediaUtils
import com.mastercoding.reversevideoresearch.ui.theme.RecordingRed
import com.mastercoding.reversevideoresearch.ui.theme.ReverseVideoResearchTheme
import com.mastercoding.reversevideoresearch.ui.theme.ShutterRing
import java.io.File
import java.util.concurrent.Executors

@Composable
fun CameraScreen(
    isVideo: Boolean,
    onCaptured: (String) -> Unit,
    onBack: () -> Unit
) {
    ReverseVideoResearchTheme(lightStatusBars = false) {
        val context = LocalContext.current
        val lifecycleOwner = LocalLifecycleOwner.current
        var granted by remember { mutableStateOf(false) }
        val needed = buildList {
            add(Manifest.permission.CAMERA)
            if (isVideo) add(Manifest.permission.RECORD_AUDIO)
        }.toTypedArray()

        val launcher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            granted = result[Manifest.permission.CAMERA] == true
            if (!granted) {
                Toast.makeText(context, context.getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                onBack()
            }
        }

        LaunchedEffect(Unit) {
            val ok = needed.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
            if (ok) granted = true else launcher.launch(needed)
        }

        if (!granted) {
            Box(Modifier.fillMaxSize().background(Color.Black))
            return@ReverseVideoResearchTheme
        }

        val previewView = remember {
            PreviewView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }
        }
        val imageCapture = remember { ImageCapture.Builder().build() }
        val videoCapture = remember {
            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.HD))
                .build()
            VideoCapture.withOutput(recorder)
        }
        var recording by remember { mutableStateOf<Recording?>(null) }
        var isRecording by remember { mutableStateOf(false) }
        val executor = remember { Executors.newSingleThreadExecutor() }

        DisposableEffect(lifecycleOwner, isVideo) {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            val listener = Runnable {
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                try {
                    cameraProvider.unbindAll()
                    val useCases = if (isVideo) {
                        arrayOf(preview, videoCapture)
                    } else {
                        arrayOf(preview, imageCapture)
                    }
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        *useCases
                    )
                } catch (e: Exception) {
                    Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
                    onBack()
                }
            }
            cameraProviderFuture.addListener(listener, ContextCompat.getMainExecutor(context))
            onDispose {
                recording?.stop()
                runCatching { ProcessCameraProvider.getInstance(context).get().unbindAll() }
                executor.shutdown()
            }
        }

        fun capturePhoto() {
            val file = MediaUtils.createCaptureFile(context, "IMG", "jpg")
            val opts = ImageCapture.OutputFileOptions.Builder(file).build()
            imageCapture.takePicture(
                opts,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        val stored = MediaUtils.moveToAppStorage(context, file, "IMG")
                        onCaptured(stored.absolutePath)
                    }

                    override fun onError(exception: ImageCaptureException) {
                        Toast.makeText(context, exception.message, Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        fun toggleVideo() {
            if (isRecording) {
                recording?.stop()
                recording = null
                isRecording = false
            } else {
                val file = MediaUtils.createCaptureFile(context, "VID", "mp4")
                val output = FileOutputOptions.Builder(file).build()
                var pending = videoCapture.output.prepareRecording(context, output)
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    pending = pending.withAudioEnabled()
                }
                recording = pending.start(ContextCompat.getMainExecutor(context)) { event ->
                    when (event) {
                        is VideoRecordEvent.Start -> isRecording = true
                        is VideoRecordEvent.Finalize -> {
                            isRecording = false
                            if (!event.hasError()) {
                                val stored = copyOrUse(file, context)
                                onCaptured(stored)
                            }
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(8.dp)
                    .align(Alignment.TopStart)
            ) {
                Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
            }
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 28.dp)
                    .size(78.dp)
                    .clip(CircleShape)
                    .border(6.dp, if (isRecording) RecordingRed else ShutterRing, CircleShape)
                    .background(Color.White)
                    .clickable {
                        if (isVideo) toggleVideo() else capturePhoto()
                    }
            )
        }
    }
}

private fun copyOrUse(file: File, context: android.content.Context): String {
    return try {
        MediaUtils.moveToAppStorage(context, file, "VID").absolutePath
    } catch (_: Exception) {
        file.absolutePath
    }
}
