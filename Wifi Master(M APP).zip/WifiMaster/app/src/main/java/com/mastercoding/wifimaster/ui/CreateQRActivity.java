package com.mastercoding.wifimaster.ui;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.mastercoding.wifimaster.R;

public class CreateQRActivity extends AppCompatActivity {

    private ImageView btnBack, imgQR;

    private EditText edtSSID, edtPassword;

    private RadioButton rbWEP, rbWPA;

    private Button btnGenerate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_qr);

        btnBack = findViewById(R.id.btnBack);
        imgQR = findViewById(R.id.imgQR);

        edtSSID = findViewById(R.id.edtSSID);
        edtPassword = findViewById(R.id.edtPassword);

        rbWEP = findViewById(R.id.rbWEP);
        rbWPA = findViewById(R.id.rbWPA);

        btnGenerate = findViewById(R.id.btnGenerate);

        btnBack.setOnClickListener(v -> finish());

        btnGenerate.setOnClickListener(v -> generateQRCode());
    }

    private void generateQRCode() {

        String ssid = edtSSID.getText().toString().trim();
        String password = edtPassword.getText().toString().trim();

        if (ssid.isEmpty()) {
            edtSSID.setError("Enter WiFi SSID");
            return;
        }

        if (password.isEmpty()) {
            edtPassword.setError("Enter WiFi Password");
            return;
        }

        String authType = rbWEP.isChecked() ? "WEP" : "WPA";

        String wifiData = "WIFI:T:" + authType +
                ";S:" + ssid +
                ";P:" + password +
                ";;";

        try {

            BitMatrix bitMatrix = new MultiFormatWriter().encode(
                    wifiData,
                    BarcodeFormat.QR_CODE,
                    700,
                    700
            );

            Bitmap bitmap = Bitmap.createBitmap(
                    700,
                    700,
                    Bitmap.Config.RGB_565
            );

            for (int x = 0; x < 700; x++) {
                for (int y = 0; y < 700; y++) {
                    bitmap.setPixel(
                            x,
                            y,
                            bitMatrix.get(x, y)
                                    ? 0xFF000000
                                    : 0xFFFFFFFF
                    );
                }
            }

            imgQR.setImageBitmap(bitmap);
            imgQR.setVisibility(View.VISIBLE);

        } catch (Exception e) {
            e.printStackTrace();

            Toast.makeText(
                    this,
                    "QR Generation Failed",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}