package com.mastercoding.wifimaster.ui;

import android.os.Build;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.mastercoding.wifimaster.R;

public class PhoneInfoActivity extends AppCompatActivity {

    private ImageView btnBack;

    private TextView txtKernel;
    private TextView txtApi;
    private TextView txtDevice;
    private TextView txtModel;
    private TextView txtProduct;
    private TextView txtRelease;
    private TextView txtIncremental;
    private TextView txtSdk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_info);

        btnBack = findViewById(R.id.btnBack);

        txtKernel = findViewById(R.id.txtKernel);
        txtApi = findViewById(R.id.txtApi);
        txtDevice = findViewById(R.id.txtDevice);
        txtModel = findViewById(R.id.txtModel);
        txtProduct = findViewById(R.id.txtProduct);

        txtSdk = findViewById(R.id.txtSdk);

//        txtRelease = findViewById(R.id.txtRelease);
//        txtIncremental = findViewById(R.id.txtIncremental);

        btnBack.setOnClickListener(v -> finish());

        loadPhoneInformation();
    }

    private void loadPhoneInformation() {

        txtKernel.setText(System.getProperty("os.version"));

        txtApi.setText(String.valueOf(Build.VERSION.SDK_INT));

        txtDevice.setText(Build.DEVICE);

        txtModel.setText(Build.MODEL);

        txtProduct.setText(Build.PRODUCT);

//        txtRelease.setText(Build.VERSION.RELEASE);
//
//        txtIncremental.setText(Build.VERSION.INCREMENTAL);

        txtSdk.setText(String.valueOf(Build.VERSION.SDK_INT));
    }
}