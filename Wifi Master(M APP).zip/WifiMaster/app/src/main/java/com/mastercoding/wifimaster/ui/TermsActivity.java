package com.mastercoding.wifimaster.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.mastercoding.wifimaster.MainActivity;
import com.mastercoding.wifimaster.R;

public class TermsActivity extends AppCompatActivity {

    Button btnAccept, btnDecline;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms);

        btnAccept = findViewById(R.id.btnAccept);
        btnDecline = findViewById(R.id.btnDecline);

        btnAccept.setOnClickListener(v -> {

            SharedPreferences preferences =
                    getSharedPreferences("WifiMaster", MODE_PRIVATE);

            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("termsAccepted", true);
            editor.apply();

            startActivity(new Intent(
                    TermsActivity.this,
                    MainActivity.class));

            finish();

        });

        btnDecline.setOnClickListener(v -> finish());

    }
}