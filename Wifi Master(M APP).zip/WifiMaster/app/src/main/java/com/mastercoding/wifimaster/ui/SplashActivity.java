package com.mastercoding.wifimaster.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.mastercoding.wifimaster.MainActivity;
import com.mastercoding.wifimaster.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {

            SharedPreferences preferences =
                    getSharedPreferences("WifiMaster", MODE_PRIVATE);

            boolean accepted =
                    preferences.getBoolean("termsAccepted", false);

            if (accepted) {

                startActivity(new Intent(
                        SplashActivity.this,
                        MainActivity.class));

            } else {

                startActivity(new Intent(
                        SplashActivity.this,
                        TermsActivity.class));

            }

            finish();

        }, 2000);

    }
}