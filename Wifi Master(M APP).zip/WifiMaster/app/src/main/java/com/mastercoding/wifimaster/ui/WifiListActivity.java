package com.mastercoding.wifimaster.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mastercoding.wifimaster.R;

import java.util.ArrayList;
import java.util.List;

public class WifiListActivity extends AppCompatActivity {

    private RecyclerView recyclerWifi;
    private ImageView btnBack;

    private WifiManager wifiManager;
    private WifiAdapter adapter;

    private final List<ScanResult> wifiList = new ArrayList<>();

    private static final int LOCATION_REQUEST = 100;

    private final BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            showWifiList();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_list);

        recyclerWifi = findViewById(R.id.recyclerWifi);
        btnBack = findViewById(R.id.btnBack);

        recyclerWifi.setLayoutManager(new LinearLayoutManager(this));

        btnBack.setOnClickListener(v -> showExitDialog());

        getOnBackPressedDispatcher().addCallback(
                this,
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        showExitDialog();
                    }
                });

        wifiManager =
                (WifiManager) getApplicationContext()
                        .getSystemService(WIFI_SERVICE);

        if (wifiManager == null) {
            Toast.makeText(
                    this,
                    "WiFi service unavailable",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (!wifiManager.isWifiEnabled()) {

            Toast.makeText(
                    this,
                    "Please turn ON WiFi",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        checkPermissionAndScan();
    }

    private void checkPermissionAndScan() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        LOCATION_REQUEST);

                return;
            }
        }

        startWifiScan();
    }

    private void startWifiScan() {

        registerReceiver(
                wifiReceiver,
                new IntentFilter(
                        WifiManager.SCAN_RESULTS_AVAILABLE_ACTION
                )
        );

        boolean started = wifiManager.startScan();

        if (!started) {
            showWifiList();
        }
    }

    private void showExitDialog() {

        View view = getLayoutInflater()
                .inflate(R.layout.dialog_exit, null);

        Button btnYes = view.findViewById(R.id.btnYes);
        Button btnNo = view.findViewById(R.id.btnNo);

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setView(view)
                        .create();

        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(
                    android.R.color.transparent
            );
        }

        btnNo.setOnClickListener(v -> dialog.dismiss());

        btnYes.setOnClickListener(v -> {
            dialog.dismiss();
            finish();
        });
    }

    private void showWifiList() {

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        wifiList.clear();

        List<ScanResult> results = wifiManager.getScanResults();

        if (results != null) {

            for (ScanResult result : results) {

                if (result != null
                        && result.SSID != null
                        && !result.SSID.trim().isEmpty()) {

                    wifiList.add(result);

                }

            }

        }

        if (adapter == null) {

            adapter = new WifiAdapter(this, wifiList);
            recyclerWifi.setAdapter(adapter);

        } else {

            adapter.notifyDataSetChanged();

        }

        if (wifiList.isEmpty()) {

            Toast.makeText(
                    this,
                    "No WiFi networks found.",
                    Toast.LENGTH_SHORT
            ).show();

        }

    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults);

        if (requestCode == LOCATION_REQUEST) {

            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {

                startWifiScan();

            } else {

                Toast.makeText(
                        this,
                        "Location permission required.",
                        Toast.LENGTH_SHORT
                ).show();

            }

        }

    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        try {

            unregisterReceiver(wifiReceiver);

        } catch (Exception ignored) {

        }

    }

}