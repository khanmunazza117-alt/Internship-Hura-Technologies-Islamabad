package com.mastercoding.wifimaster.ui;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mastercoding.wifimaster.R;

import java.util.ArrayList;

public class SavedWifiActivity extends AppCompatActivity {

    private ImageView btnBack;

    private RecyclerView recyclerSavedWifi;

    private TextView txtEmpty;

    private ArrayList<String> wifiNames;
    private ArrayList<String> wifiPasswords;

    private SavedWifiAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_wifi);

        btnBack = findViewById(R.id.btnBack);

        recyclerSavedWifi = findViewById(R.id.recyclerSavedWifi);

        txtEmpty = findViewById(R.id.txtEmpty);

        btnBack.setOnClickListener(v -> finish());

        wifiNames = new ArrayList<>();
        wifiPasswords = new ArrayList<>();

        /*
         * Dummy Data
         * Later we'll replace this with SharedPreferences.
         */

        wifiNames.add("PTCL-BB");
        wifiPasswords.add("123456789");

        wifiNames.add("StormFiber");
        wifiPasswords.add("storm123");

        wifiNames.add("Nayatel");
        wifiPasswords.add("nayatel786");

        adapter = new SavedWifiAdapter(
                this,
                wifiNames,
                wifiPasswords
        );

        recyclerSavedWifi.setLayoutManager(
                new LinearLayoutManager(this)
        );

        recyclerSavedWifi.setAdapter(adapter);

        checkEmpty();
    }

    private void checkEmpty() {

        if (wifiNames.isEmpty()) {

            txtEmpty.setVisibility(TextView.VISIBLE);

            recyclerSavedWifi.setVisibility(RecyclerView.GONE);

        } else {

            txtEmpty.setVisibility(TextView.GONE);

            recyclerSavedWifi.setVisibility(RecyclerView.VISIBLE);

        }

    }

}