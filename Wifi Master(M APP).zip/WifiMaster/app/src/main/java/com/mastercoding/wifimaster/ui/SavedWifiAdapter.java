package com.mastercoding.wifimaster.ui;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mastercoding.wifimaster.R;

import java.util.ArrayList;

public class SavedWifiAdapter extends RecyclerView.Adapter<SavedWifiAdapter.ViewHolder> {

    private final Context context;
    private final ArrayList<String> ssidList;
    private final ArrayList<String> passwordList;

    public SavedWifiAdapter(Context context,
                            ArrayList<String> ssidList,
                            ArrayList<String> passwordList) {

        this.context = context;
        this.ssidList = ssidList;
        this.passwordList = passwordList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                         int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.saved_wifi_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder,
                                 int position) {

        holder.txtSSID.setText(ssidList.get(position));

        holder.txtPassword.setText(passwordList.get(position));

        holder.imgCopy.setOnClickListener(v -> {

            ClipboardManager clipboard =
                    (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);

            ClipData clip = ClipData.newPlainText(
                    "Password",
                    passwordList.get(position));

            clipboard.setPrimaryClip(clip);

            Toast.makeText(
                    context,
                    "Password Copied",
                    Toast.LENGTH_SHORT
            ).show();

        });

        holder.imgDelete.setOnClickListener(v -> {

            ssidList.remove(position);
            passwordList.remove(position);

            notifyItemRemoved(position);
            notifyItemRangeChanged(position, getItemCount());

            Toast.makeText(
                    context,
                    "Deleted",
                    Toast.LENGTH_SHORT
            ).show();

        });

    }

    @Override
    public int getItemCount() {
        return ssidList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtSSID;
        TextView txtPassword;

        ImageView imgCopy;
        ImageView imgDelete;

        ViewHolder(View itemView) {
            super(itemView);

            txtSSID = itemView.findViewById(R.id.txtSSID);
            txtPassword = itemView.findViewById(R.id.txtPassword);

            imgCopy = itemView.findViewById(R.id.imgCopy);
            imgDelete = itemView.findViewById(R.id.imgDelete);
        }
    }
}
