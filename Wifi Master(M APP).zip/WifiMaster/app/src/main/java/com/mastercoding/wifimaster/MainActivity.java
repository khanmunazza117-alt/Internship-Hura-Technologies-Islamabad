package com.mastercoding.wifimaster;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.mastercoding.wifimaster.ui.CreateQRActivity;
import com.mastercoding.wifimaster.ui.PasswordGeneratorActivity;
import com.mastercoding.wifimaster.ui.PhoneInfoActivity;
import com.mastercoding.wifimaster.ui.PrivacyPolicyActivity;
import com.mastercoding.wifimaster.ui.QRScannerActivity;
import com.mastercoding.wifimaster.ui.SavedWifiActivity;
import com.mastercoding.wifimaster.ui.WifiListActivity;
import com.mastercoding.wifimaster.ui.HotspotActivity;
public class MainActivity extends AppCompatActivity {

    CardView cardWifi, cardQrScanner, cardPassword,
            cardCreateQr, cardSavedWifi,
            cardHotspot, cardPhoneInfo, cardPrivacy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardWifi = findViewById(R.id.cardWifi);
        cardQrScanner = findViewById(R.id.cardQrScanner);
        cardPassword = findViewById(R.id.cardPassword);
        cardCreateQr = findViewById(R.id.cardCreateQr);
        cardSavedWifi = findViewById(R.id.cardSavedWifi);
        cardHotspot = findViewById(R.id.cardHotspot);
        cardPhoneInfo = findViewById(R.id.cardPhoneInfo);
        cardPrivacy = findViewById(R.id.cardPrivacy);

        cardWifi.setOnClickListener(v ->
                startActivity(new Intent(this, WifiListActivity.class)));

        cardQrScanner.setOnClickListener(v ->
                startActivity(new Intent(this, QRScannerActivity.class)));

        cardPassword.setOnClickListener(v ->
                startActivity(new Intent(this, PasswordGeneratorActivity.class)));

        cardCreateQr.setOnClickListener(v ->
                startActivity(new Intent(this, CreateQRActivity.class)));

        cardSavedWifi.setOnClickListener(v ->
                startActivity(new Intent(this, SavedWifiActivity.class)));

        cardPhoneInfo.setOnClickListener(v ->
                startActivity(new Intent(this, PhoneInfoActivity.class)));

        cardPrivacy.setOnClickListener(v ->
                startActivity(new Intent(this, PrivacyPolicyActivity.class)));

        cardHotspot.setOnClickListener(v ->
                startActivity(new Intent(this, HotspotActivity.class)));
    }
}