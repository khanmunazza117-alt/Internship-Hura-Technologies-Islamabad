package com.mastercoding.wifimaster.ui;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.mastercoding.wifimaster.R;

import java.util.Random;

public class PasswordGeneratorActivity extends AppCompatActivity {

    private ImageView btnBack;
    private ImageView imgCopy;

    private CheckBox chUpper;
    private CheckBox chLower;
    private CheckBox chNumber;
    private CheckBox chSymbol;

    private SeekBar seekLength;

    private TextView txtPassword;

    private MaterialButton btnGenerate;

    private int passwordLength = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_generator);

        btnBack = findViewById(R.id.btnBack);
        imgCopy = findViewById(R.id.imgCopy);

        chUpper = findViewById(R.id.chUpper);
        chLower = findViewById(R.id.chLower);
        chNumber = findViewById(R.id.chNumber);
        chSymbol = findViewById(R.id.chSymbol);

        seekLength = findViewById(R.id.seekLength);

        txtPassword = findViewById(R.id.txtPassword);

        btnGenerate = findViewById(R.id.btnGenerate);

        // Default selection
        chUpper.setChecked(true);
        chLower.setChecked(true);
        chNumber.setChecked(true);

        seekLength.setMax(20);
        seekLength.setProgress(10);

        seekLength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                if (progress < 4) {

                    seekBar.setProgress(4);
                    passwordLength = 4;

                } else {

                    passwordLength = progress;

                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btnGenerate.setOnClickListener(v -> {

            txtPassword.setText(generatePassword());

        });

        imgCopy.setOnClickListener(v -> {

            String password = txtPassword.getText().toString();

            if (password.isEmpty()) {

                Toast.makeText(this,
                        "Generate password first",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            ClipboardManager clipboard =
                    (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);

            ClipData clip = ClipData.newPlainText("Password", password);

            clipboard.setPrimaryClip(clip);

            Toast.makeText(this,
                    "Copied",
                    Toast.LENGTH_SHORT).show();

        });

        btnBack.setOnClickListener(v -> finish());

    }

    private String generatePassword() {

        String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lower = "abcdefghijklmnopqrstuvwxyz";
        String number = "0123456789";
        String symbol = "@#$%&*!?";

        StringBuilder characters = new StringBuilder();

        if (chUpper.isChecked())
            characters.append(upper);

        if (chLower.isChecked())
            characters.append(lower);

        if (chNumber.isChecked())
            characters.append(number);

        if (chSymbol.isChecked())
            characters.append(symbol);

        if (characters.length() == 0) {

            Toast.makeText(this,
                    "Select at least one option",
                    Toast.LENGTH_SHORT).show();

            return "";

        }

        Random random = new Random();

        StringBuilder password = new StringBuilder();

        for (int i = 0; i < passwordLength; i++) {

            int index = random.nextInt(characters.length());

            password.append(characters.charAt(index));

        }

        return password.toString();

    }

}