package com.mastercoding.wifimaster.ui;


import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.mastercoding.wifimaster.R;


public class PrivacyPolicyActivity extends AppCompatActivity {


    private ImageView btnBack;
    private TextView txtPolicy;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_privacy_policy);



        btnBack = findViewById(R.id.btnBack);

        txtPolicy = findViewById(R.id.txtPolicy);




        btnBack.setOnClickListener(v -> finish());





        txtPolicy.setText(

                "Your privacy is important to us.\n\n" +

                        "• Wifi Master does not collect or store your personal information.\n\n" +

                        "• Camera permission is only used to scan QR codes.\n\n" +

                        "• Location permission is required by Android to scan nearby WiFi networks.\n\n" +

                        "• Generated passwords and QR codes remain only on your device.\n\n" +

                        "• We do not share your WiFi information with any third party.\n\n" +

                        "• By using this application you agree to these terms and conditions."

        );



    }

}