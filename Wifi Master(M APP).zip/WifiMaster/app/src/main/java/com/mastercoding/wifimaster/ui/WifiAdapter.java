package com.mastercoding.wifimaster.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.mastercoding.wifimaster.R;

import java.util.List;


public class WifiAdapter extends RecyclerView.Adapter<WifiAdapter.ViewHolder> {


    private Context context;
    private List<ScanResult> wifiList;


    public WifiAdapter(Context context, List<ScanResult> wifiList) {

        this.context = context;
        this.wifiList = wifiList;

    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        View view = LayoutInflater.from(context)
                .inflate(R.layout.dashboard_item, parent, false);


        return new ViewHolder(view);

    }



    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        ScanResult wifi = wifiList.get(position);



        // WIFI NAME

        String wifiName;


        if(wifi.SSID == null || wifi.SSID.trim().isEmpty()){

            wifiName = "Hidden Network";

        }
        else{

            wifiName = wifi.SSID;

        }



        holder.txtWifiName.setText(wifiName);



        // SECURITY TYPE

        String security = wifi.capabilities;


        if(security.contains("WPA3")){

            holder.txtSecurity.setText("WPA3 Secured");

        }

        else if(security.contains("WPA2")){

            holder.txtSecurity.setText("WPA2 Secured");

        }

        else if(security.contains("WPA")){

            holder.txtSecurity.setText("WPA Secured");

        }

        else{

            holder.txtSecurity.setText("Open Network");

        }





        // SIGNAL STRENGTH

        int level = WifiManager.calculateSignalLevel(
                wifi.level,
                4
        );



        switch(level){


            case 3:

                holder.imgSignal.setImageResource(
                        R.drawable.signal_full
                );

                break;



            case 2:

                holder.imgSignal.setImageResource(
                        R.drawable.signal_medium
                );

                break;



            case 1:

                holder.imgSignal.setImageResource(
                        R.drawable.signal_low
                );

                break;



            default:

                holder.imgSignal.setImageResource(
                        R.drawable.signal_empty
                );

                break;


        }





        // CARD CLICK

        holder.itemView.setOnClickListener(v -> {



            holder.itemView.animate()
                    .scaleX(0.96f)
                    .scaleY(0.96f)
                    .setDuration(100)
                    .withEndAction(() -> {


                        holder.itemView.animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .setDuration(100)
                                .start();


                    })
                    .start();



            showConnectDialog(wifiName);



        });



    }




    @Override
    public int getItemCount() {

        return wifiList == null ? 0 : wifiList.size();

    }





    public class ViewHolder extends RecyclerView.ViewHolder{


        TextView txtWifiName;
        TextView txtSecurity;

        ImageView imgSignal;



        public ViewHolder(@NonNull View itemView) {

            super(itemView);


            txtWifiName =
                    itemView.findViewById(R.id.txtWifiName);


            txtSecurity =
                    itemView.findViewById(R.id.txtSecurity);



            imgSignal =
                    itemView.findViewById(R.id.imgSignal);


        }


    }






    private void showConnectDialog(String wifiName){



        View view = LayoutInflater.from(context)
                .inflate(
                        R.layout.dialog_connect_wifi,
                        null
                );



        TextView txtNetwork =
                view.findViewById(R.id.txtNetworkName);



        EditText edtPassword =
                view.findViewById(R.id.edtPassword);



        MaterialButton btnCancel =
                view.findViewById(R.id.btnCancel);



        MaterialButton btnConnect =
                view.findViewById(R.id.btnConnect);




        txtNetwork.setText(wifiName);





        AlertDialog dialog =
                new AlertDialog.Builder(context)
                        .setView(view)
                        .create();




        dialog.show();




        if(dialog.getWindow()!=null){


            dialog.getWindow().setLayout(

                    (int)
                            (
                                    context.getResources()
                                            .getDisplayMetrics()
                                            .widthPixels
                                            *
                                            0.85
                            ),

                    ViewGroup.LayoutParams.WRAP_CONTENT

            );


        }





        btnCancel.setOnClickListener(v -> {


            dialog.dismiss();


        });







        btnConnect.setOnClickListener(v -> {



            String password =
                    edtPassword.getText()
                            .toString()
                            .trim();




            if(password.isEmpty()){


                edtPassword.setError(
                        "Enter Password"
                );


                return;


            }





            btnConnect.setEnabled(false);

            btnConnect.setText(
                    "Connecting..."
            );







            new Handler().postDelayed(() -> {



                Toast.makeText(
                        context,
                        "Connected to " + wifiName,
                        Toast.LENGTH_SHORT
                ).show();



                dialog.dismiss();



            },1800);




        });



    }



}