package com.mastercoding.wifimaster.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Size;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.mastercoding.wifimaster.R;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class QRScannerActivity extends AppCompatActivity {

    private PreviewView previewView;
    private ImageView btnBack;

    private TextView txtSSID;
    private TextView txtPassword;

    private ExecutorService cameraExecutor;

    private String scannedSSID = "";
    private String scannedPassword = "";

    private final ActivityResultLauncher<String> requestPermission =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            startCamera();
                        }
                    });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_scanner);

        previewView = findViewById(R.id.previewView);
        btnBack = findViewById(R.id.btnBack);

        txtSSID = findViewById(R.id.txtSSID);
        txtPassword = findViewById(R.id.txtPassword);



        cameraExecutor = Executors.newSingleThreadExecutor();

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {

            startCamera();

        } else {

            requestPermission.launch(Manifest.permission.CAMERA);

        }

    }

    private void startCamera() {

        ListenableFuture<ProcessCameraProvider> future =
                ProcessCameraProvider.getInstance(this);

        future.addListener(() -> {

            try {

                ProcessCameraProvider provider = future.get();

                Preview preview = new Preview.Builder().build();

                preview.setSurfaceProvider(
                        previewView.getSurfaceProvider()
                );

                ImageAnalysis analysis =
                        new ImageAnalysis.Builder()
                                .setTargetResolution(new Size(1280, 720))
                                .build();

                BarcodeScanner scanner =
                        BarcodeScanning.getClient();

                analysis.setAnalyzer(
                        cameraExecutor,
                        image -> processImage(image, scanner)
                );

                provider.unbindAll();

                provider.bindToLifecycle(
                        this,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        analysis
                );

            } catch (Exception e) {

                e.printStackTrace();

            }

        }, ContextCompat.getMainExecutor(this));

    }

    private void processImage(ImageProxy imageProxy,
                              BarcodeScanner scanner) {

        if (imageProxy.getImage() == null) {
            imageProxy.close();
            return;
        }

        InputImage image =
                InputImage.fromMediaImage(
                        imageProxy.getImage(),
                        imageProxy.getImageInfo().getRotationDegrees());

        scanner.process(image)

                .addOnSuccessListener(barcodes -> {

                    for (Barcode barcode : barcodes) {

                        String raw = barcode.getRawValue();

                        if (raw != null && raw.startsWith("WIFI:")) {

                            String ssid = "";
                            String password = "";

                            String[] parts = raw.split(";");

                            for (String p : parts) {

                                if (p.startsWith("S:")) {
                                    ssid = p.substring(2);
                                }

                                if (p.startsWith("P:")) {
                                    password = p.substring(2);
                                }
                            }

                            showWifiData(ssid, password);

                            break;
                        }
                    }

                })

                .addOnCompleteListener(task -> imageProxy.close());

    }

    private void showWifiData(String ssid, String password) {

        scannedSSID = ssid;
        scannedPassword = password;

        runOnUiThread(() -> {
            txtSSID.setText(ssid);
            txtPassword.setText(password);
        });

    }



    @Override
    protected void onDestroy() {
        super.onDestroy();

        cameraExecutor.shutdown();
    }

}