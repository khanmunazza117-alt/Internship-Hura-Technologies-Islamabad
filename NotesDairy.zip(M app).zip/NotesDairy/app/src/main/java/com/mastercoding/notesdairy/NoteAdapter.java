package com.mastercoding.notesdairy;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NoteAdapter
        extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    Context context;
    ArrayList<Note> notes;

    public NoteAdapter(
            Context context,
            ArrayList<Note> notes) {

        this.context = context;
        this.notes = notes;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        View view =
                LayoutInflater.from(context)
                        .inflate(
                                R.layout.item_note,
                                parent,
                                false);

        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull NoteViewHolder holder,
            int position) {

        Note note = notes.get(position);

        holder.txtTitle.setText(
                note.getTitle());

        holder.txtContent.setText(
                note.getContent());

        holder.txtDate.setText(
                note.getDate());

        holder.itemView.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            context,
                            AddEditNoteActivity.class);

            intent.putExtra(
                    "id",
                    note.getId());

            intent.putExtra(
                    "title",
                    note.getTitle());

            intent.putExtra(
                    "content",
                    note.getContent());

            intent.putExtra(
                    "date",
                    note.getDate());

            context.startActivity(intent);
        });

        holder.imgMenu.setOnClickListener(v -> {

            PopupMenu popupMenu =
                    new PopupMenu(
                            context,
                            holder.imgMenu);

            MenuInflater inflater =
                    popupMenu.getMenuInflater();

            inflater.inflate(
                    R.menu.note_popup_menu,
                    popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {

                // SHARE NOTE
                if (item.getItemId()
                        == R.id.menu_share) {

                    try {

                        Intent shareIntent =
                                new Intent(
                                        Intent.ACTION_SEND);

                        shareIntent.setType(
                                "text/plain");

                        String shareText =
                                "Title: "
                                        + note.getTitle()
                                        + "\n\n"
                                        + note.getContent()
                                        + "\n\nDate: "
                                        + note.getDate();

                        shareIntent.putExtra(
                                Intent.EXTRA_TEXT,
                                shareText);

                        context.startActivity(
                                Intent.createChooser(
                                        shareIntent,
                                        "Share Note"));

                    } catch (Exception e) {

                        Toast.makeText(
                                        context,
                                        "Unable to share note",
                                        Toast.LENGTH_SHORT)
                                .show();
                    }

                    return true;
                }

                // DELETE NOTE
                if (item.getItemId()
                        == R.id.menu_delete) {

                    new AlertDialog.Builder(
                            context)
                            .setTitle(
                                    "Delete Note")
                            .setMessage(
                                    "Move note to trash?")
                            .setPositiveButton(
                                    "Delete",
                                    (dialog, which) -> {

                                        note.setDeleted(
                                                true);

                                        ArrayList<Note> allNotes =
                                                NoteStorage.loadNotes(
                                                        context);

                                        for (Note n :
                                                allNotes) {

                                            if (n.getId()
                                                    == note.getId()) {

                                                n.setDeleted(
                                                        true);

                                                break;
                                            }
                                        }

                                        NoteStorage.saveNotes(
                                                context,
                                                allNotes);

                                        notes.remove(
                                                holder.getAdapterPosition());

                                        notifyDataSetChanged();

                                        Toast.makeText(
                                                        context,
                                                        "Note moved to trash",
                                                        Toast.LENGTH_SHORT)
                                                .show();
                                    })
                            .setNegativeButton(
                                    "Cancel",
                                    null)
                            .show();

                    return true;
                }

                return false;
            });

            popupMenu.show();
        });
    }

    @Override
    public int getItemCount() {

        return notes.size();
    }

    public static class NoteViewHolder
            extends RecyclerView.ViewHolder {

        TextView txtTitle;
        TextView txtContent;
        TextView txtDate;
        ImageView imgMenu;

        public NoteViewHolder(
                @NonNull View itemView) {

            super(itemView);

            txtTitle =
                    itemView.findViewById(
                            R.id.txtTitle);

            txtContent =
                    itemView.findViewById(
                            R.id.txtContent);

            txtDate =
                    itemView.findViewById(
                            R.id.txtDate);

            imgMenu =
                    itemView.findViewById(
                            R.id.imgMenu);
        }
    }
}