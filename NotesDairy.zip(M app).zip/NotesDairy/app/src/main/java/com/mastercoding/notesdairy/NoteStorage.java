package com.mastercoding.notesdairy;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class NoteStorage {

    private static final String PREF_NAME = "NotesDB";
    private static final String KEY_NOTES = "notes";

    public static void saveNotes(
            Context context,
            ArrayList<Note> notes) {

        JSONArray jsonArray = new JSONArray();

        try {

            for (Note note : notes) {

                JSONObject object =
                        new JSONObject();

                object.put("id",
                        note.getId());

                object.put("title",
                        note.getTitle());

                object.put("content",
                        note.getContent());

                object.put("date",
                        note.getDate());

                object.put("deleted",
                        note.isDeleted());

                jsonArray.put(object);
            }

            SharedPreferences preferences =
                    context.getSharedPreferences(
                            PREF_NAME,
                            Context.MODE_PRIVATE);

            preferences.edit()
                    .putString(
                            KEY_NOTES,
                            jsonArray.toString())
                    .apply();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Note> loadNotes(
            Context context) {

        ArrayList<Note> notes =
                new ArrayList<>();

        SharedPreferences preferences =
                context.getSharedPreferences(
                        PREF_NAME,
                        Context.MODE_PRIVATE);

        String data =
                preferences.getString(
                        KEY_NOTES,
                        "[]");

        try {

            JSONArray array =
                    new JSONArray(data);

            for (int i = 0;
                 i < array.length();
                 i++) {

                JSONObject object =
                        array.getJSONObject(i);

                notes.add(
                        new Note(
                                object.getInt("id"),
                                object.getString("title"),
                                object.getString("content"),
                                object.getString("date"),
                                object.getBoolean("deleted")
                        ));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return notes;
    }

    public static int getNextId(
            Context context) {

        int max = 0;

        for (Note note :
                loadNotes(context)) {

            if (note.getId() > max) {

                max = note.getId();
            }
        }

        return max + 1;
    }
}