package com.mastercoding.notesdairy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DeletedNoteAdapter
        extends RecyclerView.Adapter<DeletedNoteAdapter.ViewHolder> {

    Context context;
    ArrayList<Note> notes;

    public DeletedNoteAdapter(
            Context context,
            ArrayList<Note> notes) {

        this.context = context;
        this.notes = notes;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        View view =
                LayoutInflater.from(context)
                        .inflate(
                                R.layout.item_deleted_note,
                                parent,
                                false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder,
            int position) {

        Note note = notes.get(position);

        holder.txtTitle.setText(
                note.getTitle());

        holder.btnRestore.setOnClickListener(v -> {

            ArrayList<Note> allNotes =
                    NoteStorage.loadNotes(context);

            for (Note n : allNotes) {

                if (n.getId()
                        == note.getId()) {

                    n.setDeleted(false);
                    break;
                }
            }

            NoteStorage.saveNotes(
                    context,
                    allNotes);

            notes.remove(position);

            notifyDataSetChanged();
        });
    }

    @Override
    public int getItemCount() {

        return notes.size();
    }

    static class ViewHolder
            extends RecyclerView.ViewHolder {

        TextView txtTitle;
        Button btnRestore;

        public ViewHolder(
                @NonNull View itemView) {

            super(itemView);

            txtTitle =
                    itemView.findViewById(
                            R.id.txtDeletedTitle);

            btnRestore =
                    itemView.findViewById(
                            R.id.btnRestore);
        }
    }
}
