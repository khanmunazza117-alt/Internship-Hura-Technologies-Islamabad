package com.mastercoding.notesdairy;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.PopupMenu;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    MaterialToolbar toolbar;
    RecyclerView recyclerView;
    FloatingActionButton fabAdd;

    ArrayList<Note> noteList;
    NoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ThemeManager.applyTheme(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        toolbar = findViewById(R.id.toolbar);
        recyclerView = findViewById(R.id.recyclerView);
        fabAdd = findViewById(R.id.fabAdd);

        // Theme Toolbar Color
        String theme =
                getSharedPreferences(
                        "theme",
                        MODE_PRIVATE)
                        .getString(
                                "color",
                                "yellow");

        if (theme.equals("yellow")) {

            toolbar.setBackgroundColor(
                    getColor(R.color.yellow_toolbar));
        }

        else if (theme.equals("orange")) {

            toolbar.setBackgroundColor(
                    getColor(R.color.orange_toolbar));
        }

        else if (theme.equals("blue")) {

            toolbar.setBackgroundColor(
                    getColor(R.color.blue_toolbar));
        }

        setSupportActionBar(toolbar);

        ActionBarDrawerToggle toggle =
                new ActionBarDrawerToggle(
                        this,
                        drawerLayout,
                        toolbar,
                        R.string.app_name,
                        R.string.app_name);

        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        recyclerView.setLayoutManager(
                new LinearLayoutManager(this));

        loadActiveNotes();

        fabAdd.setOnClickListener(v -> {

            PopupMenu popup =
                    new PopupMenu(
                            MainActivity.this,
                            fabAdd);

            popup.getMenu().add("Create Note");

            popup.setOnMenuItemClickListener(item -> {

                startActivity(
                        new Intent(
                                MainActivity.this,
                                AddEditNoteActivity.class));

                return true;
            });

            popup.show();
        });

        getOnBackPressedDispatcher()
                .addCallback(
                        this,
                        new OnBackPressedCallback(true) {

                            @Override
                            public void handleOnBackPressed() {

                                new AlertDialog.Builder(
                                        MainActivity.this)
                                        .setTitle("Exit")
                                        .setMessage(
                                                "Are you sure you want to exit?")
                                        .setPositiveButton(
                                                "Yes",
                                                (dialog, which) -> finish())
                                        .setNegativeButton(
                                                "No",
                                                null)
                                        .show();
                            }
                        });
    }

    private void loadActiveNotes() {

        noteList = new ArrayList<>();

        ArrayList<Note> allNotes =
                NoteStorage.loadNotes(this);

        for (Note note : allNotes) {

            if (!note.isDeleted()) {

                noteList.add(note);
            }
        }

        adapter =
                new NoteAdapter(
                        this,
                        noteList);

        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {

        super.onResume();

        loadActiveNotes();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(
                R.menu.toolbar_menu,
                menu);

        MenuItem searchItem =
                menu.findItem(
                        R.id.action_search);

        SearchView searchView =
                (SearchView) searchItem.getActionView();

        searchView.setQueryHint(
                "Search Notes");

        searchView.setOnQueryTextListener(
                new SearchView.OnQueryTextListener() {

                    @Override
                    public boolean onQueryTextSubmit(
                            String query) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(
                            String newText) {

                        filterNotes(newText);

                        return true;
                    }
                });

        return true;
    }

    private void filterNotes(String text) {

        ArrayList<Note> filtered =
                new ArrayList<>();

        for (Note note : noteList) {

            if (note.getTitle()
                    .toLowerCase(Locale.getDefault())
                    .contains(
                            text.toLowerCase(Locale.getDefault()))

                    ||

                    note.getContent()
                            .toLowerCase(Locale.getDefault())
                            .contains(
                                    text.toLowerCase(Locale.getDefault()))) {

                filtered.add(note);
            }
        }

        recyclerView.setAdapter(
                new NoteAdapter(
                        this,
                        filtered));
    }

    @Override
    public boolean onOptionsItemSelected(
            @NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_sort_title) {

            Collections.sort(
                    noteList,
                    Comparator.comparing(
                            Note::getTitle));

            adapter.notifyDataSetChanged();

            return true;
        }

        if (id == R.id.action_sort_date) {

            Collections.sort(
                    noteList,
                    (n1, n2) ->
                            n2.getDate()
                                    .compareTo(
                                            n1.getDate()));

            adapter.notifyDataSetChanged();

            return true;
        }

        if (id == R.id.action_grid) {

            recyclerView.setLayoutManager(
                    new GridLayoutManager(
                            this,
                            2));

            return true;
        }

        if (id == R.id.action_list) {

            recyclerView.setLayoutManager(
                    new LinearLayoutManager(
                            this));

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(
            @NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.nav_notes) {

            drawerLayout.closeDrawers();
        }

        else if (id == R.id.nav_themes) {

            startActivity(
                    new Intent(
                            this,
                            SettingsActivity.class));
        }

        else if (id == R.id.nav_deleted) {

            startActivity(
                    new Intent(
                            this,
                            DeletedNotesActivity.class));
        }

        else if (id == R.id.nav_settings) {

            startActivity(
                    new Intent(
                            this,
                            SettingsActivity.class));
        }

        else if (id == R.id.nav_privacy) {

            new AlertDialog.Builder(this)
                    .setTitle("Privacy Policy")
                    .setMessage(
                            "This app stores notes locally on your device only.")
                    .setPositiveButton(
                            "OK",
                            null)
                    .show();
        }

        else if (id == R.id.nav_terms) {

            new AlertDialog.Builder(this)
                    .setTitle("Terms & Conditions")
                    .setMessage(
                            "This application is provided for personal note keeping.")
                    .setPositiveButton(
                            "OK",
                            null)
                    .show();
        }

        drawerLayout.closeDrawers();

        return true;
    }
}