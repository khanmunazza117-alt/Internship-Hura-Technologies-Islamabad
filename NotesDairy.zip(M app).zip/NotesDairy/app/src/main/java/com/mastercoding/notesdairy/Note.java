package com.mastercoding.notesdairy;

public class Note {

    private int id;
    private String title;
    private String content;
    private String date;
    private boolean deleted;

    public Note(int id,
                String title,
                String content,
                String date,
                boolean deleted) {

        this.id = id;
        this.title = title;
        this.content = content;
        this.date = date;
        this.deleted = deleted;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
}