package com.mastercoding.notesdairy;

import android.app.Activity;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

public class ThemeManager {

    public static void applyTheme(Activity activity) {

        SharedPreferences prefs =
                activity.getSharedPreferences(
                        "theme",
                        Activity.MODE_PRIVATE);

        boolean dark =
                prefs.getBoolean(
                        "dark",
                        false);

        if (dark) {

            AppCompatDelegate.setDefaultNightMode(
                    AppCompatDelegate.MODE_NIGHT_YES);
        }
        else {

            AppCompatDelegate.setDefaultNightMode(
                    AppCompatDelegate.MODE_NIGHT_NO);
        }

        String color =
                prefs.getString(
                        "color",
                        "yellow");

        if (color.equals("yellow")) {

            activity.setTheme(
                    R.style.Theme_NotesDairy_Yellow);
        }

        else if (color.equals("orange")) {

            activity.setTheme(
                    R.style.Theme_NotesDairy_Orange);
        }

        else if (color.equals("blue")) {

            activity.setTheme(
                    R.style.Theme_NotesDairy_Blue);
        }
    }
}