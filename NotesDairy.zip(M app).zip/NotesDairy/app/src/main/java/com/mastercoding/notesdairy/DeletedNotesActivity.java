package com.mastercoding.notesdairy;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DeletedNotesActivity
        extends AppCompatActivity {

    RecyclerView recyclerDeleted;

    ArrayList<Note> deletedNotes;

    DeletedNoteAdapter adapter;

    @Override
    protected void onCreate(
            Bundle savedInstanceState) {

        ThemeManager.applyTheme(this);

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_deleted_notes);

        recyclerDeleted =
                findViewById(
                        R.id.recyclerDeleted);

        recyclerDeleted.setLayoutManager(
                new LinearLayoutManager(this));

        loadDeletedNotes();
    }

    @Override
    protected void onResume() {

        super.onResume();

        loadDeletedNotes();
    }

    private void loadDeletedNotes() {

        deletedNotes =
                new ArrayList<>();

        ArrayList<Note> allNotes =
                NoteStorage.loadNotes(this);

        for (Note note : allNotes) {

            if (note.isDeleted()) {

                deletedNotes.add(note);
            }
        }

        adapter =
                new DeletedNoteAdapter(
                        this,
                        deletedNotes);

        recyclerDeleted.setAdapter(
                adapter);
    }
}