package com.mastercoding.notesdairy;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class AddEditNoteActivity extends AppCompatActivity {

    EditText editTitle;
    EditText editContent;
    TextView txtDate;

    ImageView btnSave;
    ImageView btnBack;

    boolean isEditing = false;
    int noteId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ThemeManager.applyTheme(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_note);

        editTitle = findViewById(R.id.editTitle);
        editContent = findViewById(R.id.editContent);
        txtDate = findViewById(R.id.txtDate);

        btnSave = findViewById(R.id.btnSave);
        btnBack = findViewById(R.id.btnBack);

        String currentDate =
                new SimpleDateFormat(
                        "MM-dd-yy",
                        Locale.getDefault())
                        .format(new Date());

        txtDate.setText(currentDate);

        if (getIntent().hasExtra("id")) {

            isEditing = true;

            noteId =
                    getIntent().getIntExtra(
                            "id",
                            -1);

            editTitle.setText(
                    getIntent().getStringExtra(
                            "title"));

            editContent.setText(
                    getIntent().getStringExtra(
                            "content"));

            txtDate.setText(
                    getIntent().getStringExtra(
                            "date"));
        }

        btnBack.setOnClickListener(v -> finish());

        btnSave.setOnClickListener(v -> {

            String title =
                    editTitle.getText()
                            .toString()
                            .trim();

            String content =
                    editContent.getText()
                            .toString()
                            .trim();

            if (title.isEmpty()) {

                editTitle.setError(
                        "Please enter note title");

                return;
            }

            ArrayList<Note> notes =
                    NoteStorage.loadNotes(this);

            if (isEditing) {

                for (Note note : notes) {

                    if (note.getId() == noteId) {

                        note.setTitle(title);
                        note.setContent(content);
                        note.setDate(
                                txtDate.getText()
                                        .toString());

                        break;
                    }
                }

                Toast.makeText(
                                this,
                                "Note Updated Successfully",
                                Toast.LENGTH_SHORT)
                        .show();
            }

            else {

                Note newNote =
                        new Note(
                                NoteStorage.getNextId(this),
                                title,
                                content,
                                txtDate.getText().toString(),
                                false);

                notes.add(newNote);

                Toast.makeText(
                                this,
                                "Note Saved Successfully",
                                Toast.LENGTH_SHORT)
                        .show();
            }

            NoteStorage.saveNotes(
                    this,
                    notes);

            finish();
        });
    }
}