package com.mastercoding.notesdairy;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class SettingsActivity extends AppCompatActivity {

    Button btnDarkMode;
    Button btnYellow;
    Button btnOrange;
    Button btnBlue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ThemeManager.applyTheme(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        btnDarkMode = findViewById(R.id.btnDarkMode);
        btnYellow = findViewById(R.id.btnYellow);
        btnOrange = findViewById(R.id.btnOrange);
        btnBlue = findViewById(R.id.btnBlue);

        btnDarkMode.setOnClickListener(v -> {

            SharedPreferences prefs =
                    getSharedPreferences(
                            "theme",
                            MODE_PRIVATE);

            boolean dark =
                    prefs.getBoolean(
                            "dark",
                            false);

            prefs.edit()
                    .putBoolean(
                            "dark",
                            !dark)
                    .apply();

            if (!dark) {

                AppCompatDelegate.setDefaultNightMode(
                        AppCompatDelegate.MODE_NIGHT_YES);

                Toast.makeText(
                        this,
                        "Dark Mode Enabled",
                        Toast.LENGTH_SHORT
                ).show();
            }
            else {

                AppCompatDelegate.setDefaultNightMode(
                        AppCompatDelegate.MODE_NIGHT_NO);

                Toast.makeText(
                        this,
                        "Dark Mode Disabled",
                        Toast.LENGTH_SHORT
                ).show();
            }

            recreate();
        });

        btnYellow.setOnClickListener(v -> {

            saveTheme("yellow");

            Toast.makeText(
                    this,
                    "Yellow Theme Applied",
                    Toast.LENGTH_SHORT
            ).show();

            recreate();
        });

        btnOrange.setOnClickListener(v -> {

            saveTheme("orange");

            Toast.makeText(
                    this,
                    "Orange Theme Applied",
                    Toast.LENGTH_SHORT
            ).show();

            recreate();
        });

        btnBlue.setOnClickListener(v -> {

            saveTheme("blue");

            Toast.makeText(
                    this,
                    "Blue Theme Applied",
                    Toast.LENGTH_SHORT
            ).show();

            recreate();
        });
    }

    private void saveTheme(String theme) {

        SharedPreferences prefs =
                getSharedPreferences(
                        "theme",
                        MODE_PRIVATE);

        prefs.edit()
                .putString(
                        "color",
                        theme)
                .apply();
    }
}